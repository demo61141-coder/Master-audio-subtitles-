import {
  boolean,
  customType,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

/** bytea column helper (node-postgres returns bytea as Buffer). */
const bytea = customType<{ data: Uint8Array; driverData: Uint8Array | string }>({
  dataType() {
    return "bytea";
  },
  fromDriver(value: Uint8Array | string): Uint8Array {
    if (typeof value === "string") {
      return Buffer.from(value.replace(/^\\x/, ""), "hex");
    }
    return value;
  },
  toDriver(value: Uint8Array): string {
    return `\\x${Buffer.from(value).toString("hex")}`;
  },
});

/** Learned noise prints, recorder settings and analysis payloads. */
export type NoisePrintRecord = {
  sampleRate: number;
  fftSize: number;
  learnedSec: number;
  avgDb: number;
  peakDb: number;
  magnitudes: number[];
};

export type RecorderSettingsRecord = {
  gateEnabled: boolean;
  gateThresholdDb: number;
  gateHoldSec: number;
  liveSuppress: boolean;
  suppressStrength: number;
  autoClean: boolean;
  profileSec: number;
};

export type StatsRecord = {
  peakDb: number;
  rmsDb: number;
  dynamicRangeDb: number;
  silenceSec: number;
  skippedSec: number;
  chunks: number;
  clipped: number;
};

export const projects = pgTable("projects", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  durationSec: doublePrecision("duration_sec").notNull().default(0),
  sampleRate: integer("sample_rate").notNull().default(44100),
  channels: integer("channels").notNull().default(1),
  status: text("status").notNull().default("raw"),
  source: text("source").notNull().default("mic"),
  tags: text("tags")
    .array()
    .notNull()
    .default([]),
  noisePrint: jsonb("noise_print").$type<NoisePrintRecord | null>(),
  settings: jsonb("settings").$type<RecorderSettingsRecord | null>(),
  stats: jsonb("stats").$type<StatsRecord | null>(),
  version: integer("version").notNull().default(1),
});

export const audioAssets = pgTable("audio_assets", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(),
  label: text("label").notNull(),
  mime: text("mime").notNull().default("audio/wav"),
  startSec: doublePrecision("start_sec"),
  endSec: doublePrecision("end_sec"),
  durationSec: doublePrecision("duration_sec").notNull().default(0),
  bytes: integer("bytes").notNull().default(0),
  data: bytea("data").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type PresetConfigRecord = {
  highpassHz: number;
  lowpassHz: number;
  warmthHz: number;
  warmthGainDb: number;
  presenceHz: number;
  presenceGainDb: number;
  presenceQ: number;
  airHz: number;
  airGainDb: number;
  deEsserHz: number;
  deEsserGainDb: number;
  deEsserQ: number;
  compThresholdDb: number;
  compRatio: number;
  compAttack: number;
  compRelease: number;
  makeupGainDb: number;
  limiterDrive: number;
  levelAmount: number;
};

export const presets = pgTable("presets", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull().default("voice"),
  description: text("description"),
  builtin: boolean("builtin").notNull().default(false),
  config: jsonb("config").$type<PresetConfigRecord>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const processingLogs = pgTable("processing_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id").references(() => projects.id, { onDelete: "cascade" }),
  operation: text("operation").notNull(),
  label: text("label").notNull().default(""),
  params: jsonb("params").$type<Record<string, unknown>>(),
  result: jsonb("result").$type<Record<string, unknown>>(),
  durationMs: integer("duration_ms").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

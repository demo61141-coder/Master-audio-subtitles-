"use client";

import { useEffect, type ReactNode } from "react";
import { IconAlert, IconCheck, IconCopy, IconInfo } from "./icons";
import { useWorkspace } from "@/lib/store";

/* ---------------------------------------------------------------- Panel */

export function Panel({
  title,
  step,
  subtitle,
  icon,
  right,
  children,
  className = "",
  tone = "default",
}: {
  title?: ReactNode;
  step?: string;
  subtitle?: ReactNode;
  icon?: ReactNode;
  right?: ReactNode;
  children?: ReactNode;
  className?: string;
  tone?: "default" | "signal" | "teal" | "rec";
}) {
  const accent =
    tone === "teal"
      ? "before:bg-teal"
      : tone === "rec"
        ? "before:bg-rec"
        : tone === "signal"
          ? "before:bg-signal"
          : "before:bg-ink-600";
  return (
    <section
      className={`panel panel-notch relative before:absolute before:top-0 before:left-0 before:h-[2px] before:w-16 ${accent} ${className}`}
    >
      {(title || right) && (
        <header className="flex items-start justify-between gap-3 border-b border-ink-700/70 px-4 py-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              {step && <span className="label-xs text-copper">{step}</span>}
              {icon && <span className="text-signal">{icon}</span>}
              {title && (
                <h2 className="truncate font-display text-[13px] font-600 tracking-wide text-sand-50 uppercase">
                  {title}
                </h2>
              )}
            </div>
            {subtitle && <p className="mt-1 text-[12.5px] leading-relaxed text-sand-300">{subtitle}</p>}
          </div>
          {right && <div className="shrink-0">{right}</div>}
        </header>
      )}
      <div className="px-4 py-4">{children}</div>
    </section>
  );
}

/* --------------------------------------------------------------- Button */

type BtnProps = {
  children?: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "outline" | "danger" | "teal";
  size?: "sm" | "md" | "lg";
  icon?: ReactNode;
  disabled?: boolean;
  active?: boolean;
  className?: string;
  type?: "button" | "submit";
  title?: string;
};

export function Btn({
  children,
  onClick,
  variant = "outline",
  size = "md",
  icon,
  disabled,
  active,
  className = "",
  type = "button",
  title,
}: BtnProps) {
  const sizes = {
    sm: "h-7 px-2.5 text-[11.5px] gap-1.5",
    md: "h-9 px-3.5 text-[12.5px] gap-2",
    lg: "h-11 px-5 text-[14px] gap-2.5",
  }[size];
  const variants = {
    primary:
      "bg-gradient-to-b from-[#ffb357] to-[#f0731a] text-ink-950 font-600 border border-[#ffd08a]/50 shadow-[0_6px_22px_-10px_rgba(255,140,40,0.9)] hover:brightness-110",
    teal: "bg-gradient-to-b from-[#54e3d3] to-[#12a497] text-ink-950 font-600 border border-[#8ff2e7]/40 hover:brightness-110",
    danger: "bg-rec/15 text-rec border border-rec/45 hover:bg-rec/25",
    ghost: "bg-transparent text-sand-300 border border-transparent hover:text-sand-50 hover:bg-ink-800",
    outline: "bg-ink-800/70 text-sand-100 border border-ink-600 hover:border-signal/60 hover:text-sand-50",
  }[variant];
  return (
    <button
      type={type}
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={`inline-flex items-center justify-center font-display tracking-wide transition-all duration-150 active:translate-y-[1px] disabled:cursor-not-allowed disabled:opacity-35 ${sizes} ${variants} ${
        active ? "ring-1 ring-signal/70" : ""
      } ${className}`}
    >
      {icon}
      {children}
    </button>
  );
}

/* ----------------------------------------------------------------- Chip */

export function Chip({
  children,
  active,
  onClick,
  tone = "signal",
  title,
}: {
  children: ReactNode;
  active?: boolean;
  onClick?: () => void;
  tone?: "signal" | "teal" | "sand";
  title?: string;
}) {
  const on =
    tone === "teal"
      ? "border-teal/70 bg-teal/15 text-teal"
      : tone === "sand"
        ? "border-sand-300/60 bg-sand-300/10 text-sand-100"
        : "border-signal/70 bg-signal/15 text-signal";
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      className={`border px-2.5 py-1 font-mono text-[11px] tracking-wide transition-colors ${
        active ? on : "border-ink-700 bg-ink-850 text-sand-300 hover:border-ink-600 hover:text-sand-100"
      }`}
    >
      {children}
    </button>
  );
}

/* -------------------------------------------------------------- Segmented */

export function Segmented<T extends string | number>({
  value,
  options,
  onChange,
  size = "md",
}: {
  value: T;
  options: { value: T; label: ReactNode; hint?: string }[];
  onChange: (v: T) => void;
  size?: "sm" | "md";
}) {
  return (
    <div className="inline-flex border border-ink-700 bg-ink-900/80 p-[3px]">
      {options.map((o) => (
        <button
          key={String(o.value)}
          type="button"
          title={o.hint}
          onClick={() => onChange(o.value)}
          className={`${size === "sm" ? "px-2 py-[3px] text-[11px]" : "px-3 py-1.5 text-[12.5px]"} font-display tracking-wide transition-all ${
            value === o.value
              ? "bg-gradient-to-b from-[#ffb357] to-[#ef7418] text-ink-950 font-600"
              : "text-sand-300 hover:text-sand-50"
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

/* --------------------------------------------------------------- Slider */

export function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  unit = "",
  onChange,
  hint,
  tone = "signal",
  format,
  disabled,
}: {
  label: ReactNode;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (v: number) => void;
  hint?: ReactNode;
  tone?: "signal" | "teal";
  format?: (v: number) => string;
  disabled?: boolean;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className={disabled ? "opacity-40" : ""}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-[12.5px] text-sand-100">{label}</span>
        <span className="readout text-[12px]">
          {format ? format(value) : value}
          <span className="text-sand-500">{unit}</span>
        </span>
      </div>
      <div className="relative mt-1">
        <div
          className="pointer-events-none absolute top-[9px] left-0 h-[4px] bg-gradient-to-r from-copper/80 to-signal/70"
          style={{ width: `${Math.max(0, Math.min(100, pct))}%` }}
        />
        <input
          type="range"
          className={tone === "teal" ? "teal relative" : "relative"}
          min={min}
          max={max}
          step={step}
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(Number(e.target.value))}
        />
      </div>
      {hint && <p className="mt-0.5 text-[11.5px] leading-snug text-sand-500">{hint}</p>}
    </div>
  );
}

/* --------------------------------------------------------------- Toggle */

export function Toggle({
  checked,
  onChange,
  label,
  hint,
  disabled,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: ReactNode;
  hint?: ReactNode;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className="group flex w-full items-center justify-between gap-3 text-left disabled:opacity-40"
    >
      <span>
        <span className="block text-[12.5px] text-sand-100 group-hover:text-sand-50">{label}</span>
        {hint && <span className="mt-0.5 block text-[11.5px] leading-snug text-sand-500">{hint}</span>}
      </span>
      <span
        className={`relative h-[22px] w-[42px] shrink-0 border transition-colors ${
          checked ? "border-signal/70 bg-signal/25" : "border-ink-600 bg-ink-900"
        }`}
      >
        <span
          className={`absolute top-[2px] h-[16px] w-[16px] transition-all duration-200 ${
            checked ? "left-[22px] bg-gradient-to-b from-[#ffc46b] to-[#ff7a18]" : "left-[2px] bg-ink-600"
          }`}
        />
      </span>
    </button>
  );
}

/* ----------------------------------------------------------------- Stat */

export function Stat({
  label,
  value,
  unit,
  tone = "sand",
  sub,
}: {
  label: ReactNode;
  value: ReactNode;
  unit?: string;
  tone?: "sand" | "signal" | "teal" | "rec" | "lime";
  sub?: ReactNode;
}) {
  const color = {
    sand: "text-sand-50",
    signal: "text-signal",
    teal: "text-teal",
    rec: "text-rec",
    lime: "text-lime",
  }[tone];
  return (
    <div className="border border-ink-700/70 bg-ink-900/60 px-3 py-2">
      <div className="label-xs">{label}</div>
      <div className={`mt-1 font-mono text-[19px] leading-none tabular-nums ${color}`}>
        {value}
        {unit && <span className="ml-1 text-[11px] text-sand-500">{unit}</span>}
      </div>
      {sub && <div className="mt-1 text-[11px] text-sand-500">{sub}</div>}
    </div>
  );
}

export function Badge({
  children,
  tone = "sand",
}: {
  children: ReactNode;
  tone?: "sand" | "signal" | "teal" | "rec" | "lime";
}) {
  const map = {
    sand: "border-ink-600 text-sand-300",
    signal: "border-signal/50 bg-signal/10 text-signal",
    teal: "border-teal/50 bg-teal/10 text-teal",
    rec: "border-rec/50 bg-rec/10 text-rec",
    lime: "border-lime/50 bg-lime/10 text-lime",
  }[tone];
  return (
    <span className={`inline-flex items-center gap-1 border px-1.5 py-[2px] font-mono text-[10px] tracking-[0.12em] uppercase ${map}`}>
      {children}
    </span>
  );
}

/* ---------------------------------------------------------------- Toast */

export function ToastHost() {
  const toast = useWorkspace((s) => s.toast);
  const clear = useWorkspace((s) => s.clearToast);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(clear, 4200);
    return () => clearTimeout(t);
  }, [toast, clear]);
  if (!toast) return null;
  const tone =
    toast.tone === "err"
      ? "border-rec/60 bg-rec/12 text-rec"
      : toast.tone === "warn"
        ? "border-signal/60 bg-signal/12 text-signal"
        : "border-teal/60 bg-teal/12 text-teal";
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-6 z-50 flex justify-center px-4">
      <div className={`rise-in pointer-events-auto flex items-center gap-2.5 border px-4 py-2.5 backdrop-blur-md ${tone}`}>
        {toast.tone === "err" ? <IconAlert width={16} height={16} /> : toast.tone === "warn" ? <IconInfo width={16} height={16} /> : <IconCheck width={16} height={16} />}
        <span className="text-[13px]">{toast.text}</span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ CodeBlock */

export function CodeBlock({ code, label }: { code: string; label?: string }) {
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      /* clipboard unavailable */
    }
  };
  return (
    <div className="border border-ink-700 bg-ink-950/80">
      <div className="flex items-center justify-between border-b border-ink-700/70 px-3 py-1.5">
        <span className="label-xs">{label ?? "command"}</span>
        <button
          type="button"
          onClick={copy}
          className="inline-flex items-center gap-1 font-mono text-[10.5px] text-sand-500 transition-colors hover:text-teal"
        >
          <IconCopy width={13} height={13} /> copy
        </button>
      </div>
      <pre className="overflow-x-auto px-3 py-2.5 font-mono text-[12px] leading-relaxed text-sand-100">
        {code}
      </pre>
    </div>
  );
}

export function Busy({ label }: { label: string }) {
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-ink-950/72 backdrop-blur-[3px]">
      <div className="panel flex items-center gap-3 px-5 py-4">
        <span className="spin-slow inline-block h-4 w-4 border-2 border-signal border-t-transparent rounded-full" />
        <span className="font-mono text-[12.5px] tracking-wide text-sand-100">{label}</span>
      </div>
    </div>
  );
}

export function Row({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`flex flex-wrap items-center gap-2 ${className}`}>{children}</div>;
}

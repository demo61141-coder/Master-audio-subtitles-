import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement>;

const base = (props: P) => ({
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.5,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  width: 18,
  height: 18,
  ...props,
});

export const LogoMark = (props: P) => (
  <svg {...base(props)} strokeWidth={1.4}>
    <path d="M2 12h2.2l1.6-6 2.2 13 2.4-17 2.4 22 2.2-13 1.6 5h3" />
  </svg>
);

export const IconMic = (props: P) => (
  <svg {...base(props)}>
    <rect x="9" y="2.5" width="6" height="11" rx="3" />
    <path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3.5M8.5 21.5h7" />
  </svg>
);

export const IconWave = (props: P) => (
  <svg {...base(props)}>
    <path d="M2 12h2M6 7v10M10 3.5v17M14 8v8M18 5v14M22 11v2" />
  </svg>
);

export const IconScissors = (props: P) => (
  <svg {...base(props)}>
    <circle cx="6" cy="6.5" r="2.5" />
    <circle cx="6" cy="17.5" r="2.5" />
    <path d="M8.2 8 20 18M8.2 16 20 6M12.4 12 20 12" />
  </svg>
);

export const IconWand = (props: P) => (
  <svg {...base(props)}>
    <path d="M4 20 15 9M13.5 4.5 14.8 7l2.5 1.3-2.5 1.3L13.5 12l-1.3-2.4L9.7 8.3l2.5-1.3zM19 13l.8 1.7 1.7.8-1.7.8-.8 1.7-.8-1.7-1.7-.8 1.7-.8z" />
    <path d="m13.8 10.2 3.6 3.6" />
  </svg>
);

export const IconLibrary = (props: P) => (
  <svg {...base(props)}>
    <path d="M3.5 4.5h6v15h-6zM12 4.5h5v15h-5z" />
    <path d="m19.2 5.6 2.3 14.1" />
  </svg>
);

export const IconAndroid = (props: P) => (
  <svg {...base(props)}>
    <path d="M4 11a8 8 0 0 1 16 0v8H4z" />
    <path d="M7.5 7 6 4.6M16.5 7 18 4.6M9 11.5v.01M15 11.5v.01" />
  </svg>
);

export const IconPlay = (props: P) => (
  <svg {...base(props)}>
    <path d="M7 4.8 19 12 7 19.2z" fill="currentColor" stroke="none" />
  </svg>
);

export const IconPause = (props: P) => (
  <svg {...base(props)}>
    <path d="M8.5 5v14M15.5 5v14" strokeWidth={2.4} />
  </svg>
);

export const IconStop = (props: P) => (
  <svg {...base(props)}>
    <rect x="6" y="6" width="12" height="12" rx="1" fill="currentColor" stroke="none" />
  </svg>
);

export const IconRecord = (props: P) => (
  <svg {...base(props)}>
    <circle cx="12" cy="12" r="6" fill="currentColor" stroke="none" />
  </svg>
);

export const IconPlus = (props: P) => (
  <svg {...base(props)}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);

export const IconTrash = (props: P) => (
  <svg {...base(props)}>
    <path d="M4 6.5h16M9.5 6.5V4h5v2.5M6.5 6.5 7.6 20h8.8l1.1-13.5M10.2 10v6.5M13.8 10v6.5" />
  </svg>
);

export const IconUndo = (props: P) => (
  <svg {...base(props)}>
    <path d="M4 9h9.5a5.5 5.5 0 1 1 0 11H8M4 9l4-4M4 9l4 4" />
  </svg>
);

export const IconRedo = (props: P) => (
  <svg {...base(props)}>
    <path d="M20 9h-9.5a5.5 5.5 0 1 0 0 11H16M20 9l-4-4M20 9l-4 4" />
  </svg>
);

export const IconDownload = (props: P) => (
  <svg {...base(props)}>
    <path d="M12 3.5v11M7.5 10.5 12 15l4.5-4.5M4 19.5h16" />
  </svg>
);

export const IconUpload = (props: P) => (
  <svg {...base(props)}>
    <path d="M12 15.5v-11M7.5 8.5 12 4l4.5 4.5M4 19.5h16" />
  </svg>
);

export const IconFan = (props: P) => (
  <svg {...base(props)}>
    <circle cx="12" cy="12" r="2.2" />
    <path d="M12 9.8C12 6 13.6 3.5 16.4 3.5c2 0 2.8 2.2 1.4 4-1.3 1.7-3.6 2.3-5.8 2.3zM14.2 12c3.8 0 6.3 1.6 6.3 4.4 0 2-2.2 2.8-4 1.4-1.7-1.3-2.3-3.6-2.3-5.8zM12 14.2C12 18 10.4 20.5 7.6 20.5c-2 0-2.8-2.2-1.4-4 1.3-1.7 3.6-2.3 5.8-2.3zM9.8 12C6 12 3.5 10.4 3.5 7.6c0-2 2.2-2.8 4-1.4 1.7 1.3 2.3 3.6 2.3 5.8z" />
  </svg>
);

export const IconMute = (props: P) => (
  <svg {...base(props)}>
    <path d="M4 9.5h3.5L12 5.5v13L7.5 14.5H4z" />
    <path d="m16 9.5 5 5M21 9.5l-5 5" />
  </svg>
);

export const IconBolt = (props: P) => (
  <svg {...base(props)}>
    <path d="M13.5 2.5 5 13.5h5.5L9.5 21.5 19 10.5h-5.8z" />
  </svg>
);

export const IconCheck = (props: P) => (
  <svg {...base(props)}>
    <path d="m4.5 12.5 5 5 10-11" />
  </svg>
);

export const IconClock = (props: P) => (
  <svg {...base(props)}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7v5.3l3.4 2" />
  </svg>
);

export const IconZoomIn = (props: P) => (
  <svg {...base(props)}>
    <circle cx="10.5" cy="10.5" r="6.5" />
    <path d="M15.5 15.5 21 21M10.5 7.8v5.4M7.8 10.5h5.4" />
  </svg>
);

export const IconZoomOut = (props: P) => (
  <svg {...base(props)}>
    <circle cx="10.5" cy="10.5" r="6.5" />
    <path d="M15.5 15.5 21 21M7.8 10.5h5.4" />
  </svg>
);

export const IconSplit = (props: P) => (
  <svg {...base(props)}>
    <path d="M3 6h7M3 12h4M3 18h7M14 6h7M17 12h4M14 18h7" />
    <path d="M12 3.5v17" strokeDasharray="2 2.5" />
  </svg>
);

export const IconSave = (props: P) => (
  <svg {...base(props)}>
    <path d="M4.5 4.5h11L19.5 8v11.5h-15z" />
    <path d="M8 4.5v5h6.5v-5M8 19.5v-5.5h8v5.5" />
  </svg>
);

export const IconChip = (props: P) => (
  <svg {...base(props)}>
    <rect x="7" y="7" width="10" height="10" rx="1.5" />
    <path d="M10 3.5v3M14 3.5v3M10 17.5v3M14 17.5v3M3.5 10h3M3.5 14h3M17.5 10h3M17.5 14h3" />
  </svg>
);

export const IconAlert = (props: P) => (
  <svg {...base(props)}>
    <path d="M12 3.8 21.2 20H2.8z" />
    <path d="M12 9.8v4.4M12 17.2v.01" />
  </svg>
);

export const IconInfo = (props: P) => (
  <svg {...base(props)}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 11v5.5M12 7.8v.01" />
  </svg>
);

export const IconCopy = (props: P) => (
  <svg {...base(props)}>
    <rect x="8.5" y="8.5" width="12" height="12" rx="1.6" />
    <path d="M15.5 5.5h-11a1 1 0 0 0-1 1v11" />
  </svg>
);

export const IconTerminal = (props: P) => (
  <svg {...base(props)}>
    <rect x="2.5" y="4.5" width="19" height="15" rx="2" />
    <path d="m6.5 9.5 3 2.8-3 2.8M12.5 15.5h5" />
  </svg>
);

export const IconChevron = (props: P) => (
  <svg {...base(props)}>
    <path d="m6.5 9.5 5.5 5.5 5.5-5.5" />
  </svg>
);

export const IconX = (props: P) => (
  <svg {...base(props)}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);

export const IconShield = (props: P) => (
  <svg {...base(props)}>
    <path d="M12 3 20 6v6c0 4.6-3.2 7.9-8 9-4.8-1.1-8-4.4-8-9V6z" />
    <path d="m8.8 12 2.3 2.3 4.1-4.6" />
  </svg>
);

export const IconLoop = (props: P) => (
  <svg {...base(props)}>
    <path d="M4 10.5A4.5 4.5 0 0 1 8.5 6H18M18 6l-2.8-2.8M18 6l-2.8 2.8" />
    <path d="M20 13.5a4.5 4.5 0 0 1-4.5 4.5H6M6 18l2.8 2.8M6 18l2.8-2.8" />
  </svg>
);

export const IconGrid = (props: P) => (
  <svg {...base(props)}>
    <path d="M3.5 3.5h7v7h-7zM13.5 3.5h7v7h-7zM3.5 13.5h7v7h-7zM13.5 13.5h7v7h-7z" />
  </svg>
);

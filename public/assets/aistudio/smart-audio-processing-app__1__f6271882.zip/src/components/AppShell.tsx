"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { IconAndroid, IconLibrary, IconMic, IconWand, IconWave, LogoMark } from "./icons";
import { Badge, Busy, ToastHost } from "./ui";
import { EqBars } from "./visuals";
import { useWorkspace } from "@/lib/store";
import { timecode } from "@/lib/audio/dsp";

const NAV = [
  { href: "/", label: "রেকর্ডার", sub: "Record", icon: IconMic },
  { href: "/editor", label: "এডিটর", sub: "Trim · Split", icon: IconWave },
  { href: "/effects", label: "ইফেক্টস", sub: "Enhance", icon: IconWand },
  { href: "/library", label: "লাইব্রেরি", sub: "Library", icon: IconLibrary },
  { href: "/apk", label: "APK গাইড", sub: "Build", icon: IconAndroid },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const title = useWorkspace((s) => s.title);
  const stats = useWorkspace((s) => s.stats);
  const status = useWorkspace((s) => s.status);
  const dirty = useWorkspace((s) => s.dirty);
  const busy = useWorkspace((s) => s.busy);
  const sampleRate = useWorkspace((s) => s.sampleRate);
  const hasProfile = useWorkspace((s) => s.noiseProfile !== null);

  return (
    <div className="relative z-10 flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 border-b border-ink-700/80 bg-ink-950/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1400px] items-center gap-4 px-4 py-2.5">
          <Link href="/" className="group flex items-center gap-2.5">
            <span className="relative flex h-9 w-9 items-center justify-center border border-signal/40 bg-gradient-to-br from-ink-800 to-ink-900">
              <LogoMark width={22} height={22} className="text-signal transition-transform group-hover:scale-110" />
              <span className="absolute -top-px -left-px h-1.5 w-1.5 bg-copper" />
              <span className="absolute -right-px -bottom-px h-1.5 w-1.5 bg-teal" />
            </span>
            <span className="leading-none">
              <span className="block font-display text-[15px] font-700 tracking-[0.14em] text-sand-50 uppercase">
                VoiceLab<span className="text-signal">·</span>Studio
              </span>
              <span className="mt-1 block font-mono text-[9.5px] tracking-[0.2em] text-sand-500 uppercase">
                noise-intelligence audio engine
              </span>
            </span>
          </Link>

          <nav className="ml-2 hidden flex-1 items-center gap-1 md:flex">
            {NAV.map((item) => {
              const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`group relative flex items-center gap-2 border px-3 py-1.5 transition-all ${
                    active
                      ? "border-signal/50 bg-signal/10 text-signal"
                      : "border-transparent text-sand-300 hover:border-ink-700 hover:bg-ink-850 hover:text-sand-50"
                  }`}
                >
                  <Icon width={15} height={15} />
                  <span className="font-display text-[12.5px] tracking-wide">{item.label}</span>
                  <span className="hidden font-mono text-[9px] tracking-[0.16em] text-sand-500 uppercase lg:inline">
                    {item.sub}
                  </span>
                  {active && <span className="absolute inset-x-2 -bottom-[3px] h-[2px] bg-signal" />}
                </Link>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-3">
            <div className="hidden items-center gap-2 border border-ink-700 bg-ink-900/70 px-2.5 py-1.5 sm:flex">
              <EqBars count={4} active={status !== "empty"} />
              <div className="leading-tight">
                <div className="max-w-[160px] truncate font-display text-[12px] text-sand-100">{title}</div>
                <div className="font-mono text-[9.5px] text-sand-500">
                  {stats ? timecode(stats.durationSec) : "00:00.00"} · {(sampleRate / 1000).toFixed(1)}kHz
                </div>
              </div>
              {dirty ? <Badge tone="signal">সেভ বাকি</Badge> : status !== "empty" ? <Badge tone="teal">লোডেড</Badge> : <Badge>খালি</Badge>}
            </div>
          </div>
        </div>

        <nav className="flex items-center gap-1 overflow-x-auto border-t border-ink-800 px-3 py-1.5 md:hidden">
          {NAV.map((item) => {
            const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex shrink-0 items-center gap-1.5 border px-2.5 py-1 font-display text-[12px] ${
                  active ? "border-signal/50 bg-signal/10 text-signal" : "border-ink-800 text-sand-300"
                }`}
              >
                <Icon width={14} height={14} />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </header>

      <main className="mx-auto w-full max-w-[1400px] flex-1 px-4 py-5">{children}</main>

      <footer className="border-t border-ink-800 bg-ink-950/80">
        <div className="mx-auto flex max-w-[1400px] flex-wrap items-center gap-x-5 gap-y-1 px-4 py-2.5 font-mono text-[10.5px] text-sand-500">
          <span className="text-sand-300">VoiceLab Studio</span>
          <span>Web Audio DSP · spectral subtraction</span>
          <span>
            নয়েজ প্রিন্ট:{" "}
            <span className={hasProfile ? "text-teal" : "text-sand-500"}>{hasProfile ? "শেখা আছে" : "নেই"}</span>
          </span>
          <span className="ml-auto hidden sm:inline">ড্র্যাগ = সিলেকশন · ক্লিক = সিক · ডাবল-ক্লিক = সিলেকশন বাতিল</span>
          <Link href="/apk" className="text-teal transition-colors hover:text-sand-50">
            APK বানানোর গাইড →
          </Link>
        </div>
      </footer>

      <ToastHost />
      {busy && <Busy label={busy} />}
    </div>
  );
}

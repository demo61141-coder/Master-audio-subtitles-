"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { clamp } from "@/lib/audio/dsp";
import { timecode } from "@/lib/audio/dsp";

/* ------------------------------------------------------- peak cacheing */

type PeakCache = { block: number; min: Float32Array; max: Float32Array };

function buildPeaks(samples: Float32Array, block = 128): PeakCache {
  const n = Math.max(1, Math.ceil(samples.length / block));
  const min = new Float32Array(n);
  const max = new Float32Array(n);
  for (let b = 0; b < n; b += 1) {
    const s = b * block;
    const e = Math.min(samples.length, s + block);
    let lo = 0;
    let hi = 0;
    for (let i = s; i < e; i += 1) {
      const v = samples[i];
      if (v < lo) lo = v;
      else if (v > hi) hi = v;
    }
    min[b] = lo;
    max[b] = hi;
  }
  return { block, min, max };
}

export type Region = { start: number; end: number; tone: "cut" | "chunk" | "noise" | "keep" };

/* ------------------------------------------------------------- Waveform */

export function Waveform({
  samples,
  sampleRate,
  height = 150,
  view,
  selection,
  onSelect,
  playhead,
  onSeek,
  regions = [],
  markers = [],
  showRuler = true,
  accent = "#ffa23a",
  label,
}: {
  samples: Float32Array | null;
  sampleRate: number;
  height?: number;
  view?: { start: number; end: number };
  selection?: { start: number; end: number } | null;
  onSelect?: (sel: { start: number; end: number } | null) => void;
  playhead?: number;
  onSeek?: (sec: number) => void;
  regions?: Region[];
  markers?: number[];
  showRuler?: boolean;
  accent?: string;
  label?: string;
}) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [width, setWidth] = useState(600);
  const dragRef = useRef<{ x0: number; moved: boolean } | null>(null);

  const total = samples ? samples.length / sampleRate : 0;
  const v = view ?? { start: 0, end: Math.max(total, 1) };
  const peaks = useMemo(() => (samples ? buildPeaks(samples, 128) : null), [samples]);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width ?? 600;
      setWidth(Math.max(120, Math.floor(w)));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const secToX = useCallback(
    (sec: number) => ((sec - v.start) / Math.max(1e-6, v.end - v.start)) * width,
    [v.start, v.end, width],
  );
  const xToSec = useCallback(
    (x: number) => v.start + (x / Math.max(1, width)) * (v.end - v.start),
    [v.start, v.end, width],
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !peaks) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const rulerH = showRuler ? 18 : 0;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor((height + rulerH) * dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height + rulerH}px`;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height + rulerH);

    // backdrop
    const bg = ctx.createLinearGradient(0, rulerH, 0, height + rulerH);
    bg.addColorStop(0, "#12161b");
    bg.addColorStop(0.5, "#0d1014");
    bg.addColorStop(1, "#12161b");
    ctx.fillStyle = bg;
    ctx.fillRect(0, rulerH, width, height);

    // centre line + dB guides
    const mid = rulerH + height / 2;
    ctx.strokeStyle = "rgba(255,255,255,0.07)";
    ctx.lineWidth = 1;
    for (const g of [0.25, 0.5, 0.75]) {
      ctx.beginPath();
      ctx.moveTo(0, rulerH + height * g);
      ctx.lineTo(width, rulerH + height * g);
      ctx.stroke();
    }

    // regions
    for (const r of regions) {
      const x0 = clamp(secToX(r.start), 0, width);
      const x1 = clamp(secToX(r.end), 0, width);
      if (x1 <= x0) continue;
      const tone =
        r.tone === "cut"
          ? "rgba(255,77,85,0.18)"
          : r.tone === "noise"
            ? "rgba(255,162,58,0.16)"
            : r.tone === "keep"
              ? "rgba(184,224,74,0.12)"
              : "rgba(47,212,196,0.14)";
      ctx.fillStyle = tone;
      ctx.fillRect(x0, rulerH, x1 - x0, height);
      ctx.strokeStyle = r.tone === "chunk" ? "rgba(47,212,196,0.55)" : "rgba(255,77,85,0.4)";
      ctx.beginPath();
      ctx.moveTo(x0, rulerH);
      ctx.lineTo(x0, rulerH + height);
      ctx.stroke();
    }

    // waveform
    const b0 = clamp(Math.floor((v.start * sampleRate) / peaks.block), 0, Math.max(0, peaks.min.length - 1));
    const b1 = clamp(Math.ceil((v.end * sampleRate) / peaks.block), b0, Math.max(0, peaks.min.length - 1));
    const grad = ctx.createLinearGradient(0, rulerH, 0, rulerH + height);
    grad.addColorStop(0, accent);
    grad.addColorStop(0.5, "#ffe0b0");
    grad.addColorStop(1, accent);
    ctx.fillStyle = grad;
    const perPx = Math.max(1, (b1 - b0) / Math.max(1, width));
    for (let x = 0; x < width; x += 1) {
      const from = b0 + Math.floor(x * perPx);
      const to = Math.min(b1, b0 + Math.floor((x + 1) * perPx));
      let lo = 0;
      let hi = 0;
      for (let b = from; b <= to; b += 1) {
        if (peaks.min[b] < lo) lo = peaks.min[b];
        if (peaks.max[b] > hi) hi = peaks.max[b];
      }
      const y1 = mid - hi * (height / 2 - 3);
      const y2 = mid - lo * (height / 2 - 3);
      ctx.globalAlpha = 0.92;
      ctx.fillRect(x, y1, 1, Math.max(1, y2 - y1));
    }
    ctx.globalAlpha = 1;

    // selection
    if (selection) {
      const x0 = clamp(secToX(selection.start), 0, width);
      const x1 = clamp(secToX(selection.end), 0, width);
      ctx.fillStyle = "rgba(47,212,196,0.14)";
      ctx.fillRect(x0, rulerH, x1 - x0, height);
      ctx.strokeStyle = "rgba(47,212,196,0.85)";
      ctx.lineWidth = 1;
      for (const x of [x0, x1]) {
        ctx.beginPath();
        ctx.moveTo(x, rulerH);
        ctx.lineTo(x, rulerH + height);
        ctx.stroke();
        ctx.fillStyle = "rgba(47,212,196,0.9)";
        ctx.fillRect(x - 2, rulerH + height / 2 - 9, 4, 18);
      }
    }

    // markers
    ctx.strokeStyle = "rgba(184,224,74,0.7)";
    for (const m of markers) {
      const x = secToX(m);
      if (x < 0 || x > width) continue;
      ctx.beginPath();
      ctx.moveTo(x, rulerH + height - 8);
      ctx.lineTo(x, rulerH + height);
      ctx.stroke();
    }

    // playhead
    if (playhead != null) {
      const x = secToX(playhead);
      if (x >= 0 && x <= width) {
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 1.4;
        ctx.shadowColor = "rgba(255,255,255,0.7)";
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.moveTo(x, rulerH);
        ctx.lineTo(x, rulerH + height);
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
    }

    // ruler
    if (showRuler) {
      ctx.fillStyle = "#0a0c0f";
      ctx.fillRect(0, 0, width, rulerH);
      ctx.strokeStyle = "rgba(255,255,255,0.08)";
      ctx.beginPath();
      ctx.moveTo(0, rulerH - 0.5);
      ctx.lineTo(width, rulerH - 0.5);
      ctx.stroke();
      const span = Math.max(0.001, v.end - v.start);
      const target = 8;
      const raw = span / target;
      const steps = [0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 15, 30, 60];
      const step = steps.find((s) => s >= raw) ?? 120;
      ctx.font = '9.5px "JetBrains Mono", monospace';
      ctx.fillStyle = "#7e786e";
      const first = Math.ceil(v.start / step) * step;
      for (let s = first; s <= v.end; s += step) {
        const x = secToX(s);
        ctx.strokeStyle = "rgba(255,255,255,0.14)";
        ctx.beginPath();
        ctx.moveTo(x, rulerH - 5);
        ctx.lineTo(x, rulerH);
        ctx.stroke();
        ctx.fillText(timecode(s, step < 1), x + 3, rulerH - 5);
      }
    }
  }, [peaks, width, height, v.start, v.end, sampleRate, selection, playhead, regions, markers, showRuler, accent, secToX]);

  if (!samples) {
    return (
      <div
        className="flex items-center justify-center border border-dashed border-ink-700 bg-ink-900/50 text-[12.5px] text-sand-500"
        style={{ height }}
      >
        কোনো অডিও লোড করা হয়নি
      </div>
    );
  }

  return (
    <div ref={wrapRef} className="relative w-full select-none">
      {label && <span className="label-xs absolute top-1 right-2 z-10">{label}</span>}
      <canvas
        ref={canvasRef}
        className="block w-full cursor-crosshair touch-none"
        onPointerDown={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          dragRef.current = { x0: e.clientX - rect.left, moved: false };
          e.currentTarget.setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          const d = dragRef.current;
          if (!d || !onSelect) return;
          const rect = e.currentTarget.getBoundingClientRect();
          const x = e.clientX - rect.left;
          if (Math.abs(x - d.x0) > 4) d.moved = true;
          if (d.moved) {
            const a = clamp(xToSec(Math.min(d.x0, x)), 0, total);
            const b = clamp(xToSec(Math.max(d.x0, x)), 0, total);
            onSelect({ start: a, end: b });
          }
        }}
        onPointerUp={(e) => {
          const d = dragRef.current;
          dragRef.current = null;
          if (!d) return;
          const rect = e.currentTarget.getBoundingClientRect();
          const x = e.clientX - rect.left;
          if (!d.moved && onSeek) onSeek(clamp(xToSec(x), 0, total));
          else if (d.moved && onSelect) {
            const a = clamp(xToSec(Math.min(d.x0, x)), 0, total);
            const b = clamp(xToSec(Math.max(d.x0, x)), 0, total);
            if (b - a < 0.02) onSelect(null);
            else onSelect({ start: a, end: b });
          }
        }}
        onDoubleClick={() => onSelect?.(null)}
      />
    </div>
  );
}

/* --------------------------------------------------------- SpectrumBars */

export function SpectrumBars({
  magnitudes,
  sampleRate,
  fftSize,
  height = 74,
  bars = 40,
  caption,
}: {
  magnitudes: Float32Array | number[] | null;
  sampleRate: number;
  fftSize: number;
  height?: number;
  bars?: number;
  caption?: string;
}) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const [width, setWidth] = useState(320);

  useEffect(() => {
    const el = ref.current?.parentElement;
    if (!el) return;
    const ro = new ResizeObserver((e) => setWidth(Math.max(80, Math.floor(e[0].contentRect.width))));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas || !magnitudes) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);
    const mags = Array.from(magnitudes as ArrayLike<number>);
    let peak = 1e-9;
    for (const m of mags) if (m > peak) peak = m;
    const bw = width / bars;
    for (let i = 0; i < bars; i += 1) {
      // log-spaced bins 60 Hz .. 12 kHz
      const f0 = 60 * Math.pow(200, i / bars);
      const f1 = 60 * Math.pow(200, (i + 1) / bars);
      const k0 = clamp(Math.floor((f0 * fftSize) / sampleRate), 0, mags.length - 1);
      const k1 = clamp(Math.ceil((f1 * fftSize) / sampleRate), k0 + 1, mags.length);
      let sum = 0;
      for (let k = k0; k < k1; k += 1) sum += mags[k];
      const avg = sum / Math.max(1, k1 - k0);
      const h = Math.max(1.5, (avg / peak) * (height - 12));
      const g = ctx.createLinearGradient(0, height, 0, height - h);
      g.addColorStop(0, "rgba(255,122,24,0.35)");
      g.addColorStop(1, "#ffc46b");
      ctx.fillStyle = g;
      ctx.fillRect(i * bw + 1, height - h, bw - 2, h);
    }
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.beginPath();
    ctx.moveTo(0, height - 0.5);
    ctx.lineTo(width, height - 0.5);
    ctx.stroke();
    ctx.font = '9px "JetBrains Mono", monospace';
    ctx.fillStyle = "#7e786e";
    const labels = [100, 500, 2000, 8000];
    for (const f of labels) {
      const x = (Math.log(f / 60) / Math.log(200)) * width;
      if (x > 6 && x < width - 20) ctx.fillText(f >= 1000 ? `${f / 1000}k` : `${f}`, x, 9);
    }
    if (caption) {
      ctx.fillStyle = "#b3aa9c";
      ctx.fillText(caption, 4, 9);
    }
  }, [magnitudes, width, height, bars, sampleRate, fftSize, caption]);

  return (
    <div className="w-full border border-ink-700/70 bg-ink-950/70 p-1">
      <canvas ref={ref} className="block" />
    </div>
  );
}

/* ------------------------------------------------------------ LevelBar */

export function LevelBar({
  db,
  peak,
  thresholdDb,
  gateOpen,
  segments = 34,
  showScale = true,
}: {
  db: number;
  peak: number;
  thresholdDb?: number;
  gateOpen?: boolean;
  segments?: number;
  showScale?: boolean;
}) {
  const MIN = -60;
  const idx = Math.round(((clamp(db, MIN, 0) - MIN) / -MIN) * segments);
  const peakIdx = Math.round(((clamp(peak, MIN, 0) - MIN) / -MIN) * segments);
  const gateIdx = thresholdDb != null ? Math.round(((clamp(thresholdDb, MIN, 0) - MIN) / -MIN) * segments) : null;
  return (
    <div>
      <div className="relative flex h-[14px] items-stretch gap-[2px]">
        {Array.from({ length: segments }).map((_, i) => {
          const on = i < idx;
          const isPeak = i === peakIdx - 1;
          const color = i > segments * 0.9 ? "#ff4d55" : i > segments * 0.72 ? "#ffa23a" : "#2fd4c4";
          return (
            <span
              key={i}
              className="flex-1 transition-all duration-75"
              style={{
                background: on || isPeak ? color : "#1b2027",
                boxShadow: on ? `0 0 8px ${color}66` : "none",
                opacity: isPeak && !on ? 0.9 : 1,
              }}
            />
          );
        })}
        {gateIdx != null && (
          <span
            className="absolute top-[-3px] bottom-[-3px] w-[2px] bg-lime"
            style={{ left: `${(gateIdx / segments) * 100}%` }}
            title={`গেট থ্রেশহোল্ড ${thresholdDb} dB`}
          />
        )}
      </div>
      {showScale && (
        <div className="mt-1 flex justify-between font-mono text-[9.5px] text-sand-500">
          <span>-60</span>
          <span className={gateOpen == null ? "" : gateOpen ? "text-lime" : "text-rec"}>
            {gateOpen == null ? "-30" : gateOpen ? "গেট খোলা" : "সাইলেন্স স্কিপ"}
          </span>
          <span>-12</span>
          <span>0 dB</span>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------ LiveScope */

export type ScopeBuffer = { data: Float32Array; idx: number };

export function makeScope(size = 8192): ScopeBuffer {
  return { data: new Float32Array(size), idx: 0 };
}

export function pushScope(scope: ScopeBuffer, chunk: Float32Array) {
  const n = scope.data.length;
  for (let i = 0; i < chunk.length; i += 1) {
    scope.data[scope.idx % n] = chunk[i];
    scope.idx += 1;
  }
}

export function LiveScope({
  scope,
  active,
  height = 96,
  color = "#ffa23a",
}: {
  scope: React.RefObject<ScopeBuffer | null>;
  active: boolean;
  height?: number;
  color?: string;
}) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const [width, setWidth] = useState(480);
  const raf = useRef<number>(0);

  useEffect(() => {
    const el = ref.current?.parentElement;
    if (!el) return;
    const ro = new ResizeObserver((e) => setWidth(Math.max(120, Math.floor(e[0].contentRect.width))));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const draw = () => {
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      if (canvas.width !== Math.floor(width * dpr)) {
        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(height * dpr);
        canvas.style.width = `${width}px`;
        canvas.style.height = `${height}px`;
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, width, height);
      const bg = ctx.createLinearGradient(0, 0, 0, height);
      bg.addColorStop(0, "#101317");
      bg.addColorStop(1, "#0a0c0f");
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);
      ctx.strokeStyle = "rgba(255,255,255,0.05)";
      ctx.beginPath();
      ctx.moveTo(0, height / 2);
      ctx.lineTo(width, height / 2);
      ctx.stroke();

      const buf = scope.current;
      if (buf) {
        const n = buf.data.length;
        ctx.strokeStyle = active ? color : "rgba(255,162,58,0.4)";
        ctx.lineWidth = 1.2;
        ctx.shadowColor = active ? "rgba(255,140,40,0.6)" : "transparent";
        ctx.shadowBlur = active ? 8 : 0;
        ctx.beginPath();
        for (let x = 0; x < width; x += 1) {
          const i = (buf.idx - width + x + n * 2) % n;
          const v = buf.data[i] ?? 0;
          const y = height / 2 - v * (height / 2 - 4);
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
      raf.current = requestAnimationFrame(draw);
    };
    raf.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf.current);
  }, [scope, active, width, height, color]);

  return (
    <div className="w-full overflow-hidden border border-ink-700/70">
      <canvas ref={ref} className="block" />
    </div>
  );
}

/* -------------------------------------------------------------- EqBars */

export function EqBars({ count = 5, active = true, className = "" }: { count?: number; active?: boolean; className?: string }) {
  return (
    <span className={`inline-flex h-4 items-end gap-[2px] ${className}`}>
      {Array.from({ length: count }).map((_, i) => (
        <span
          key={i}
          className="eq-bar w-[2px] bg-signal/80"
          style={{ height: "100%", animationDelay: `${i * 0.14}s`, animationPlayState: active ? "running" : "paused" }}
        />
      ))}
    </span>
  );
}

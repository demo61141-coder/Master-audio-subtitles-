import { encodeWav } from "@/lib/audio/wav";
import type {
  NoisePrintRecord,
  PresetConfigRecord,
  RecorderSettingsRecord,
  StatsRecord,
} from "@/db/schema";

export type AssetSummary = {
  id: string;
  kind: string;
  label: string;
  mime: string;
  durationSec: number;
  bytes: number;
  startSec: number | null;
  endSec: number | null;
  createdAt: string;
};

export type LogEntry = {
  id: string;
  projectId: string | null;
  operation: string;
  label: string;
  params: Record<string, unknown> | null;
  result: Record<string, unknown> | null;
  durationMs: number;
  createdAt: string;
};

export type ProjectSummary = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  durationSec: number;
  sampleRate: number;
  channels: number;
  status: string;
  source: string;
  tags: string[];
  version: number;
  noisePrint: NoisePrintRecord | null;
  settings: RecorderSettingsRecord | null;
  stats: StatsRecord | null;
  assets: AssetSummary[];
};

export type PresetRow = {
  id: string;
  name: string;
  category: string;
  description: string | null;
  builtin: boolean;
  config: PresetConfigRecord;
  createdAt: string;
};

export type DashboardStats = {
  projects: number;
  audioSeconds: number;
  silenceRemovedSec: number;
  chunks: number;
  operations: number;
  storageBytes: number;
};

async function json<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `রিকোয়েস্ট ব্যর্থ (${res.status})`);
  }
  return (await res.json()) as T;
}

export const api = {
  listProjects: () => fetch("/api/projects", { cache: "no-store" }).then((r) => json<ProjectSummary[]>(r)),

  createProject: (payload: {
    title: string;
    durationSec: number;
    sampleRate: number;
    channels?: number;
    status?: string;
    source?: string;
    noisePrint?: NoisePrintRecord | null;
    settings?: RecorderSettingsRecord | null;
    stats?: StatsRecord | null;
  }) =>
    fetch("/api/projects", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    }).then((r) => json<ProjectSummary>(r)),

  updateProject: (id: string, patch: Partial<Omit<ProjectSummary, "id" | "assets">>) =>
    fetch(`/api/projects/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(patch),
    }).then((r) => json<ProjectSummary>(r)),

  deleteProject: (id: string) => fetch(`/api/projects/${id}`, { method: "DELETE" }).then((r) => json<{ ok: boolean }>(r)),

  listLogs: (projectId?: string) =>
    fetch(`/api/logs${projectId ? `?projectId=${projectId}` : ""}`, { cache: "no-store" }).then((r) =>
      json<LogEntry[]>(r),
    ),

  addLog: (payload: {
    projectId?: string | null;
    operation: string;
    label?: string;
    params?: Record<string, unknown>;
    result?: Record<string, unknown>;
    durationMs?: number;
  }) =>
    fetch("/api/logs", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    }).then((r) => json<LogEntry>(r)),

  listPresets: () => fetch("/api/presets", { cache: "no-store" }).then((r) => json<PresetRow[]>(r)),

  savePreset: (payload: { name: string; category?: string; description?: string; config: EnhanceLike }) =>
    fetch("/api/presets", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    }).then((r) => json<PresetRow>(r)),

  deletePreset: (id: string) => fetch(`/api/presets/${id}`, { method: "DELETE" }).then((r) => json<{ ok: boolean }>(r)),

  dashboard: () => fetch("/api/stats", { cache: "no-store" }).then((r) => json<DashboardStats>(r)),

  uploadAudio: async (
    projectId: string,
    input: { kind: string; label: string; samples: Float32Array; sampleRate: number; startSec?: number; endSec?: number },
  ) => {
    const bytes = encodeWav(input.samples, input.sampleRate, 16);
    const blob = new Blob([bytes.buffer as ArrayBuffer], { type: "audio/wav" });
    const form = new FormData();
    form.set("kind", input.kind);
    form.set("label", input.label);
    form.set("durationSec", String(input.samples.length / input.sampleRate));
    if (input.startSec != null) form.set("startSec", String(input.startSec));
    if (input.endSec != null) form.set("endSec", String(input.endSec));
    form.set("file", blob, `${input.label || input.kind}.wav`);
    return fetch(`/api/projects/${projectId}/audio`, { method: "POST", body: form }).then((r) =>
      json<AssetSummary>(r),
    );
  },

  fetchAudio: async (projectId: string, assetId: string) => {
    const res = await fetch(`/api/projects/${projectId}/audio/${assetId}`, { cache: "no-store" });
    if (!res.ok) throw new Error("অডিও লোড করা যায়নি");
    return await res.arrayBuffer();
  },

  deleteAudio: (projectId: string, assetId: string) =>
    fetch(`/api/projects/${projectId}/audio/${assetId}`, { method: "DELETE" }).then((r) => json<{ ok: boolean }>(r)),

  audioUrl: (projectId: string, assetId: string) => `/api/projects/${projectId}/audio/${assetId}`,
};

export type EnhanceLike = PresetConfigRecord;

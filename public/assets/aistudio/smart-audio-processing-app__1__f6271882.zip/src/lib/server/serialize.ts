import type { AssetSummary, LogEntry, PresetRow, ProjectSummary } from "@/lib/api";

type AssetRow = {
  id: string;
  kind: string;
  label: string;
  mime: string;
  durationSec: number;
  bytes: number;
  startSec: number | null;
  endSec: number | null;
  createdAt: Date;
};

type ProjectRow = {
  id: string;
  title: string;
  createdAt: Date;
  updatedAt: Date;
  durationSec: number;
  sampleRate: number;
  channels: number;
  status: string;
  source: string;
  tags: string[];
  version: number;
  noisePrint: unknown;
  settings: unknown;
  stats: unknown;
};

export function serializeProject(row: ProjectRow, assets: AssetSummary[]): ProjectSummary {
  return {
    id: row.id,
    title: row.title,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    durationSec: row.durationSec,
    sampleRate: row.sampleRate,
    channels: row.channels,
    status: row.status,
    source: row.source,
    tags: row.tags ?? [],
    version: row.version,
    noisePrint: (row.noisePrint ?? null) as ProjectSummary["noisePrint"],
    settings: (row.settings ?? null) as ProjectSummary["settings"],
    stats: (row.stats ?? null) as ProjectSummary["stats"],
    assets,
  };
}

export function serializeAsset(row: AssetRow): AssetSummary {
  return {
    id: row.id,
    kind: row.kind,
    label: row.label,
    mime: row.mime,
    durationSec: row.durationSec,
    bytes: row.bytes,
    startSec: row.startSec,
    endSec: row.endSec,
    createdAt: row.createdAt.toISOString(),
  };
}

type LogRow = {
  id: string;
  projectId: string | null;
  operation: string;
  label: string;
  params: unknown;
  result: unknown;
  durationMs: number;
  createdAt: Date;
};

export function serializeLog(row: LogRow): LogEntry {
  return {
    id: row.id,
    projectId: row.projectId,
    operation: row.operation,
    label: row.label,
    params: (row.params ?? null) as Record<string, unknown> | null,
    result: (row.result ?? null) as Record<string, unknown> | null,
    durationMs: row.durationMs,
    createdAt: row.createdAt.toISOString(),
  };
}

type PresetDbRow = {
  id: string;
  name: string;
  category: string;
  description: string | null;
  builtin: boolean;
  config: unknown;
  createdAt: Date;
};

export function serializePreset(row: PresetDbRow): PresetRow {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    description: row.description,
    builtin: row.builtin,
    config: row.config as PresetRow["config"],
    createdAt: row.createdAt.toISOString(),
  };
}

export const MAX_AUDIO_BYTES = 24 * 1024 * 1024;

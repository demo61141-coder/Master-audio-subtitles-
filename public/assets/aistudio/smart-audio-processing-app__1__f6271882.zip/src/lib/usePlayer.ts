import { useCallback, useEffect, useRef, useState } from "react";
import { audioContext } from "@/lib/audio/wav";
import { clamp } from "@/lib/audio/dsp";

export type Player = {
  playing: boolean;
  position: number;
  duration: number;
  loop: boolean;
  setLoop: (v: boolean) => void;
  play: (from?: number, to?: number) => void;
  pause: () => void;
  stop: () => void;
  seek: (sec: number) => void;
};

/** Shared-context sample player with selection looping and rAF position updates. */
export function usePlayer(samples: Float32Array | null, sampleRate: number): Player {
  const [playing, setPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [loop, setLoop] = useState(false);

  const bufferRef = useRef<AudioBuffer | null>(null);
  const bufferSrc = useRef<Float32Array | null>(null);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);
  const gainRef = useRef<GainNode | null>(null);
  const startedAt = useRef(0);
  const offset = useRef(0);
  const rangeEnd = useRef(0);
  const rangeStart = useRef(0);
  const raf = useRef<number>(0);
  const loopRef = useRef(false);
  const duration = samples ? samples.length / sampleRate : 0;

  loopRef.current = loop;

  const durationRef = useRef(0);
  durationRef.current = duration;

  const ensureBuffer = useCallback(() => {
    if (!samples) return null;
    if (bufferRef.current && bufferSrc.current === samples) return bufferRef.current;
    const ctx = audioContext();
    const buf = ctx.createBuffer(1, Math.max(1, samples.length), sampleRate);
    const copy = new Float32Array(samples.length);
    copy.set(samples);
    buf.copyToChannel(copy, 0);
    bufferRef.current = buf;
    bufferSrc.current = samples;
    return buf;
  }, [samples, sampleRate]);

  const teardown = useCallback(() => {
    cancelAnimationFrame(raf.current);
    if (sourceRef.current) {
      sourceRef.current.onended = null;
      try {
        sourceRef.current.stop();
      } catch {
        /* already stopped */
      }
      sourceRef.current.disconnect();
      sourceRef.current = null;
    }
  }, []);

  const stop = useCallback(() => {
    teardown();
    setPlaying(false);
    setPosition(0);
    offset.current = 0;
  }, [teardown]);

  const playRangeRef = useRef<(from: number, to: number) => void>(() => undefined);

  const tick = useCallback(() => {
    const ctx = audioContext();
    const pos = offset.current + (ctx.currentTime - startedAt.current);
    if (pos >= rangeEnd.current) {
      if (loopRef.current && rangeEnd.current > rangeStart.current) {
        playRangeRef.current(rangeStart.current, rangeEnd.current);
        return;
      }
      teardown();
      setPlaying(false);
      setPosition(rangeEnd.current);
      offset.current = rangeEnd.current;
      return;
    }
    setPosition(pos);
    raf.current = requestAnimationFrame(tick);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [teardown]);

  const playRangeInternal = useCallback(
    (from: number, to: number) => {
      const buf = ensureBuffer();
      if (!buf) return;
      const ctx = audioContext();
      teardown();
      const src = ctx.createBufferSource();
      src.buffer = buf;
      if (!gainRef.current) {
        gainRef.current = ctx.createGain();
        gainRef.current.gain.value = 1;
        gainRef.current.connect(ctx.destination);
      }
      src.connect(gainRef.current);
      const start = clamp(from, 0, durationRef.current);
      const end = clamp(to > start ? to : durationRef.current, start, durationRef.current);
      rangeStart.current = start;
      rangeEnd.current = end;
      offset.current = start;
      src.start(0, start, Math.max(0.01, end - start));
      startedAt.current = ctx.currentTime;
      sourceRef.current = src;
      src.onended = () => {
        if (sourceRef.current === src) {
          teardown();
          setPlaying(false);
          setPosition(rangeEnd.current);
        }
      };
      setPlaying(true);
      cancelAnimationFrame(raf.current);
      raf.current = requestAnimationFrame(tick);
    },
    [ensureBuffer, teardown, tick],
  );

  playRangeRef.current = playRangeInternal;

  const play = useCallback(
    (from = 0, to?: number) => playRangeInternal(from, to ?? durationRef.current),
    [playRangeInternal],
  );

  const pause = useCallback(() => {
    if (!playing) return;
    const ctx = audioContext();
    offset.current = clamp(offset.current + (ctx.currentTime - startedAt.current), 0, durationRef.current);
    teardown();
    setPlaying(false);
    setPosition(offset.current);
  }, [playing, teardown]);

  const seek = useCallback(
    (sec: number) => {
      const s = clamp(sec, 0, durationRef.current);
      offset.current = s;
      setPosition(s);
      if (playing) playRangeInternal(s, rangeEnd.current > s ? rangeEnd.current : durationRef.current);
    },
    [playing, playRangeInternal],
  );

  // buffer invalidation whenever the audio changes
  useEffect(() => {
    bufferRef.current = null;
    teardown();
    setPlaying(false);
    setPosition(0);
    offset.current = 0;
  }, [samples, teardown]);

  useEffect(() => () => teardown(), [teardown]);

  return { playing, position, duration, loop, setLoop, play, pause, stop, seek };
}

import { analyze, generateDemoAudio, serializeNoiseProfile, type NoiseProfile } from "@/lib/audio/dsp";
import { decodeToMono, downloadBlob, wavBlob } from "@/lib/audio/wav";
import { api } from "@/lib/api";
import { useWorkspace } from "@/lib/store";

export async function loadDemoIntoWorkspace(seconds = 26): Promise<void> {
  const ws = useWorkspace.getState();
  ws.setBusy(`ডেমো অডিও তৈরি হচ্ছে (${seconds}s)…`);
  await new Promise((r) => setTimeout(r, 30));
  const { samples } = generateDemoAudio(seconds, 44100, { noiseDb: -33 });
  ws.loadAudio({
    samples,
    sampleRate: 44100,
    title: "ডেমো — ফ্যান নয়েজ সহ কণ্ঠ",
    status: "raw",
    keepOriginal: false,
  });
  ws.setBusy(null);
  ws.notify("ডেমো অডিও লোড হয়েছে — ফ্যান/AC নয়েজ ও ৪টি লম্বা সাইলেন্ট গ্যাপ আছে।", "ok");
}

export async function importFileIntoWorkspace(file: File): Promise<void> {
  const ws = useWorkspace.getState();
  ws.setBusy("ফাইল ডিকোড হচ্ছে…");
  try {
    const { samples, sampleRate } = await decodeToMono(file);
    ws.loadAudio({
      samples,
      sampleRate,
      title: file.name.replace(/\.[^.]+$/, "").slice(0, 80) || "ইমপোর্টেড অডিও",
      status: "raw",
      keepOriginal: false,
    });
    ws.notify(`ইমপোর্ট সফল — ${(samples.length / sampleRate).toFixed(1)} সেকেন্ড, ${(sampleRate / 1000).toFixed(1)} kHz`);
  } catch {
    ws.notify("ফাইল ডিকোড করা যায়নি — WAV/MP3/M4A/OGG দিন।", "err");
  } finally {
    ws.setBusy(null);
  }
}

export type PersistInput = {
  samples: Float32Array;
  sampleRate: number;
  title: string;
  status: "raw" | "cleaned" | "enhanced";
  projectId?: string | null;
  noiseProfile?: NoiseProfile | null;
  kind?: string;
  label?: string;
  source?: string;
};

/** Creates/updates the project row, uploads the WAV and writes a processing log. */
export async function persistToServer(input: PersistInput): Promise<{ projectId: string; assetId: string } | null> {
  const ws = useWorkspace.getState();
  const stats = analyze(input.samples, input.sampleRate);
  const settings = {
    gateEnabled: ws.gate.enabled,
    gateThresholdDb: ws.gate.thresholdDb,
    gateHoldSec: ws.gate.holdSec,
    liveSuppress: ws.liveSuppress,
    suppressStrength: ws.suppress.strength,
    autoClean: ws.autoClean,
    profileSec: ws.profileSec,
  };

  try {
    let projectId = input.projectId ?? null;
    if (projectId) {
      await api.updateProject(projectId, {
        title: input.title,
        status: input.status,
        durationSec: stats.durationSec,
        sampleRate: input.sampleRate,
        stats: {
          peakDb: stats.peakDb,
          rmsDb: stats.rmsDb,
          dynamicRangeDb: stats.dynamicRangeDb,
          silenceSec: stats.silenceSec,
          skippedSec: ws.stats?.silenceSec ?? 0,
          chunks: 0,
          clipped: stats.clipped,
        },
        noisePrint: input.noiseProfile ? serializeNoiseProfile(input.noiseProfile) : undefined,
        settings,
      });
    } else {
      const created = await api.createProject({
        title: input.title,
        durationSec: stats.durationSec,
        sampleRate: input.sampleRate,
        status: input.status,
        source: input.source ?? "mic",
        noisePrint: input.noiseProfile ? serializeNoiseProfile(input.noiseProfile) : null,
        settings,
        stats: {
          peakDb: stats.peakDb,
          rmsDb: stats.rmsDb,
          dynamicRangeDb: stats.dynamicRangeDb,
          silenceSec: stats.silenceSec,
          skippedSec: 0,
          chunks: 0,
          clipped: stats.clipped,
        },
      });
      projectId = created.id;
    }

    const asset = await api.uploadAudio(projectId, {
      kind: input.kind ?? "processed",
      label: input.label ?? `${input.status === "enhanced" ? "এনহ্যান্সড" : input.status === "cleaned" ? "ক্লিনড" : "র"} মাস্টার`,
      samples: input.samples,
      sampleRate: input.sampleRate,
    });
    ws.setProjectId(projectId);
    return { projectId, assetId: asset.id };
  } catch (e) {
    ws.notify(e instanceof Error ? e.message : "সার্ভারে সেভ করা যায়নি", "err");
    return null;
  }
}

export function exportLocal(
  samples: Float32Array,
  sampleRate: number,
  filename: string,
  bitDepth: 16 | 24 = 16,
): void {
  downloadBlob(wavBlob(samples, sampleRate, bitDepth), filename);
}

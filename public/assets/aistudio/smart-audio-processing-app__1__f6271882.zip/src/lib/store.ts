import { create } from "zustand";
import { persist } from "zustand/middleware";
import { analyze, type Analysis, type NoiseProfile, type NoiseReduceOptions } from "@/lib/audio/dsp";
import { enhancePresets, type EnhanceConfig } from "@/lib/audio/enhance";
import type { GateSettings } from "@/lib/audio/recorder";

export type Toast = { id: number; text: string; tone: "ok" | "warn" | "err" };

export type WorkspaceState = {
  projectId: string | null;
  title: string;
  samples: Float32Array | null;
  sampleRate: number;
  original: Float32Array | null;
  status: "raw" | "cleaned" | "enhanced" | "empty";
  dirty: boolean;
  past: { samples: Float32Array; label: string }[];
  future: { samples: Float32Array; label: string }[];
  noiseProfile: NoiseProfile | null;
  noiseProfileRaw: Float32Array | null;
  stats: Analysis | null;
  presetId: string;
  enhance: EnhanceConfig;
  lastOperation: string | null;
  busy: string | null;
  toast: Toast | null;

  // recorder settings (persisted)
  gate: GateSettings;
  liveSuppress: boolean;
  suppress: NoiseReduceOptions;
  profileSec: number;
  autoClean: boolean;
  autoLevel: boolean;

  loadAudio: (input: {
    samples: Float32Array;
    sampleRate: number;
    title?: string;
    projectId?: string | null;
    status?: WorkspaceState["status"];
    keepOriginal?: boolean;
  }) => void;
  setAudio: (samples: Float32Array, label: string) => void;
  undo: () => void;
  redo: () => void;
  resetHistory: () => void;
  setTitle: (title: string) => void;
  setProjectId: (id: string | null) => void;
  setStatus: (status: WorkspaceState["status"]) => void;
  setDirty: (dirty: boolean) => void;
  setNoiseProfile: (profile: NoiseProfile | null, raw?: Float32Array | null) => void;
  setPresetId: (id: string) => void;
  setEnhance: (patch: Partial<EnhanceConfig>) => void;
  resetEnhance: () => void;
  setGate: (patch: Partial<GateSettings>) => void;
  setLiveSuppress: (v: boolean) => void;
  setSuppress: (patch: Partial<NoiseReduceOptions>) => void;
  setProfileSec: (v: number) => void;
  setAutoClean: (v: boolean) => void;
  setAutoLevel: (v: boolean) => void;
  setBusy: (label: string | null) => void;
  setLastOperation: (label: string | null) => void;
  notify: (text: string, tone?: Toast["tone"]) => void;
  clearToast: () => void;
  clearWorkspace: () => void;
};

const MAX_HISTORY = 12;

export const useWorkspace = create<WorkspaceState>()(
  persist(
    (set, get) => ({
      projectId: null,
      title: "নতুন রেকর্ডিং",
      samples: null,
      sampleRate: 44100,
      original: null,
      status: "empty",
      dirty: false,
      past: [],
      future: [],
      noiseProfile: null,
      noiseProfileRaw: null,
      stats: null,
      presetId: "podcast-studio",
      enhance: { ...enhancePresets[0].config },
      lastOperation: null,
      busy: null,
      toast: null,

      gate: { enabled: true, thresholdDb: -45, holdSec: 2 },
      liveSuppress: false,
      suppress: { strength: 2, floorDb: -32, smoothing: 0.6 },
      profileSec: 4,
      autoClean: true,
      autoLevel: true,

      loadAudio: ({ samples, sampleRate, title, projectId, status, keepOriginal }) => {
        const original = keepOriginal ? get().original : samples;
        set({
          samples,
          sampleRate,
          original: original ?? samples,
          title: title ?? get().title,
          projectId: projectId ?? get().projectId,
          status: status ?? "raw",
          stats: analyze(samples, sampleRate),
          past: [],
          future: [],
          dirty: false,
        });
      },

      setAudio: (samples, label) => {
        const { past, sampleRate, samples: current } = get();
        if (!current) {
          set({ samples, stats: analyze(samples, sampleRate), dirty: true });
          return;
        }
        const nextPast = [...past, { samples: current, label }].slice(-MAX_HISTORY);
        set({
          samples,
          past: nextPast,
          future: [],
          stats: analyze(samples, sampleRate),
          dirty: true,
        });
      },

      undo: () => {
        const { past, future, samples, sampleRate } = get();
        if (!samples || !past.length) return;
        const prev = past[past.length - 1];
        set({
          samples: prev.samples,
          past: past.slice(0, -1),
          future: [{ samples, label: prev.label }, ...future].slice(0, MAX_HISTORY),
          stats: analyze(prev.samples, sampleRate),
          dirty: true,
        });
      },

      redo: () => {
        const { past, future, samples, sampleRate } = get();
        if (!samples || !future.length) return;
        const next = future[0];
        set({
          samples: next.samples,
          past: [...past, { samples, label: next.label }].slice(-MAX_HISTORY),
          future: future.slice(1),
          stats: analyze(next.samples, sampleRate),
          dirty: true,
        });
      },

      resetHistory: () => set({ past: [], future: [] }),

      setTitle: (title) => set({ title }),
      setProjectId: (projectId) => set({ projectId }),
      setStatus: (status) => set({ status }),
      setDirty: (dirty) => set({ dirty }),
      setNoiseProfile: (profile, raw = null) =>
        set({ noiseProfile: profile, noiseProfileRaw: raw ?? get().noiseProfileRaw }),
      setPresetId: (id) => {
        const preset = enhancePresets.find((p) => p.id === id);
        if (preset) set({ presetId: id, enhance: { ...preset.config } });
      },
      setEnhance: (patch) => set({ enhance: { ...get().enhance, ...patch }, presetId: "custom" }),
      resetEnhance: () => {
        const preset = enhancePresets.find((p) => p.id === get().presetId) ?? enhancePresets[0];
        set({ enhance: { ...preset.config }, presetId: preset.id });
      },
      setGate: (patch) => set({ gate: { ...get().gate, ...patch } }),
      setLiveSuppress: (liveSuppress) => set({ liveSuppress }),
      setSuppress: (patch) => set({ suppress: { ...get().suppress, ...patch } }),
      setProfileSec: (profileSec) => set({ profileSec }),
      setAutoClean: (autoClean) => set({ autoClean }),
      setAutoLevel: (autoLevel) => set({ autoLevel }),
      setBusy: (busy) => set({ busy }),
      setLastOperation: (lastOperation) => set({ lastOperation }),
      notify: (text, tone = "ok") => set({ toast: { id: Date.now(), text, tone } }),
      clearToast: () => set({ toast: null }),
      clearWorkspace: () =>
        set({
          samples: null,
          original: null,
          projectId: null,
          stats: null,
          status: "empty",
          dirty: false,
          past: [],
          future: [],
          title: "নতুন রেকর্ডিং",
        }),
    }),
    {
      name: "voicelab-settings",
      version: 1,
      partialize: (s) => ({
        gate: s.gate,
        liveSuppress: s.liveSuppress,
        suppress: s.suppress,
        profileSec: s.profileSec,
        autoClean: s.autoClean,
        autoLevel: s.autoLevel,
        presetId: s.presetId,
        enhance: s.enhance,
      }),
    },
  ),
);

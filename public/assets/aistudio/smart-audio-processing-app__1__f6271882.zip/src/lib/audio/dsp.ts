import { FFT, hannWindow, sqrtHannWindow } from "./fft";

export type Range = { start: number; end: number };

export type NoiseProfile = {
  sampleRate: number;
  fftSize: number;
  learnedSec: number;
  avgDb: number;
  peakDb: number;
  /** average magnitude per bin */
  magnitudes: Float32Array;
  /** minimum magnitude per bin (true noise floor) */
  floor: Float32Array;
};

export type NoiseReduceOptions = {
  /** oversubtraction factor 1 (gentle) .. 4 (aggressive) */
  strength: number;
  /** maximum attenuation in dB (negative), e.g. -36 */
  floorDb: number;
  /** temporal gain smoothing 0..0.95 – kills "musical noise" */
  smoothing: number;
};

export const defaultNoiseOptions: NoiseReduceOptions = {
  strength: 2,
  floorDb: -32,
  smoothing: 0.6,
};

export const linToDb = (v: number): number => (v <= 1e-9 ? -180 : 20 * Math.log10(v));
export const dbToLin = (db: number): number => Math.pow(10, db / 20);
export const clamp = (v: number, lo: number, hi: number): number => Math.min(hi, Math.max(lo, v));

export function peakLevel(samples: Float32Array): number {
  let peak = 0;
  for (let i = 0; i < samples.length; i += 1) {
    const a = Math.abs(samples[i]);
    if (a > peak) peak = a;
  }
  return peak;
}

export function rmsLevel(samples: Float32Array): number {
  if (!samples.length) return 0;
  let sum = 0;
  for (let i = 0; i < samples.length; i += 1) sum += samples[i] * samples[i];
  return Math.sqrt(sum / samples.length);
}

export const peakDb = (samples: Float32Array): number => linToDb(peakLevel(samples));
export const rmsDb = (samples: Float32Array): number => linToDb(rmsLevel(samples));

/** Block RMS envelope in dB. Returns per-hop values plus the hop duration. */
export function envelopeDb(
  samples: Float32Array,
  sampleRate: number,
  hopMs = 10,
): { values: Float32Array; hopSec: number } {
  const hop = Math.max(64, Math.round((sampleRate * hopMs) / 1000));
  const count = Math.max(1, Math.ceil(samples.length / hop));
  const values = new Float32Array(count);
  const win = hannWindow(hop);
  for (let b = 0; b < count; b += 1) {
    const off = b * hop;
    let sum = 0;
    let n = 0;
    for (let i = 0; i < hop; i += 1) {
      const idx = off + i;
      if (idx >= samples.length) break;
      const v = samples[idx];
      sum += v * v;
      n += 1;
    }
    values[b] = n ? linToDb(Math.sqrt(sum / n)) : -180;
  }
  return { values, hopSec: hop / sampleRate };
}

/* ------------------------------------------------------------------ */
/* Noise profile learning                                              */
/* ------------------------------------------------------------------ */

export function learnNoiseProfile(
  samples: Float32Array,
  sampleRate: number,
  fftSize = 2048,
): NoiseProfile {
  const n = fftSize;
  const hop = n >> 1;
  const bins = n >> 1;
  const fft = new FFT(n);
  const win = sqrtHannWindow(n);
  const re = new Float32Array(n);
  const im = new Float32Array(n);
  const sum = new Float32Array(bins + 1);
  const min = new Float32Array(bins + 1).fill(Infinity);
  let frames = 0;

  if (samples.length < n) {
    const padded = new Float32Array(n);
    padded.set(samples.subarray(0, Math.min(samples.length, n)));
    samples = padded;
  }

  for (let pos = 0; pos + n <= samples.length; pos += hop) {
    for (let i = 0; i < n; i += 1) {
      re[i] = samples[pos + i] * win[i];
      im[i] = 0;
    }
    fft.forward(re, im);
    for (let k = 0; k <= bins; k += 1) {
      const mag = Math.hypot(re[k], im[k]);
      sum[k] += mag;
      if (mag < min[k]) min[k] = mag;
    }
    frames += 1;
  }

  if (!frames) frames = 1;
  const magnitudes = new Float32Array(bins + 1);
  const floor = new Float32Array(bins + 1);
  for (let k = 0; k <= bins; k += 1) {
    const avg = sum[k] / frames;
    // 3-bin spectral smoothing stabilises the estimate against random noise
    const prev = k > 0 ? sum[k - 1] / frames : avg;
    const next = k < bins ? sum[k + 1] / frames : avg;
    magnitudes[k] = (prev + avg * 2 + next) / 4;
    floor[k] = Number.isFinite(min[k]) ? min[k] : 0;
  }

  return {
    sampleRate,
    fftSize: n,
    learnedSec: samples.length / sampleRate,
    avgDb: rmsDb(samples),
    peakDb: peakDb(samples),
    magnitudes,
    floor,
  };
}

export type SerializedNoiseProfile = {
  sampleRate: number;
  fftSize: number;
  learnedSec: number;
  avgDb: number;
  peakDb: number;
  magnitudes: number[];
};

export function serializeNoiseProfile(p: NoiseProfile): SerializedNoiseProfile {
  // keep every 2nd bin to shrink the payload – the curve is smooth anyway
  const step = 2;
  const mags: number[] = [];
  for (let k = 0; k < p.magnitudes.length; k += step) {
    mags.push(Number(p.magnitudes[k].toPrecision(4)));
  }
  return {
    sampleRate: p.sampleRate,
    fftSize: p.fftSize,
    learnedSec: Number(p.learnedSec.toFixed(3)),
    avgDb: Number(p.avgDb.toFixed(2)),
    peakDb: Number(p.peakDb.toFixed(2)),
    magnitudes: mags,
  };
}

export function deserializeNoiseProfile(s: SerializedNoiseProfile): NoiseProfile {
  const bins = (s.fftSize >> 1) + 1;
  const magnitudes = new Float32Array(bins);
  const floor = new Float32Array(bins);
  for (let k = 0; k < bins; k += 1) {
    const src = Math.min(s.magnitudes.length - 1, Math.round(k / 2));
    const v = s.magnitudes[src] ?? 0;
    magnitudes[k] = v;
    floor[k] = v * 0.6;
  }
  return {
    sampleRate: s.sampleRate,
    fftSize: s.fftSize,
    learnedSec: s.learnedSec,
    avgDb: s.avgDb,
    peakDb: s.peakDb,
    magnitudes,
    floor,
  };
}

/* ------------------------------------------------------------------ */
/* Spectral subtraction (offline + streaming)                          */
/* ------------------------------------------------------------------ */

function binGains(
  profile: NoiseProfile,
  opts: NoiseReduceOptions,
): { threshold: Float32Array; floorGain: number } {
  const bins = profile.magnitudes.length;
  const threshold = new Float32Array(bins);
  for (let k = 0; k < bins; k += 1) {
    threshold[k] = profile.magnitudes[k] * opts.strength;
  }
  return { threshold, floorGain: dbToLin(opts.floorDb) };
}

/**
 * Applies a learned noise print across a whole buffer.
 * The voice is preserved because only bins whose energy sits close to the
 * learned print are attenuated, never more than `floorDb`.
 */
export function reduceNoise(
  samples: Float32Array,
  sampleRate: number,
  profile: NoiseProfile,
  opts: NoiseReduceOptions = defaultNoiseOptions,
): Float32Array {
  const n = profile.fftSize;
  if (samples.length < n / 4) return samples.slice();
  const hop = n >> 1;
  const fft = new FFT(n);
  const win = sqrtHannWindow(n);
  // a print learned at another sample rate is remapped bin-by-bin
  const mapped =
    profile.sampleRate === sampleRate
      ? profile
      : remapProfile(profile, sampleRate, n);
  const { threshold, floorGain } = binGains(mapped, opts);
  const re = new Float32Array(n);
  const im = new Float32Array(n);
  const prevGain = new Float32Array(n >> 1).fill(1);
  const out = new Float32Array(samples.length);
  const weight = new Float32Array(samples.length);
  const bins = n >> 1;
  const s = opts.smoothing;
  const padded = samples.length >= n ? samples : padTo(samples, n);

  for (let pos = 0; pos < padded.length; pos += hop) {
    const avail = Math.min(n, padded.length - pos);
    for (let i = 0; i < n; i += 1) {
      re[i] = i < avail ? padded[pos + i] * win[i] : 0;
      im[i] = 0;
    }
    fft.forward(re, im);
    for (let k = 0; k <= bins; k += 1) {
      const mag = Math.hypot(re[k], im[k]);
      let g = mag > 1e-9 ? (mag - threshold[k]) / mag : floorGain;
      g = clamp(g, floorGain, 1);
      g = s * prevGain[k === bins ? bins - 1 : k] + (1 - s) * g;
      prevGain[k === bins ? bins - 1 : k] = g;
      const apply = (idx: number) => {
        re[idx] *= g;
        im[idx] *= g;
      };
      apply(k);
      if (k !== 0 && k !== bins) apply(n - k);
    }
    fft.inverse(re, im);
    const write = Math.min(n, samples.length - pos);
    for (let i = 0; i < write; i += 1) {
      const v = re[i] * win[i];
      out[pos + i] += v;
      weight[pos + i] += win[i] * win[i];
    }
    if (pos + n >= padded.length) break;
  }

  for (let i = 0; i < out.length; i += 1) {
    const w = weight[i];
    out[i] = w > 1e-6 ? out[i] / w : 0;
  }
  return out;
}

/** Rescales a learned print so it matches a different sample rate / FFT size. */
function remapProfile(profile: NoiseProfile, sampleRate: number, fftSize: number): NoiseProfile {
  const bins = (fftSize >> 1) + 1;
  const magnitudes = new Float32Array(bins);
  const floor = new Float32Array(bins);
  const srcBins = profile.magnitudes.length;
  for (let k = 0; k < bins; k += 1) {
    const hz = (k * sampleRate) / fftSize;
    const srcK = clamp(Math.round((hz * profile.fftSize) / profile.sampleRate), 0, srcBins - 1);
    magnitudes[k] = profile.magnitudes[srcK];
    floor[k] = profile.floor[srcK];
  }
  return { ...profile, sampleRate, fftSize, magnitudes, floor };
}

function padTo(samples: Float32Array, len: number): Float32Array {
  const out = new Float32Array(Math.max(len, samples.length));
  out.set(samples);
  return out;
}

/**
 * Frame-by-frame suppressor used while recording, so the user hears the
 * cleaned signal in real time (one 1/2-block latency).
 */
export class StreamingNoiseSuppressor {
  private readonly fft: FFT;
  private readonly n: number;
  private readonly hop: number;
  private readonly win: Float32Array;
  private readonly re: Float32Array;
  private readonly im: Float32Array;
  private readonly prevGain: Float32Array;
  private prevInput: Float32Array;
  private prevTail: Float32Array;
  private threshold: Float32Array;
  private floorGain: number;
  private smoothing: number;

  constructor(profile: NoiseProfile, opts: NoiseReduceOptions = defaultNoiseOptions) {
    this.n = profile.fftSize;
    this.hop = this.n >> 1;
    this.fft = new FFT(this.n);
    this.win = sqrtHannWindow(this.n);
    this.re = new Float32Array(this.n);
    this.im = new Float32Array(this.n);
    this.prevGain = new Float32Array(this.n >> 1).fill(1);
    this.prevInput = new Float32Array(this.hop);
    this.prevTail = new Float32Array(this.hop);
    const g = binGains(profile, opts);
    this.threshold = g.threshold;
    this.floorGain = g.floorGain;
    this.smoothing = opts.smoothing;
  }

  retune(profile: NoiseProfile, opts: NoiseReduceOptions): void {
    const g = binGains(profile, opts);
    this.threshold = g.threshold;
    this.floorGain = g.floorGain;
    this.smoothing = opts.smoothing;
  }

  /** Consumes `hop * 2` samples at a time and returns the same amount. */
  process(input: Float32Array): Float32Array {
    const out = new Float32Array(input.length);
    let offset = 0;
    while (offset + this.hop <= input.length) {
      const frame = new Float32Array(this.n);
      frame.set(this.prevInput);
      frame.set(input.subarray(offset, offset + this.hop), this.hop);
      for (let i = 0; i < this.n; i += 1) {
        this.re[i] = frame[i] * this.win[i];
        this.im[i] = 0;
      }
      this.fft.forward(this.re, this.im);
      const bins = this.n >> 1;
      for (let k = 0; k <= bins; k += 1) {
        const mag = Math.hypot(this.re[k], this.im[k]);
        let g = mag > 1e-9 ? (mag - this.threshold[k]) / mag : this.floorGain;
        g = clamp(g, this.floorGain, 1);
        const gi = k === bins ? bins - 1 : k;
        g = this.smoothing * this.prevGain[gi] + (1 - this.smoothing) * g;
        this.prevGain[gi] = g;
        this.re[k] *= g;
        this.im[k] *= g;
        if (k !== 0 && k !== bins) {
          this.re[this.n - k] *= g;
          this.im[this.n - k] *= g;
        }
      }
      this.fft.inverse(this.re, this.im);
      for (let i = 0; i < this.hop; i += 1) {
        out[offset + i] = this.prevTail[i] + this.re[i] * this.win[i];
        this.prevTail[i] = this.re[i + this.hop] * this.win[i + this.hop];
      }
      this.prevInput = input.subarray(offset, offset + this.hop).slice();
      offset += this.hop;
    }
    return out;
  }
}

/** Learn a print from an arbitrary region of the file, then clean everything. */
export function reduceNoiseFromSample(
  samples: Float32Array,
  sampleRate: number,
  noiseSample: Float32Array,
  opts: NoiseReduceOptions = defaultNoiseOptions,
): { samples: Float32Array; profile: NoiseProfile } {
  const profile = learnNoiseProfile(noiseSample, sampleRate);
  return { samples: reduceNoise(samples, sampleRate, profile, opts), profile };
}

/* ------------------------------------------------------------------ */
/* Silence detection, removal and splitting                            */
/* ------------------------------------------------------------------ */

export type SilenceOptions = {
  thresholdDb: number;
  minSilenceSec: number;
  /** if set, silences are trimmed down to this length instead of fully cut */
  keepSec?: number | null;
  /** pad kept audio by this many ms around every cut */
  padMs?: number;
};

export function detectSilence(
  samples: Float32Array,
  sampleRate: number,
  opts: { thresholdDb: number; minSec: number },
): Range[] {
  const { values, hopSec } = envelopeDb(samples, sampleRate, 10);
  const ranges: Range[] = [];
  let runStart = -1;
  for (let i = 0; i < values.length; i += 1) {
    const quiet = values[i] < opts.thresholdDb;
    if (quiet && runStart < 0) runStart = i;
    if ((!quiet || i === values.length - 1) && runStart >= 0) {
      const end = quiet ? i + 1 : i;
      const start = runStart * hopSec;
      const stop = end * hopSec;
      if (stop - start >= opts.minSec) ranges.push({ start, end: Math.min(stop, samples.length / sampleRate) });
      runStart = -1;
    }
  }
  return ranges;
}

export type SilenceResult = {
  samples: Float32Array;
  removed: Range[];
  kept: Range[];
  removedSec: number;
};

/**
 * Dual mode silence removal.
 *  - dB mode: everything under `thresholdDb` longer than `minSilenceSec` is cut.
 *  - second-limit mode: `keepSec` keeps at most N seconds of each pause.
 */
export function removeSilence(
  samples: Float32Array,
  sampleRate: number,
  opts: SilenceOptions,
): SilenceResult {
  const detected = detectSilence(samples, sampleRate, {
    thresholdDb: opts.thresholdDb,
    minSec: opts.minSilenceSec,
  });
  const total = samples.length / sampleRate;
  const pad = (opts.padMs ?? 20) / 1000;
  const cut: Range[] = [];
  for (const r of detected) {
    const len = r.end - r.start;
    if (opts.keepSec != null && opts.keepSec > 0) {
      if (len <= opts.keepSec) continue;
      const remove = len - opts.keepSec;
      cut.push({
        start: clamp(r.start + opts.keepSec / 2 - pad, 0, total),
        end: clamp(r.start + opts.keepSec / 2 - pad + remove + pad * 2, 0, total),
      });
    } else {
      cut.push({
        start: clamp(r.start - pad, 0, total),
        end: clamp(r.end + pad, 0, total),
      });
    }
  }
  const kept = invertRanges(cut, total);
  const outSamples = keepRanges(samples, sampleRate, kept, 6);
  return {
    samples: outSamples,
    removed: cut,
    kept,
    removedSec: cut.reduce((a, r) => a + (r.end - r.start), 0),
  };
}

export function invertRanges(ranges: Range[], totalSec: number): Range[] {
  const sorted = [...ranges].sort((a, b) => a.start - b.start);
  const out: Range[] = [];
  let cursor = 0;
  for (const r of sorted) {
    if (r.start > cursor) out.push({ start: cursor, end: r.start });
    cursor = Math.max(cursor, r.end);
  }
  if (cursor < totalSec) out.push({ start: cursor, end: totalSec });
  return out.filter((r) => r.end - r.start > 0.001);
}

export function keepRanges(
  samples: Float32Array,
  sampleRate: number,
  ranges: Range[],
  fadeMs = 6,
): Float32Array {
  const fade = Math.max(1, Math.round((sampleRate * fadeMs) / 1000));
  const pieces: Float32Array[] = [];
  for (const r of ranges) {
    pieces.push(extractRange(samples, sampleRate, r, fade));
  }
  return concat(pieces);
}

export function cutRanges(
  samples: Float32Array,
  sampleRate: number,
  ranges: Range[],
  fadeMs = 6,
): Float32Array {
  const total = samples.length / sampleRate;
  return keepRanges(samples, sampleRate, invertRanges(ranges, total), fadeMs);
}

export function extractRange(
  samples: Float32Array,
  sampleRate: number,
  range: Range,
  fadeMs = 6,
): Float32Array {
  const a = clamp(Math.round(range.start * sampleRate), 0, samples.length);
  const b = clamp(Math.round(range.end * sampleRate), a, samples.length);
  const out = samples.slice(a, b);
  const fade = Math.min(Math.max(1, Math.round((sampleRate * fadeMs) / 1000)), Math.floor(out.length / 2));
  for (let i = 0; i < fade; i += 1) {
    const g = i / fade;
    out[i] *= g;
    out[out.length - 1 - i] *= g;
  }
  return out;
}

export type SplitOptions = {
  thresholdDb: number;
  minSilenceSec: number;
  minChunkSec: number;
  maxChunks: number;
};

/** Auto-splits on silence; if too many gaps are found only the deepest ones are used. */
export function splitBySilence(
  samples: Float32Array,
  sampleRate: number,
  opts: SplitOptions,
): { ranges: Range[]; silences: Range[] } {
  const total = samples.length / sampleRate;
  const silences = detectSilence(samples, sampleRate, {
    thresholdDb: opts.thresholdDb,
    minSec: opts.minSilenceSec,
  });
  let chosen = silences;
  const maxPoints = Math.max(0, opts.maxChunks - 1);
  if (chosen.length > maxPoints) {
    chosen = [...chosen]
      .sort((a, b) => b.end - b.start - (a.end - a.start))
      .slice(0, maxPoints)
      .sort((a, b) => a.start - b.start);
  }
  let ranges = invertRanges(chosen, total);
  if (opts.minChunkSec > 0) {
    ranges = ranges.filter((r) => r.end - r.start >= opts.minChunkSec);
    if (!ranges.length) ranges = [{ start: 0, end: total }];
  }
  return { ranges, silences };
}

/* ------------------------------------------------------------------ */
/* Gain staging: normalise, auto-level, limit                          */
/* ------------------------------------------------------------------ */

export function normalizePeak(samples: Float32Array, targetDb = -1): Float32Array {
  const peak = peakLevel(samples);
  if (peak < 1e-6) return samples.slice();
  const g = dbToLin(targetDb) / peak;
  const out = new Float32Array(samples.length);
  for (let i = 0; i < samples.length; i += 1) out[i] = samples[i] * g;
  return out;
}

export function normalizeRms(samples: Float32Array, targetDb = -18): Float32Array {
  const rms = rmsLevel(samples);
  if (rms < 1e-6) return samples.slice();
  let g = dbToLin(targetDb) / rms;
  g = Math.min(g, dbToLin(24));
  const out = new Float32Array(samples.length);
  for (let i = 0; i < samples.length; i += 1) out[i] = samples[i] * g;
  return normalizePeak(out, -1);
}

export type AutoLevelOptions = {
  targetDb: number;
  windowMs: number;
  maxBoostDb: number;
  maxCutDb: number;
  smoothing: number;
  noiseGateDb: number;
};

/**
 * Voice booster / auto-normalisation: block based RMS levelling with a
 * smoothed gain curve, so quiet words come up and loud words come down
 * without pumping the background noise.
 */
export function autoLevel(
  samples: Float32Array,
  sampleRate: number,
  opts: Partial<AutoLevelOptions> = {},
): { samples: Float32Array; gains: Float32Array; hopSec: number } {
  const target = opts.targetDb ?? -18;
  const windowMs = opts.windowMs ?? 60;
  const maxBoost = dbToLin(opts.maxBoostDb ?? 18);
  const maxCut = dbToLin(-(opts.maxCutDb ?? 12));
  const smoothing = opts.smoothing ?? 0.75;
  const gate = opts.noiseGateDb ?? -55;
  const hop = Math.max(64, Math.round((sampleRate * windowMs) / 1000));
  const blocks = Math.max(1, Math.ceil(samples.length / hop));
  const gains = new Float32Array(blocks);
  let prev = 1;
  for (let b = 0; b < blocks; b += 1) {
    const off = b * hop;
    const end = Math.min(samples.length, off + hop);
    const block = samples.subarray(off, end);
    const rms = rmsLevel(block);
    const db = linToDb(rms);
    let g = prev;
    if (db > gate) {
      g = clamp(dbToLin(target) / Math.max(rms, 1e-6), maxCut, maxBoost);
      g = smoothing * prev + (1 - smoothing) * g;
    }
    prev = g;
    gains[b] = g;
  }
  // guard: never push the result into clipping
  const ceiling = -1;
  const out = new Float32Array(samples.length);
  for (let i = 0; i < samples.length; i += 1) {
    const b = Math.min(blocks - 1, Math.floor(i / hop));
    const nb = Math.min(blocks - 1, b + 1);
    const t = (i - b * hop) / hop;
    const g = gains[b] * (1 - t) + gains[nb] * t;
    out[i] = samples[i] * g;
  }
  const limited = softClip(out, 0.97);
  const final = peakDb(limited) > ceiling ? normalizePeak(limited, ceiling) : limited;
  return { samples: final, gains, hopSec: hop / sampleRate };
}

/** tanh based limiter – transparent up to ~0.8, never exceeds 1.0 */
export function softClip(samples: Float32Array, threshold = 0.98): Float32Array {
  const out = new Float32Array(samples.length);
  const t = Math.max(0.05, threshold);
  for (let i = 0; i < samples.length; i += 1) {
    const v = samples[i];
    out[i] = Math.abs(v) <= t ? v : Math.sign(v) * (t + (1 - t) * Math.tanh((Math.abs(v) - t) / (1 - t)));
  }
  return out;
}

export function removeDc(samples: Float32Array): Float32Array {
  let mean = 0;
  for (let i = 0; i < samples.length; i += 1) mean += samples[i];
  mean /= Math.max(1, samples.length);
  const out = new Float32Array(samples.length);
  for (let i = 0; i < samples.length; i += 1) out[i] = samples[i] - mean;
  return out;
}

export type Analysis = {
  durationSec: number;
  peakDb: number;
  rmsDb: number;
  dynamicRangeDb: number;
  silenceSec: number;
  clipped: number;
  noiseFloorDb: number;
};

export function analyze(samples: Float32Array, sampleRate: number): Analysis {
  const { values, hopSec } = envelopeDb(samples, sampleRate, 20);
  let clipped = 0;
  for (let i = 0; i < samples.length; i += 1) if (Math.abs(samples[i]) >= 0.999) clipped += 1;
  const sorted = Array.from(values).sort((a, b) => a - b);
  const p10 = sorted[Math.floor(sorted.length * 0.1)] ?? -180;
  const p90 = sorted[Math.floor(sorted.length * 0.9)] ?? -180;
  const silence = values.reduce((a, v) => a + (v < -45 ? hopSec : 0), 0);
  return {
    durationSec: samples.length / sampleRate,
    peakDb: peakDb(samples),
    rmsDb: rmsDb(samples),
    dynamicRangeDb: p90 - p10,
    silenceSec: silence,
    clipped,
    noiseFloorDb: p10,
  };
}

/* ------------------------------------------------------------------ */
/* Utilities                                                           */
/* ------------------------------------------------------------------ */

export function concat(parts: Float32Array[]): Float32Array {
  const total = parts.reduce((a, p) => a + p.length, 0);
  const out = new Float32Array(total);
  let off = 0;
  for (const p of parts) {
    out.set(p, off);
    off += p.length;
  }
  return out;
}

export function mixToMono(buffer: AudioBuffer): Float32Array {
  if (buffer.numberOfChannels === 1) return buffer.getChannelData(0).slice();
  const len = buffer.length;
  const out = new Float32Array(len);
  const ch = buffer.numberOfChannels;
  for (let c = 0; c < ch; c += 1) {
    const data = buffer.getChannelData(c);
    for (let i = 0; i < len; i += 1) out[i] += data[i] / ch;
  }
  return out;
}

/** Peak cache for fast waveform drawing at any zoom. */
export function computePeaks(samples: Float32Array, buckets: number): Float32Array[] {
  const min = new Float32Array(buckets);
  const max = new Float32Array(buckets);
  const per = Math.max(1, Math.floor(samples.length / buckets));
  for (let b = 0; b < buckets; b += 1) {
    let lo = 0;
    let hi = 0;
    const start = b * per;
    const end = Math.min(samples.length, start + per);
    for (let i = start; i < end; i += 1) {
      const v = samples[i];
      if (v < lo) lo = v;
      if (v > hi) hi = v;
    }
    min[b] = lo;
    max[b] = hi;
  }
  return [min, max];
}

export function timecode(sec: number, withMs = true): string {
  if (!Number.isFinite(sec) || sec < 0) sec = 0;
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  const ms = Math.floor((sec - Math.floor(sec)) * 100);
  return withMs
    ? `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(ms).padStart(2, "0")}`
    : `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

/* ------------------------------------------------------------------ */
/* Demo source material (so every tool can be tested without a mic)    */
/* ------------------------------------------------------------------ */

/**
 * Synthesises a "room recording": voiced syllable bursts with formant-like
 * harmonics, breath pauses and a fan/AC style broadband noise bed.
 */
export function generateDemoAudio(
  seconds = 24,
  sampleRate = 44100,
  opts: { noiseDb?: number; seed?: number } = {},
): { samples: Float32Array; speech: Range[]; silences: Range[] } {
  const noiseDb = opts.noiseDb ?? -34;
  let seed = opts.seed ?? 20260214;
  const rand = () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };
  const total = Math.floor(seconds * sampleRate);
  const out = new Float32Array(total);

  // broadband "fan" bed with slow amplitude drift
  let lp = 0;
  const noiseAmp = dbToLin(noiseDb);
  for (let i = 0; i < total; i += 1) {
    const white = rand() * 2 - 1;
    lp = lp * 0.86 + white * 0.14;
    const drift = 0.75 + 0.25 * Math.sin((2 * Math.PI * i) / (sampleRate * 7.3));
    out[i] = lp * noiseAmp * drift;
  }

  // syllable plan: phrases with gaps
  const speech: Range[] = [];
  const silences: Range[] = [];
  let t = 0.6;
  let gapIndex = 0;
  while (t < seconds - 1.2) {
    const phraseLen = 1.4 + rand() * 2.2;
    const start = t;
    let pt = 0;
    const baseF0 = 104 + rand() * 46;
    while (pt < phraseLen) {
      const syl = 0.14 + rand() * 0.16;
      const s0 = Math.floor((start + pt) * sampleRate);
      const s1 = Math.min(total, Math.floor((start + pt + syl) * sampleRate));
      const f0 = baseF0 * (0.94 + rand() * 0.14);
      const f1 = 380 + rand() * 420;
      const f2 = 1150 + rand() * 900;
      for (let i = s0; i < s1; i += 1) {
        const x = (i - s0) / sampleRate;
        const env = Math.sin(Math.PI * Math.min(1, (i - s0) / Math.max(1, s1 - s0))) ** 1.4;
        const glottal =
          Math.sin(2 * Math.PI * f0 * x) * 0.6 +
          Math.sin(2 * Math.PI * f0 * 2 * x) * 0.32 +
          Math.sin(2 * Math.PI * f0 * 3 * x) * 0.18;
        const formants =
          Math.sin(2 * Math.PI * f1 * x + glottal * 1.6) * 0.4 +
          Math.sin(2 * Math.PI * f2 * x + glottal * 0.9) * 0.22;
        out[i] += (glottal * 0.55 + formants * 0.5) * env * 0.62;
      }
      pt += syl + 0.02 + rand() * 0.05;
    }
    speech.push({ start, end: Math.min(seconds, start + phraseLen) });
    t += phraseLen;
    const gaps = [1.6, 0.9, 2.6, 1.1];
    const gap = gaps[gapIndex % gaps.length] * (0.8 + rand() * 0.5);
    silences.push({ start: t, end: t + gap });
    t += gap;
    gapIndex += 1;
  }

  // occasional loud transient so the limiter/leveller has work to do
  const burstAt = Math.floor(seconds * 0.42 * sampleRate);
  for (let i = 0; i < sampleRate * 0.08; i += 1) {
    const idx = burstAt + i;
    if (idx >= total) break;
    out[idx] += Math.sin(2 * Math.PI * 210 * (i / sampleRate)) * (1 - i / (sampleRate * 0.08)) * 0.9;
  }

  return { samples: normalizePeak(softClip(out, 0.97), -1.5), speech, silences };
}

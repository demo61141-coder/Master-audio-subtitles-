/**
 * Iterative radix-2 FFT (in-place) used by the noise-profile engine.
 * Kept dependency-free so it runs identically in the browser and in tests.
 */
export class FFT {
  readonly size: number;
  private readonly cosTable: Float32Array;
  private readonly sinTable: Float32Array;

  constructor(size: number) {
    if (size < 2 || (size & (size - 1)) !== 0) {
      throw new Error(`FFT size must be a power of two, got ${size}`);
    }
    this.size = size;
    this.cosTable = new Float32Array(size / 2);
    this.sinTable = new Float32Array(size / 2);
    for (let i = 0; i < size / 2; i += 1) {
      this.cosTable[i] = Math.cos((2 * Math.PI * i) / size);
      this.sinTable[i] = Math.sin((2 * Math.PI * i) / size);
    }
  }

  forward(re: Float32Array, im: Float32Array): void {
    this.transform(re, im, -1);
  }

  inverse(re: Float32Array, im: Float32Array): void {
    this.transform(re, im, 1);
    const n = this.size;
    for (let i = 0; i < n; i += 1) {
      re[i] /= n;
      im[i] /= n;
    }
  }

  private transform(re: Float32Array, im: Float32Array, sign: number): void {
    const n = this.size;
    // Bit-reversal permutation
    for (let i = 1, j = 0; i < n; i += 1) {
      let bit = n >> 1;
      for (; j & bit; bit >>= 1) {
        j ^= bit;
      }
      j ^= bit;
      if (i < j) {
        const tr = re[i];
        re[i] = re[j];
        re[j] = tr;
        const ti = im[i];
        im[i] = im[j];
        im[j] = ti;
      }
    }
    for (let len = 2; len <= n; len <<= 1) {
      const half = len >> 1;
      const step = n / len;
      for (let i = 0; i < n; i += len) {
        for (let k = 0; k < half; k += 1) {
          const idx = k * step;
          const cos = this.cosTable[idx];
          const sin = sign * this.sinTable[idx];
          const e = i + k;
          const o = e + half;
          const tre = re[o] * cos - im[o] * sin;
          const tim = re[o] * sin + im[o] * cos;
          re[o] = re[e] - tre;
          im[o] = im[e] - tim;
          re[e] += tre;
          im[e] += tim;
        }
      }
    }
  }
}

/** Periodic sqrt-Hann window: analysis * synthesis gives perfect 50% overlap-add. */
export function sqrtHannWindow(size: number): Float32Array {
  const w = new Float32Array(size);
  for (let i = 0; i < size; i += 1) {
    w[i] = Math.sqrt(0.5 * (1 - Math.cos((2 * Math.PI * i) / size)));
  }
  return w;
}

export function hannWindow(size: number): Float32Array {
  const w = new Float32Array(size);
  for (let i = 0; i < size; i += 1) {
    w[i] = 0.5 * (1 - Math.cos((2 * Math.PI * i) / size));
  }
  return w;
}

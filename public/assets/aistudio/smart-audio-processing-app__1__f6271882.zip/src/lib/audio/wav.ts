/** WAV (PCM) encode/decode helpers – no external dependencies. */

export function encodeWav(samples: Float32Array, sampleRate: number, bitDepth: 16 | 24 = 16): Uint8Array {
  const bytesPerSample = bitDepth / 8;
  const blockAlign = bytesPerSample;
  const dataSize = samples.length * bytesPerSample;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i += 1) view.setUint8(offset + i, str.charCodeAt(i));
  };

  writeString(0, "RIFF");
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, "WAVE");
  writeString(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, 1, true); // mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeString(36, "data");
  view.setUint32(40, dataSize, true);

  let offset = 44;
  if (bitDepth === 16) {
    for (let i = 0; i < samples.length; i += 1, offset += 2) {
      const s = Math.max(-1, Math.min(1, samples[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
  } else {
    for (let i = 0; i < samples.length; i += 1, offset += 3) {
      const s = Math.max(-1, Math.min(1, samples[i]));
      const v = Math.round(s < 0 ? s * 0x800000 : s * 0x7fffff);
      view.setUint8(offset, v & 0xff);
      view.setUint8(offset + 1, (v >> 8) & 0xff);
      view.setUint8(offset + 2, (v >> 16) & 0xff);
    }
  }
  return new Uint8Array(buffer);
}

export function wavBlob(samples: Float32Array, sampleRate: number, bitDepth: 16 | 24 = 16): Blob {
  return new Blob([encodeWav(samples, sampleRate, bitDepth).buffer as ArrayBuffer], {
    type: "audio/wav",
  });
}

let sharedCtx: AudioContext | null = null;

export function audioContext(): AudioContext {
  if (typeof window === "undefined") throw new Error("AudioContext needs a browser");
  const Ctor: typeof AudioContext =
    window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!sharedCtx) sharedCtx = new Ctor();
  if (sharedCtx.state === "suspended") void sharedCtx.resume();
  return sharedCtx;
}

export async function decodeToMono(file: ArrayBuffer | Blob): Promise<{ samples: Float32Array; sampleRate: number }> {
  const data = file instanceof Blob ? await file.arrayBuffer() : file;
  const ctx = audioContext();
  const buffer = await ctx.decodeAudioData(data.slice(0));
  const channels = buffer.numberOfChannels;
  const out = new Float32Array(buffer.length);
  for (let c = 0; c < channels; c += 1) {
    const d = buffer.getChannelData(c);
    for (let i = 0; i < buffer.length; i += 1) out[i] += d[i] / channels;
  }
  return { samples: out, sampleRate: buffer.sampleRate };
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

import {
  clamp,
  learnNoiseProfile,
  linToDb,
  peakLevel,
  reduceNoise,
  rmsLevel,
  StreamingNoiseSuppressor,
  type NoiseProfile,
  type NoiseReduceOptions,
} from "./dsp";

export type GateSettings = {
  enabled: boolean;
  thresholdDb: number;
  holdSec: number;
};

export type RecorderLevel = { db: number; peak: number; gateOpen: boolean };

export type RecorderResult = {
  samples: Float32Array;
  sampleRate: number;
  capturedSec: number;
  skippedSec: number;
  gateEvents: number;
};

export type RecorderHooks = {
  onLevel?: (level: RecorderLevel) => void;
  onChunk?: (chunk: Float32Array) => void;
  onProgress?: (info: { capturedSec: number; skippedSec: number; gateOpen: boolean }) => void;
};

const BLOCK = 2048;

/**
 * PCM recorder built on ScriptProcessorNode so we always keep raw float
 * samples: silence skipping drops frames live, and the learned noise print
 * can be applied in real time *and* again offline after stopping.
 */
export class StudioRecorder {
  private ctx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private processor: ScriptProcessorNode | null = null;
  private sink: GainNode | null = null;

  private chunks: Float32Array[] = [];
  private preRoll: Float32Array[] = [];
  private sampleRate = 48000;

  private gate: GateSettings = { enabled: true, thresholdDb: -45, holdSec: 2 };
  private noiseOptions: NoiseReduceOptions = { strength: 2, floorDb: -32, smoothing: 0.6 };
  private profile: NoiseProfile | null = null;
  private liveSuppress = false;
  private suppressor: StreamingNoiseSuppressor | null = null;

  private silenceMs = 0;
  private gateOpen = true;
  private skippedSec = 0;
  private capturedSec = 0;
  private gateEvents = 0;
  private preRollMs = 140;

  running = false;

  get currentProfile(): NoiseProfile | null {
    return this.profile;
  }

  setProfile(profile: NoiseProfile | null): void {
    this.profile = profile;
    this.suppressor =
      profile && this.liveSuppress ? new StreamingNoiseSuppressor(profile, this.noiseOptions) : null;
  }

  setGate(gate: GateSettings): void {
    this.gate = { ...gate };
  }

  setLiveSuppress(on: boolean, options?: NoiseReduceOptions): void {
    this.liveSuppress = on;
    if (options) this.noiseOptions = { ...options };
    this.suppressor =
      on && this.profile ? new StreamingNoiseSuppressor(this.profile, this.noiseOptions) : null;
  }

  private async ensureStream(): Promise<AudioContext> {
    if (this.ctx && this.stream) return this.ctx;
    if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
      throw new Error("এই ব্রাউজারে মাইক্রোফোন অ্যাক্সেস সাপোর্ট করে না।");
    }
    const Ctor: typeof AudioContext =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) throw new Error("Web Audio API পাওয়া যায়নি।");
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false,
        },
      });
    } catch {
      throw new Error("মাইক্রোফোনের অনুমতি পাওয়া যায়নি — সেটিংস থেকে মাইক পারমিশন দিন।");
    }
    this.ctx = new Ctor();
    await this.ctx.resume().catch(() => undefined);
    this.sampleRate = this.ctx.sampleRate;
    this.source = this.ctx.createMediaStreamSource(this.stream);
    return this.ctx;
  }

  /** Records `seconds` of room tone and turns it into a noise print. */
  async captureProfile(
    seconds: number,
    onTick?: (remaining: number, db: number) => void,
  ): Promise<{ profile: NoiseProfile; samples: Float32Array }> {
    const ctx = await this.ensureStream();
    const proc = ctx.createScriptProcessor(BLOCK, 1, 1);
    const sink = ctx.createGain();
    sink.gain.value = 0;
    const collected: Float32Array[] = [];
    const target = seconds * this.sampleRate;
    const started = performance.now();

    const samples = await new Promise<Float32Array>((resolve, reject) => {
      const timeout = window.setTimeout(() => {
        cleanup();
        reject(new Error("নয়েজ প্রিন্ট ক্যাপচার টাইমআউট হয়েছে।"));
      }, (seconds + 6) * 1000);

      const cleanup = () => {
        window.clearTimeout(timeout);
        proc.onaudioprocess = null;
        proc.disconnect();
        sink.disconnect();
      };

      proc.onaudioprocess = (e) => {
        const input = e.inputBuffer.getChannelData(0);
        collected.push(input.slice());
        const got = collected.reduce((a, c) => a + c.length, 0);
        onTick?.(Math.max(0, seconds - got / this.sampleRate), linToDb(rmsLevel(input)));
        if (got >= target || performance.now() - started > (seconds + 2) * 1000) {
          cleanup();
          const all = new Float32Array(got);
          let off = 0;
          for (const c of collected) {
            all.set(c, off);
            off += c.length;
          }
          resolve(all);
        }
      };
      this.source?.connect(proc);
      proc.connect(sink);
      sink.connect(ctx.destination);
    });

    const profile = learnNoiseProfile(samples, this.sampleRate, BLOCK);
    this.setProfile(profile);
    return { profile, samples };
  }

  async start(hooks: RecorderHooks = {}): Promise<void> {
    const ctx = await this.ensureStream();
    if (!this.source) throw new Error("অডিও সোর্স তৈরি করা যায়নি।");
    this.chunks = [];
    this.preRoll = [];
    this.silenceMs = 0;
    this.gateOpen = true;
    this.skippedSec = 0;
    this.capturedSec = 0;
    this.gateEvents = 0;
    this.running = true;

    this.processor = ctx.createScriptProcessor(BLOCK, 1, 1);
    this.sink = ctx.createGain();
    this.sink.gain.value = 0;
    const blockSec = BLOCK / this.sampleRate;
    const preRollBlocks = Math.max(1, Math.round(this.preRollMs / 1000 / blockSec));

    this.processor.onaudioprocess = (e) => {
      if (!this.running) return;
      const input = e.inputBuffer.getChannelData(0);
      const db = linToDb(rmsLevel(input));
      const peak = peakLevel(input);

      let block: Float32Array = input.slice();
      if (this.liveSuppress && this.suppressor) {
        block = this.suppressor.process(block);
      }

      if (this.gate.enabled) {
        if (db >= this.gate.thresholdDb) {
          if (!this.gateOpen) {
            this.gateOpen = true;
            this.gateEvents += 1;
            // flush the pre-roll so word attacks are never clipped
            for (const p of this.preRoll) {
              this.chunks.push(p);
              this.capturedSec += p.length / this.sampleRate;
              hooks.onChunk?.(p);
            }
          }
          this.preRoll = [];
          this.silenceMs = 0;
          this.chunks.push(block);
          this.capturedSec += block.length / this.sampleRate;
          hooks.onChunk?.(block);
        } else {
          this.silenceMs += blockSec * 1000;
          if (this.silenceMs >= this.gate.holdSec * 1000) {
            if (this.gateOpen) {
              this.gateOpen = false;
              this.gateEvents += 1;
            }
            this.skippedSec += blockSec;
            this.preRoll.push(block);
            if (this.preRoll.length > preRollBlocks) this.preRoll.shift();
          } else {
            this.chunks.push(block);
            this.capturedSec += block.length / this.sampleRate;
            hooks.onChunk?.(block);
          }
        }
      } else {
        this.chunks.push(block);
        this.capturedSec += block.length / this.sampleRate;
        hooks.onChunk?.(block);
      }

      hooks.onLevel?.({ db: clamp(db, -90, 0), peak, gateOpen: this.gateOpen });
      hooks.onProgress?.({
        capturedSec: this.capturedSec,
        skippedSec: this.skippedSec,
        gateOpen: this.gateOpen,
      });
    };

    this.source.connect(this.processor);
    this.processor.connect(this.sink);
    this.sink.connect(ctx.destination);
  }

  pause(): void {
    this.running = false;
  }

  resume(): void {
    this.running = true;
  }

  stop(): RecorderResult {
    this.running = false;
    if (this.processor) {
      this.processor.onaudioprocess = null;
      this.processor.disconnect();
      this.processor = null;
    }
    if (this.sink) {
      this.sink.disconnect();
      this.sink = null;
    }
    this.source?.disconnect();
    this.source = null;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    if (this.ctx) {
      void this.ctx.close().catch(() => undefined);
      this.ctx = null;
    }

    const total = this.chunks.reduce((a, c) => a + c.length, 0);
    const samples = new Float32Array(total);
    let off = 0;
    for (const c of this.chunks) {
      samples.set(c, off);
      off += c.length;
    }
    this.chunks = [];
    const result: RecorderResult = {
      samples,
      sampleRate: this.sampleRate,
      capturedSec: total / this.sampleRate,
      skippedSec: this.skippedSec,
      gateEvents: this.gateEvents,
    };
    return result;
  }

  /** Post-record pass with the learned print (100% voice-safe floor). */
  static applyProfile(
    result: RecorderResult,
    profile: NoiseProfile | null,
    options: NoiseReduceOptions,
  ): RecorderResult {
    if (!profile || result.samples.length < profile.fftSize) return result;
    const cleaned = reduceNoise(result.samples, result.sampleRate, profile, options);
    return { ...result, samples: cleaned };
  }

  release(): void {
    this.running = false;
    this.processor?.disconnect();
    this.sink?.disconnect();
    this.source?.disconnect();
    this.stream?.getTracks().forEach((t) => t.stop());
    void this.ctx?.close().catch(() => undefined);
    this.ctx = null;
    this.stream = null;
    this.processor = null;
    this.sink = null;
    this.source = null;
  }
}

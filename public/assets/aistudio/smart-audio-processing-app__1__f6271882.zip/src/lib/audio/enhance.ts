import { clamp, dbToLin } from "./dsp";

/** Full studio chain description used by the Effects screen. */
export type EnhanceConfig = {
  highpassHz: number;
  lowpassHz: number;
  warmthHz: number;
  warmthGainDb: number;
  presenceHz: number;
  presenceGainDb: number;
  presenceQ: number;
  airHz: number;
  airGainDb: number;
  deEsserHz: number;
  deEsserGainDb: number;
  deEsserQ: number;
  compThresholdDb: number;
  compRatio: number;
  compAttack: number;
  compRelease: number;
  makeupGainDb: number;
  limiterDrive: number;
  levelAmount: number;
};

export type EnhancePreset = {
  id: string;
  name: string;
  tag: string;
  description: string;
  config: EnhanceConfig;
};

const base: EnhanceConfig = {
  highpassHz: 80,
  lowpassHz: 15000,
  warmthHz: 180,
  warmthGainDb: 1.5,
  presenceHz: 3200,
  presenceGainDb: 3,
  presenceQ: 0.9,
  airHz: 11000,
  airGainDb: 2,
  deEsserHz: 6800,
  deEsserGainDb: -3,
  deEsserQ: 2.4,
  compThresholdDb: -22,
  compRatio: 4,
  compAttack: 0.006,
  compRelease: 0.18,
  makeupGainDb: 4,
  limiterDrive: 1.15,
  levelAmount: 0.7,
};

export const enhancePresets: EnhancePreset[] = [
  {
    id: "podcast-studio",
    name: "পডকাস্ট স্টুডিও",
    tag: "AI VOICE",
    description: "ঘরে বসা রেকর্ডিংকে ব্রডকাস্ট পডকাস্ট টোনে বদলে দেয় — উষ্ণ বডি, স্পষ্ট উপস্থিতি, সমান লাউডনেস।",
    config: { ...base },
  },
  {
    id: "crystal-clear",
    name: "ক্রিস্টাল ক্লিয়ার ভয়েস",
    tag: "CLARITY",
    description: "কনসোন্যান্ট ও ডিকশন তীক্ষ্ণ করে, হিস-হিস শব্দ কমিয়ে একদম পরিচ্ছন্ন কণ্ঠ দেয়।",
    config: {
      ...base,
      highpassHz: 100,
      presenceHz: 4200,
      presenceGainDb: 4.5,
      airHz: 12500,
      airGainDb: 3.5,
      deEsserGainDb: -4.5,
      compRatio: 5,
      compThresholdDb: -24,
      warmthGainDb: 0.5,
    },
  },
  {
    id: "radio-broadcast",
    name: "রেডিও ব্রডকাস্ট",
    tag: "LOUD",
    description: "ভারী কম্প্রেশন ও লিমিটার — এফএম/ইউটিউবের জন্য একদম ঘন, লাউড ভোকাল।",
    config: {
      ...base,
      compThresholdDb: -28,
      compRatio: 8,
      compAttack: 0.003,
      compRelease: 0.12,
      makeupGainDb: 7,
      limiterDrive: 1.4,
      presenceGainDb: 3.5,
      levelAmount: 0.9,
    },
  },
  {
    id: "phone-clean",
    name: "ফোন কল ক্লিনআপ",
    tag: "RESCUE",
    description: "মোবাইল/কল রেকর্ডিংয়ের বুকুনো আওয়াজ, হাম ও কম ভলিউম ঠিক করে বোধগম্য কণ্ঠ ফেরায়।",
    config: {
      ...base,
      highpassHz: 140,
      lowpassHz: 9000,
      warmthHz: 240,
      warmthGainDb: 2.5,
      presenceHz: 2600,
      presenceGainDb: 5,
      airGainDb: 0,
      compThresholdDb: -26,
      compRatio: 6,
      makeupGainDb: 8,
    },
  },
  {
    id: "interview-natural",
    name: "ইন্টারভিউ ন্যাচারাল",
    tag: "NATURAL",
    description: "স্টুডিও ইন্টারভিউয়ের মতো প্রাকৃতিক টিম্বার — হালকা EQ, নরম কম্প্রেশন।",
    config: {
      ...base,
      presenceGainDb: 2,
      airGainDb: 1.5,
      compRatio: 2.6,
      compThresholdDb: -20,
      makeupGainDb: 2.5,
      limiterDrive: 1.05,
      levelAmount: 0.4,
    },
  },
  {
    id: "voiceover-warm",
    name: "ভয়েসওভার ওয়ার্ম",
    tag: "DUBBING",
    description: "ডাবিং/গল্প বলার জন্য বুকে-রেজোন্যান্স বাড়ানো গভীর, সিনেমাটিক কণ্ঠ।",
    config: {
      ...base,
      warmthHz: 150,
      warmthGainDb: 4,
      presenceHz: 2900,
      presenceGainDb: 2.5,
      airHz: 10000,
      airGainDb: 1.5,
      compRatio: 3.4,
      makeupGainDb: 3.5,
    },
  },
  {
    id: "bypass",
    name: "বাইপাস (অরিজিনাল)",
    tag: "REF",
    description: "কোনো প্রসেসিং ছাড়াই মূল সিগন্যাল — A/B তুলনার জন্য।",
    config: {
      ...base,
      highpassHz: 20,
      lowpassHz: 20000,
      warmthGainDb: 0,
      presenceGainDb: 0,
      airGainDb: 0,
      deEsserGainDb: 0,
      compThresholdDb: 0,
      compRatio: 1,
      makeupGainDb: 0,
      limiterDrive: 1,
      levelAmount: 0,
    },
  },
];

export function presetById(id: string): EnhancePreset {
  return enhancePresets.find((p) => p.id === id) ?? enhancePresets[0];
}

function limiterCurve(drive: number): Float32Array<ArrayBuffer> {
  const n = 2048;
  const curve: Float32Array<ArrayBuffer> = new Float32Array(n);
  const d = Math.max(1, drive);
  for (let i = 0; i < n; i += 1) {
    const x = (i * 2) / (n - 1) - 1;
    curve[i] = Math.tanh(x * d) / Math.tanh(d);
  }
  return curve;
}

/**
 * Runs the enhancement chain in an OfflineAudioContext and returns clean PCM.
 * Chain: DC-safe highpass → lowpass → warmth → presence → air → de-esser →
 * compressor → makeup gain → tanh limiter.
 */
export async function renderEnhanced(
  samples: Float32Array,
  sampleRate: number,
  cfg: EnhanceConfig,
): Promise<Float32Array> {
  if (typeof window === "undefined") return samples.slice();
  const tail = Math.floor(sampleRate * 0.08);
  const length = Math.max(128, samples.length + tail);
  const Ctor: typeof OfflineAudioContext =
    window.OfflineAudioContext ??
    (window as unknown as { webkitOfflineAudioContext: typeof OfflineAudioContext }).webkitOfflineAudioContext;
  const ctx = new Ctor(1, length, sampleRate);

  const src = ctx.createBufferSource();
  const buf = ctx.createBuffer(1, samples.length, sampleRate);
  buf.copyToChannel(samples.slice(), 0);
  src.buffer = buf;

  const highpass = ctx.createBiquadFilter();
  highpass.type = "highpass";
  highpass.frequency.value = clamp(cfg.highpassHz, 20, 800);
  highpass.Q.value = 0.707;

  const lowpass = ctx.createBiquadFilter();
  lowpass.type = "lowpass";
  lowpass.frequency.value = clamp(cfg.lowpassHz, 1000, 20000);
  lowpass.Q.value = 0.707;

  const warmth = ctx.createBiquadFilter();
  warmth.type = "lowshelf";
  warmth.frequency.value = clamp(cfg.warmthHz, 60, 600);
  warmth.gain.value = clamp(cfg.warmthGainDb, -12, 12);

  const presence = ctx.createBiquadFilter();
  presence.type = "peaking";
  presence.frequency.value = clamp(cfg.presenceHz, 500, 9000);
  presence.Q.value = clamp(cfg.presenceQ, 0.3, 6);
  presence.gain.value = clamp(cfg.presenceGainDb, -12, 15);

  const deEsser = ctx.createBiquadFilter();
  deEsser.type = "peaking";
  deEsser.frequency.value = clamp(cfg.deEsserHz, 3000, 12000);
  deEsser.Q.value = clamp(cfg.deEsserQ, 0.5, 8);
  deEsser.gain.value = clamp(cfg.deEsserGainDb, -18, 0);

  const air = ctx.createBiquadFilter();
  air.type = "highshelf";
  air.frequency.value = clamp(cfg.airHz, 4000, 18000);
  air.gain.value = clamp(cfg.airGainDb, -12, 12);

  const comp = ctx.createDynamicsCompressor();
  comp.threshold.value = clamp(cfg.compThresholdDb, -60, 0);
  comp.ratio.value = clamp(cfg.compRatio, 1, 20);
  comp.attack.value = clamp(cfg.compAttack, 0, 1);
  comp.release.value = clamp(cfg.compRelease, 0.01, 1);
  comp.knee.value = 6;

  const makeup = ctx.createGain();
  makeup.gain.value = dbToLin(clamp(cfg.makeupGainDb, -24, 24));

  const limiter = ctx.createWaveShaper();
  limiter.curve = limiterCurve(cfg.limiterDrive);
  limiter.oversample = "4x";

  const out = ctx.createGain();
  out.gain.value = 1;

  src
    .connect(highpass)
    .connect(lowpass)
    .connect(warmth)
    .connect(presence)
    .connect(deEsser)
    .connect(air)
    .connect(comp)
    .connect(makeup)
    .connect(limiter)
    .connect(out)
    .connect(ctx.destination);

  src.start(0);
  const rendered = await ctx.startRendering();
  const data = rendered.getChannelData(0).slice(0, samples.length);
  return data;
}

"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Btn, Chip, Panel, Row, Stat } from "@/components/ui";
import {
  IconAndroid,
  IconBolt,
  IconChevron,
  IconDownload,
  IconLibrary,
  IconMic,
  IconPlay,
  IconScissors,
  IconTrash,
  IconUpload,
  IconWand,
  IconWave,
} from "@/components/icons";
import { decodeToMono } from "@/lib/audio/wav";
import { formatBytes, timecode } from "@/lib/audio/dsp";
import { api, type DashboardStats, type LogEntry, type ProjectSummary } from "@/lib/api";
import { useWorkspace } from "@/lib/store";
import { importFileIntoWorkspace, loadDemoIntoWorkspace } from "@/lib/workspaceActions";
import Link from "next/link";

const OPERATION_LABEL: Record<string, { label: string; tone: "signal" | "teal" | "lime" | "rec" }> = {
  record: { label: "রেকর্ড", tone: "rec" },
  "noise-profile-learned": { label: "নয়েজ প্রিন্ট", tone: "signal" },
  "silence-db-mode": { label: "dB সাইলেন্স কাট", tone: "teal" },
  "silence-limit-mode": { label: "সেকেন্ড-লিমিট কাট", tone: "teal" },
  "sample-noise-removal": { label: "স্যাম্পল নয়েজ রিমুভ", tone: "signal" },
  "auto-split": { label: "অটো স্প্লিট", tone: "lime" },
  "manual-split": { label: "ম্যানুয়াল স্প্লিট", tone: "lime" },
  "ai-voice-enhance": { label: "AI এনহ্যান্স", tone: "signal" },
  "auto-normalize": { label: "অটো লেভেল", tone: "teal" },
  "noise-removal": { label: "নয়েজ রিমুভ", tone: "signal" },
  "studio-chain": { label: "স্টুডিও চেইন", tone: "lime" },
};

export default function LibraryScreen() {
  const ws = useWorkspace();
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const [p, l, s] = await Promise.all([api.listProjects(), api.listLogs(), api.dashboard()]);
      setProjects(p);
      setLogs(l);
      setStats(s);
    } catch (e) {
      ws.notify(e instanceof Error ? e.message : "ডেটা লোড করা যায়নি", "err");
    } finally {
      setLoading(false);
    }
  }, [ws]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  async function openInEditor(project: ProjectSummary, assetId?: string) {
    const asset = assetId
      ? project.assets.find((a) => a.id === assetId)
      : project.assets.find((a) => a.kind === "processed") ?? project.assets[0];
    if (!asset) {
      ws.notify("এই প্রজেক্টে কোনো অডিও অ্যাসেট নেই।", "warn");
      return;
    }
    ws.setBusy("সার্ভার থেকে অডিও লোড হচ্ছে…");
    try {
      const bytes = await api.fetchAudio(project.id, asset.id);
      const { samples, sampleRate } = await decodeToMono(bytes);
      ws.loadAudio({
        samples,
        sampleRate,
        title: project.title,
        projectId: project.id,
        status: project.status === "enhanced" ? "enhanced" : project.status === "cleaned" ? "cleaned" : "raw",
        keepOriginal: false,
      });
      ws.notify(`"${project.title}" এডিটরে খোলা হয়েছে (${timecode(samples.length / sampleRate)})`);
      router.push("/editor");
    } catch (e) {
      ws.notify(e instanceof Error ? e.message : "অডিও লোড ব্যর্থ", "err");
    } finally {
      ws.setBusy(null);
    }
  }

  async function remove(project: ProjectSummary) {
    if (!window.confirm(`"${project.title}" মুছে ফেলবেন? অডিও ও লগ সব ডিলিট হবে।`)) return;
    await api.deleteProject(project.id).catch(() => undefined);
    ws.notify("প্রজেক্ট মুছে ফেলা হয়েছে", "warn");
    await refresh();
  }

  async function rename(project: ProjectSummary) {
    const name = window.prompt("নতুন নাম:", project.title);
    if (!name) return;
    await api.updateProject(project.id, { title: name }).catch(() => undefined);
    await refresh();
  }

  return (
    <div className="space-y-4">
      <div className="panel panel-notch flex flex-wrap items-end justify-between gap-4 px-5 py-4">
        <div>
          <div className="label-xs mb-2 text-copper">সার্ভার · PostgreSQL + Drizzle</div>
          <h1 className="font-display text-[26px] leading-tight font-700 sm:text-[30px]">
            প্রজেক্ট <span className="text-signal">লাইব্রেরি</span> ও প্রসেসিং টাইমলাইন
          </h1>
          <p className="mt-1.5 max-w-2xl text-[13.5px] text-sand-300">
            প্রতিটি রেকর্ডিং, শেখা নয়েজ প্রিন্ট, স্প্লিট টুকরো আর সব DSP অপারেশনের লগ সার্ভারে সংরক্ষিত থাকে।
          </p>
        </div>
        <Row>
          <Btn icon={<IconBolt />} onClick={() => loadDemoIntoWorkspace(24)}>
            ডেমো তৈরি
          </Btn>
          <Btn icon={<IconUpload />} onClick={() => fileRef.current?.click()}>
            ফাইল ইমপোর্ট
          </Btn>
          <Link href="/">
            <Btn variant="primary" icon={<IconMic />}>
              নতুন রেকর্ডিং
            </Btn>
          </Link>
          <Btn variant="ghost" onClick={refresh}>
            রিফ্রেশ
          </Btn>
          <input
            ref={fileRef}
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (f) {
                await importFileIntoWorkspace(f);
                router.push("/editor");
              }
              e.target.value = "";
            }}
          />
        </Row>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
        <Stat label="প্রজেক্ট" value={stats?.projects ?? 0} tone="signal" />
        <Stat label="মোট অডিও" value={timecode(stats?.audioSeconds ?? 0, false)} tone="teal" />
        <Stat label="সাইলেন্স বাদ" value={(stats?.silenceRemovedSec ?? 0).toFixed(1)} unit="s" tone="lime" />
        <Stat label="টুকরো (chunks)" value={stats?.chunks ?? 0} />
        <Stat label="DSP অপারেশন" value={stats?.operations ?? 0} />
        <Stat label="স্টোরেজ" value={formatBytes(stats?.storageBytes ?? 0)} />
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.55fr)_minmax(0,1fr)]">
        <Panel
          title="সংরক্ষিত প্রজেক্ট"
          step="01"
          icon={<IconLibrary />}
          right={<Badge tone={loading ? "signal" : "teal"}>{loading ? "লোডিং…" : `${projects.length} টি`}</Badge>}
        >
          {projects.length === 0 ? (
            <div className="border border-dashed border-ink-700 bg-ink-900/40 px-4 py-10 text-center">
              <p className="font-display text-[16px] text-sand-100">এখনো কোনো প্রজেক্ট সেভ হয়নি</p>
              <p className="mx-auto mt-1.5 max-w-md text-[12.5px] text-sand-500">
                রেকর্ডার থেকে রেকর্ডিং শেষ করলে অথবা এডিটর/ইফেক্টসে "সার্ভারে সেভ" চাপলে এখানে কার্ড যোগ হবে —
                WAV বাইট, নয়েজ প্রিন্ট ও প্রসেসিং লগসহ।
              </p>
              <Row className="mt-4 justify-center">
                <Link href="/">
                  <Btn variant="primary" icon={<IconMic />}>
                    রেকর্ডার খুলুন
                  </Btn>
                </Link>
                <Btn icon={<IconBolt />} onClick={() => loadDemoIntoWorkspace(24)}>
                  ডেমো দিয়ে টেস্ট করুন
                </Btn>
              </Row>
            </div>
          ) : (
            <div className="space-y-2">
              {projects.map((p) => {
                const expanded = open === p.id;
                const master = p.assets.find((a) => a.kind === "processed") ?? p.assets[0];
                const chunkAssets = p.assets.filter((a) => a.kind === "chunk");
                return (
                  <article key={p.id} className="border border-ink-700/80 bg-ink-900/60 transition-colors hover:border-ink-600">
                    <div className="flex flex-wrap items-center gap-3 px-3 py-2.5">
                      <button
                        type="button"
                        onClick={() => openInEditor(p, master?.id)}
                        className="grid h-9 w-9 shrink-0 place-items-center border border-signal/40 bg-signal/10 text-signal transition-colors hover:bg-signal/20"
                        title="এডিটরে খুলুন"
                      >
                        <IconWave width={16} height={16} />
                      </button>
                      <div className="min-w-[180px] flex-1">
                        <div className="flex items-center gap-2">
                          <span className="truncate font-display text-[14px] text-sand-50">{p.title}</span>
                          <Badge tone={p.status === "enhanced" ? "signal" : p.status === "cleaned" ? "teal" : "sand"}>{p.status}</Badge>
                          <Badge tone="sand">{p.source}</Badge>
                        </div>
                        <div className="mt-0.5 font-mono text-[10.5px] text-sand-500">
                          {timecode(p.durationSec)} · {(p.sampleRate / 1000).toFixed(1)} kHz · v{p.version} ·{" "}
                          {new Date(p.createdAt).toLocaleString("en-GB", { dateStyle: "short", timeStyle: "short" })}
                          {p.stats ? ` · peak ${p.stats.peakDb.toFixed(1)}dB · rms ${p.stats.rmsDb.toFixed(1)}dB` : ""}
                          {p.noisePrint ? ` · প্রিন্ট ${p.noisePrint.avgDb.toFixed(1)}dB` : ""}
                        </div>
                      </div>
                      <Row className="shrink-0">
                        {master && (
                          <a href={api.audioUrl(p.id, master.id)} download>
                            <Btn size="sm" icon={<IconDownload width={13} height={13} />}>
                              WAV
                            </Btn>
                          </a>
                        )}
                        <Btn size="sm" variant="primary" icon={<IconPlay width={12} height={12} />} onClick={() => openInEditor(p, master?.id)}>
                          এডিটর
                        </Btn>
                        <Btn size="sm" variant="ghost" onClick={() => rename(p)}>
                          রিনেম
                        </Btn>
                        <Btn size="sm" variant="ghost" icon={<IconChevron width={13} height={13} className={expanded ? "rotate-180" : ""} />} onClick={() => setOpen(expanded ? null : p.id)} />
                        <Btn size="sm" variant="danger" icon={<IconTrash width={13} height={13} />} onClick={() => remove(p)} />
                      </Row>
                    </div>

                    {expanded && (
                      <div className="space-y-3 border-t border-ink-800 bg-ink-950/50 px-3 py-3">
                        <div>
                          <div className="label-xs mb-1.5">অডিও অ্যাসেট ({p.assets.length})</div>
                          {p.assets.length === 0 ? (
                            <p className="text-[12px] text-sand-500">কোনো অ্যাসেট নেই।</p>
                          ) : (
                            <div className="space-y-1">
                              {p.assets.map((a) => (
                                <div key={a.id} className="flex flex-wrap items-center gap-2 border border-ink-800 bg-ink-900/70 px-2 py-1.5">
                                  <Badge tone={a.kind === "chunk" ? "lime" : a.kind === "processed" ? "teal" : "sand"}>{a.kind}</Badge>
                                  <span className="flex-1 truncate text-[12px] text-sand-100">{a.label}</span>
                                  {a.startSec != null && a.endSec != null && (
                                    <span className="readout text-[11px] text-sand-500">
                                      {timecode(a.startSec)} → {timecode(a.endSec)}
                                    </span>
                                  )}
                                  <span className="readout text-[11px] text-sand-300">{timecode(a.durationSec)}</span>
                                  <span className="readout text-[11px] text-sand-500">{formatBytes(a.bytes)}</span>
                                  <a href={api.audioUrl(p.id, a.id)} download>
                                    <Btn size="sm" variant="ghost" icon={<IconDownload width={12} height={12} />}>
                                      ডাউনলোড
                                    </Btn>
                                  </a>
                                  <Btn size="sm" variant="ghost" icon={<IconPlay width={12} height={12} />} onClick={() => openInEditor(p, a.id)}>
                                    খুলুন
                                  </Btn>
                                </div>
                              ))}
                            </div>
                          )}
                          {chunkAssets.length > 0 && (
                            <p className="mt-1.5 font-mono text-[11px] text-sand-500">
                              <IconScissors width={12} height={12} className="mr-1 inline" />
                              {chunkAssets.length}টি স্প্লিট টুকরো এই প্রজেক্টে সংরক্ষিত
                            </p>
                          )}
                        </div>

                        <div className="grid gap-3 sm:grid-cols-2">
                          <div>
                            <div className="label-xs mb-1.5">রেকর্ডার সেটিংস</div>
                            <div className="space-y-1 font-mono text-[11.5px] text-sand-300">
                              <KV k="গেট" v={p.settings ? (p.settings.gateEnabled ? `চালু · ${p.settings.gateThresholdDb} dB · ${p.settings.gateHoldSec}s` : "বন্ধ") : "—"} />
                              <KV k="লাইভ সাপ্রেশন" v={p.settings ? (p.settings.liveSuppress ? "চালু" : "বন্ধ") : "—"} />
                              <KV k="স্ট্রেংথ" v={p.settings ? `${p.settings.suppressStrength}×` : "—"} />
                              <KV k="অটো ক্লিন" v={p.settings ? (p.settings.autoClean ? "চালু" : "বন্ধ") : "—"} />
                            </div>
                          </div>
                          <div>
                            <div className="label-xs mb-1.5">নয়েজ প্রিন্ট</div>
                            {p.noisePrint ? (
                              <div className="space-y-1 font-mono text-[11.5px] text-sand-300">
                                <KV k="ফ্লোর" v={`${p.noisePrint.avgDb.toFixed(1)} dB`} />
                                <KV k="পিক" v={`${p.noisePrint.peakDb.toFixed(1)} dB`} />
                                <KV k="শেখা" v={`${p.noisePrint.learnedSec.toFixed(1)} s`} />
                                <KV k="FFT" v={`${p.noisePrint.fftSize} pt · ${p.noisePrint.magnitudes.length} বিন`} />
                                <Btn
                                  size="sm"
                                  variant="ghost"
                                  icon={<IconWand width={12} height={12} />}
                                  onClick={async () => {
                                    const { deserializeNoiseProfile } = await import("@/lib/audio/dsp");
                                    ws.setNoiseProfile(deserializeNoiseProfile(p.noisePrint!));
                                    ws.notify("সার্ভারের নয়েজ প্রিন্ট ওয়ার্কস্পেসে লোড হয়েছে — ইফেক্টসে প্রয়োগ করা যাবে।");
                                  }}
                                >
                                  ওয়ার্কস্পেসে লোড
                                </Btn>
                              </div>
                            ) : (
                              <p className="text-[12px] text-sand-500">এই প্রজেক্টে প্রিন্ট সংরক্ষিত নেই।</p>
                            )}
                          </div>
                        </div>
                      </div>
                    )}
                  </article>
                );
              })}
            </div>
          )}
        </Panel>

        <Panel title="প্রসেসিং টাইমলাইন" step="02" icon={<IconBolt />} subtitle="প্রতিটি DSP অপারেশনের প্যারামিটার ও ফলাফল সার্ভারে লগ হয়।" right={<Chip onClick={refresh}>রিফ্রেশ</Chip>}>
          {logs.length === 0 ? (
            <p className="border border-dashed border-ink-700 px-3 py-8 text-center text-[12.5px] text-sand-500">
              এখনো কোনো অপারেশন লগ নেই — রেকর্ড, সাইলেন্স রিমুভ বা এনহ্যান্স করলেই এখানে জমা হবে।
            </p>
          ) : (
            <ol className="relative space-y-2 border-l border-ink-700 pl-4">
              {logs.map((l) => {
                const meta = OPERATION_LABEL[l.operation] ?? { label: l.operation, tone: "sand" as const };
                return (
                  <li key={l.id} className="relative">
                    <span className="absolute top-2 -left-[21px] h-2 w-2 border border-signal/60 bg-ink-900" />
                    <div className="border border-ink-700/70 bg-ink-900/60 px-3 py-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge tone={meta.tone as "signal" | "teal" | "lime" | "rec"}>{meta.label}</Badge>
                        <span className="flex-1 truncate text-[12.5px] text-sand-100">{l.label}</span>
                        <span className="readout text-[10.5px] text-sand-500">{l.durationMs} ms</span>
                      </div>
                      <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 font-mono text-[10.5px] text-sand-500">
                        <span>{new Date(l.createdAt).toLocaleString("en-GB", { dateStyle: "short", timeStyle: "medium" })}</span>
                        {l.result && Object.entries(l.result).slice(0, 4).map(([k, v]) => (
                          <span key={k}>
                            {k}=<span className="text-sand-300">{typeof v === "number" ? v.toFixed(2) : String(v)}</span>
                          </span>
                        ))}
                      </div>
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
        </Panel>
      </div>

      <Panel title="পরবর্তী ধাপ" step="03" icon={<IconAndroid />} subtitle="অ্যাপটি Android ফোনে নিতে চাইলে APK গাইড দেখুন।">
        <Row>
          <Link href="/apk">
            <Btn variant="teal" icon={<IconAndroid />}>
              APK ডাউনলোড/বিল্ড গাইড
            </Btn>
          </Link>
          <Link href="/effects">
            <Btn icon={<IconWand />}>ইফেক্টস স্ক্রিন</Btn>
          </Link>
          <Link href="/editor">
            <Btn variant="ghost" icon={<IconScissors />}>
              এডিটর
            </Btn>
          </Link>
        </Row>
      </Panel>
    </div>
  );
}

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-sand-500">{k}</span>
      <span className="text-sand-100">{v}</span>
    </div>
  );
}

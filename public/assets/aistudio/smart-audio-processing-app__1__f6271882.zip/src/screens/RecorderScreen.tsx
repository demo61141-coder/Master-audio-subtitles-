"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Btn, Chip, Panel, Row, Segmented, Slider, Stat, Toggle } from "@/components/ui";
import {
  IconBolt,
  IconCheck,
  IconDownload,
  IconFan,
  IconMic,
  IconMute,
  IconPause,
  IconPlay,
  IconRecord,
  IconShield,
  IconStop,
  IconUpload,
  IconWand,
} from "@/components/icons";
import { EqBars, LevelBar, LiveScope, makeScope, pushScope, SpectrumBars, type ScopeBuffer } from "@/components/visuals";
import { StudioRecorder } from "@/lib/audio/recorder";
import { autoLevel, normalizePeak, reduceNoise, timecode } from "@/lib/audio/dsp";
import { api } from "@/lib/api";
import { useWorkspace } from "@/lib/store";
import { loadDemoIntoWorkspace, importFileIntoWorkspace, persistToServer } from "@/lib/workspaceActions";

type Phase = "idle" | "profiling" | "recording" | "paused" | "processing";

export default function RecorderScreen() {
  const router = useRouter();
  const ws = useWorkspace();
  const gate = ws.gate;
  const setGate = ws.setGate;
  const suppress = ws.suppress;
  const setSuppress = ws.setSuppress;
  const liveSuppress = ws.liveSuppress;
  const setLiveSuppress = ws.setLiveSuppress;
  const profileSec = ws.profileSec;
  const setProfileSec = ws.setProfileSec;
  const autoClean = ws.autoClean;
  const setAutoClean = ws.setAutoClean;
  const autoLevelOn = ws.autoLevel;
  const setAutoLevel = ws.setAutoLevel;

  const recRef = useRef<StudioRecorder | null>(null);
  const scopeRef = useRef<ScopeBuffer>(makeScope(9000));
  const fileRef = useRef<HTMLInputElement | null>(null);
  const levelRef = useRef({ db: -90, peak: -90, gateOpen: true });
  const startedRef = useRef(0);
  const rafRef = useRef(0);
  const lastUiRef = useRef(0);

  const [phase, setPhase] = useState<Phase>("idle");
  const [level, setLevel] = useState({ db: -90, peak: -90, gateOpen: true });
  const [wall, setWall] = useState(0);
  const [captured, setCaptured] = useState(0);
  const [skipped, setSkipped] = useState(0);
  const [gateEvents, setGateEvents] = useState(0);
  const [countdown, setCountdown] = useState(0);

  const profile = ws.noiseProfile;
  const recording = phase === "recording" || phase === "paused";

  useEffect(() => {
    recRef.current?.setGate(gate);
  }, [gate]);
  useEffect(() => {
    recRef.current?.setLiveSuppress(liveSuppress, suppress);
  }, [liveSuppress, suppress]);
  useEffect(() => () => recRef.current?.release(), []);

  const uiLoop = useCallback(() => {
    const now = performance.now();
    if (now - lastUiRef.current > 55) {
      lastUiRef.current = now;
      setLevel({ ...levelRef.current });
      setWall((performance.now() - startedRef.current) / 1000);
    }
    rafRef.current = requestAnimationFrame(uiLoop);
  }, []);

  useEffect(() => {
    if (phase === "recording") {
      rafRef.current = requestAnimationFrame(uiLoop);
      return () => cancelAnimationFrame(rafRef.current);
    }
    return;
  }, [phase, uiLoop]);

  /* ------------------------------------------------ noise print capture */

  async function captureProfile() {
    if (phase !== "idle") return;
    setPhase("profiling");
    setCountdown(profileSec);
    const rec = recRef.current ?? new StudioRecorder();
    recRef.current = rec;
    try {
      const { profile: learned, samples } = await rec.captureProfile(profileSec, (remaining, db) => {
        setCountdown(remaining);
        levelRef.current = { db, peak: db, gateOpen: true };
        setLevel({ db, peak: db, gateOpen: true });
      });
      ws.setNoiseProfile(learned, samples);
      ws.notify(`নয়েজ প্রিন্ট শেখা শেষ — ${learned.avgDb.toFixed(1)} dB ফ্লোর, ${learned.fftSize}-পয়েন্ট স্পেকট্রাম।`, "ok");
      await api
        .addLog({
          operation: "noise-profile-learned",
          label: `${profileSec}s রুম টোন থেকে নয়েজ প্রিন্ট`,
          params: { profileSec, fftSize: learned.fftSize, strength: suppress.strength },
          result: { avgDb: learned.avgDb, peakDb: learned.peakDb },
        })
        .catch(() => undefined);
    } catch (e) {
      ws.notify(e instanceof Error ? e.message : "নয়েজ প্রিন্ট ক্যাপচার ব্যর্থ", "err");
    } finally {
      recRef.current?.release();
      recRef.current = null;
      setPhase("idle");
      setCountdown(0);
    }
  }

  /* ------------------------------------------------------- record flow */

  async function startRecording() {
    if (phase === "paused") {
      recRef.current?.resume();
      startedRef.current = performance.now() - wall * 1000;
      setPhase("recording");
      return;
    }
    const rec = new StudioRecorder();
    recRef.current = rec;
    rec.setGate(gate);
    rec.setLiveSuppress(liveSuppress, suppress);
    if (profile) rec.setProfile(profile);
    scopeRef.current = makeScope(9000);
    try {
      await rec.start({
        onLevel: (l) => {
          levelRef.current = l;
        },
        onChunk: (chunk) => pushScope(scopeRef.current, chunk),
        onProgress: (p) => {
          setCaptured(p.capturedSec);
          setSkipped(p.skippedSec);
        },
      });
      startedRef.current = performance.now();
      setCaptured(0);
      setSkipped(0);
      setWall(0);
      setGateEvents(0);
      setPhase("recording");
    } catch (e) {
      ws.notify(e instanceof Error ? e.message : "রেকর্ডিং শুরু করা যায়নি", "err");
      rec.release();
      recRef.current = null;
      setPhase("idle");
    }
  }

  async function stopRecording(save: boolean) {
    const rec = recRef.current;
    if (!rec) {
      setPhase("idle");
      return;
    }
    if (phase === "paused") rec.resume();
    setPhase("processing");
    const t0 = performance.now();
    const result = rec.stop();
    recRef.current = null;
    cancelAnimationFrame(rafRef.current);
    setGateEvents(result.gateEvents);

    if (result.samples.length < 2048) {
      ws.notify("যথেষ্ট অডিও ক্যাপচার হয়নি — আবার চেষ্টা করুন।", "warn");
      setPhase("idle");
      return;
    }

    let samples = result.samples;
    const sr = result.sampleRate;
    const ops: string[] = [];
    if (gate.enabled && result.skippedSec > 0.05) ops.push(`silence-skip(${result.skippedSec.toFixed(1)}s বাদ)`);
    if (autoClean && profile) {
      samples = reduceNoise(samples, sr, profile, suppress);
      ops.push("noise-profile-subtract");
    }
    if (autoLevelOn) {
      samples = autoLevel(samples, sr, { targetDb: -18, windowMs: 60 }).samples;
      ops.push("auto-level");
    }
    if (!autoLevelOn) samples = normalizePeak(samples, -1);

    const title = `রেকর্ডিং ${new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}`;
    ws.loadAudio({
      samples,
      sampleRate: sr,
      title,
      status: autoClean && profile ? "cleaned" : "raw",
      keepOriginal: false,
    });

    if (save) {
      ws.setBusy("সার্ভারে সেভ হচ্ছে…");
      const saved = await persistToServer({
        samples,
        sampleRate: sr,
        title,
        status: autoClean && profile ? "cleaned" : "raw",
        noiseProfile: profile,
        kind: "processed",
        label: "রেকর্ড মাস্টার",
        source: "mic",
      });
      await api
        .addLog({
          projectId: saved?.projectId ?? null,
          operation: "record",
          label: title,
          params: { gate, liveSuppress, autoClean, autoLevel: autoLevelOn, ops },
          result: {
            capturedSec: Number(result.capturedSec.toFixed(2)),
            skippedSec: Number(result.skippedSec.toFixed(2)),
            gateEvents: result.gateEvents,
            durationSec: Number((samples.length / sr).toFixed(2)),
            removedSec: Number(result.skippedSec.toFixed(2)),
            ms: Math.round(performance.now() - t0),
          },
          durationMs: Math.round(performance.now() - t0),
        })
        .catch(() => undefined);
      ws.setBusy(null);
      ws.notify(
        saved
          ? `রেকর্ডিং সেভ হয়েছে — ${result.skippedSec.toFixed(1)}s সাইলেন্স স্কিপ, ${ops.length}টি প্রসেস স্টেপ।`
          : "অডিও লোকালি লোড হয়েছে (সার্ভারে সেভ ব্যর্থ)।",
        saved ? "ok" : "warn",
      );
      router.push("/editor");
      return;
    }
    setPhase("idle");
  }

  function cancelRecording() {
    recRef.current?.release();
    recRef.current = null;
    cancelAnimationFrame(rafRef.current);
    setPhase("idle");
    setWall(0);
    setCaptured(0);
    setSkipped(0);
    ws.notify("রেকর্ডিং বাতিল করা হয়েছে", "warn");
  }

  const ring = Math.min(1, Math.max(0, (level.db + 60) / 60));
  const statusTone =
    phase === "recording" ? "rec" : phase === "profiling" ? "signal" : phase === "paused" ? "lime" : "teal";

  return (
    <div className="space-y-4">
      {/* console header */}
      <div className="panel panel-notch flex flex-wrap items-end justify-between gap-4 px-5 py-4">
        <div>
          <div className="label-xs mb-2 text-copper">ফিচার ০১ · স্মার্ট রেকর্ডিং ডেক</div>
          <h1 className="font-display text-[26px] leading-tight font-700 text-sand-50 sm:text-[32px]">
            অডাসিটি-স্টাইল <span className="text-signal">নয়েজ প্রোফাইল লার্নিং</span>
          </h1>
          <p className="mt-1.5 max-w-2xl text-[13.5px] leading-relaxed text-sand-300">
            রেকর্ডিং শুরুর আগে ৩–৫ সেকেন্ডের রুম টোন থেকে অ্যাপ আপনার পরিবেশের "নয়েজ প্রিন্ট" শিখে নেয়। এরপর
            সেই প্রিন্ট মিলিয়ে শুধু ব্যাকগ্রাউন্ড নয়েজ (ফ্যান/AC/হাম) বিয়োগ হয় — কণ্ঠের ফ্রিকোয়েন্সি অক্ষুণ্ণ থাকে।
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge tone={statusTone as "rec" | "signal" | "lime" | "teal"}>
            <EqBars count={3} active={phase === "recording"} />
            {phase === "recording" ? "REC" : phase === "profiling" ? "LEARNING" : phase === "paused" ? "PAUSED" : phase === "processing" ? "DSP" : "READY"}
          </Badge>
          <span className="readout text-[13px]">{timecode(wall)}</span>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)]">
        {/* left column ------------------------------------------------ */}
        <div className="space-y-4">
          <Panel
            title="রেকর্ড ডেক"
            step="01"
            icon={<IconMic />}
            subtitle="বড় রেকর্ড বাটন, লাইভ স্কোপ ও গেট মিটার — সব একসাথে।"
            right={
              <span className="readout text-[12px] text-sand-300">
                {(ws.sampleRate / 1000).toFixed(1)} kHz · mono
              </span>
            }
          >
            <div className="flex flex-col items-center gap-5 sm:flex-row sm:items-center">
              <button
                type="button"
                onClick={() => (phase === "recording" ? stopRecording(true) : phase === "idle" ? startRecording() : undefined)}
                disabled={phase === "profiling" || phase === "processing"}
                className={`relative grid h-[168px] w-[168px] shrink-0 place-items-center rounded-full transition-transform active:scale-[0.98] disabled:opacity-50 ${
                  phase === "recording" ? "rec-pulse" : ""
                }`}
                style={{
                  background:
                    phase === "recording"
                      ? "radial-gradient(circle at 50% 35%, #3a1416, #16090a 68%)"
                      : "radial-gradient(circle at 50% 35%, #20262e, #0c0f13 70%)",
                  boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.07), 0 24px 50px -30px #000",
                }}
              >
                <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full -rotate-90">
                  <circle cx="100" cy="100" r="86" fill="none" stroke="#222a33" strokeWidth="4" />
                  <circle
                    cx="100"
                    cy="100"
                    r="86"
                    fill="none"
                    stroke={phase === "recording" ? "#ff4d55" : "#ffa23a"}
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeDasharray={`${ring * 540} 540`}
                    style={{ transition: "stroke-dasharray 90ms linear", filter: "drop-shadow(0 0 6px rgba(255,140,40,0.55))" }}
                  />
                </svg>
                <span className="relative flex flex-col items-center gap-1.5">
                  {phase === "recording" ? (
                    <>
                      <IconStop width={30} height={30} className="text-rec" />
                      <span className="readout text-[22px]">{timecode(captured)}</span>
                      <span className="label-xs">স্টপ ও সেভ</span>
                    </>
                  ) : phase === "paused" ? (
                    <>
                      <IconPlay width={30} height={30} className="text-lime" />
                      <span className="readout text-[22px]">{timecode(captured)}</span>
                      <span className="label-xs">রিজিউম</span>
                    </>
                  ) : (
                    <>
                      <IconRecord width={34} height={34} className="text-rec" />
                      <span className="label-xs">রেকর্ড শুরু</span>
                    </>
                  )}
                </span>
              </button>

              <div className="min-w-0 flex-1 space-y-3">
                <LiveScope scope={scopeRef} active={phase === "recording"} height={104} />
                <LevelBar db={level.db} peak={level.peak} thresholdDb={gate.enabled ? gate.thresholdDb : undefined} gateOpen={level.gateOpen} />
                <div className="grid grid-cols-3 gap-2">
                  <Stat label="ক্যাপচার" value={captured.toFixed(1)} unit="s" tone="signal" />
                  <Stat label="স্কিপড সাইলেন্স" value={skipped.toFixed(1)} unit="s" tone="lime" />
                  <Stat label="গেট ইভেন্ট" value={gateEvents} tone="teal" />
                </div>
                <Row>
                  {phase === "recording" && (
                    <Btn
                      size="sm"
                      icon={<IconPause width={14} height={14} />}
                      onClick={() => {
                        recRef.current?.pause();
                        setPhase("paused");
                      }}
                    >
                      পজ
                    </Btn>
                  )}
                  {phase === "paused" && (
                    <Btn size="sm" variant="teal" icon={<IconPlay width={14} height={14} />} onClick={startRecording}>
                      রিজিউম
                    </Btn>
                  )}
                  {recording && (
                    <>
                      <Btn size="sm" variant="primary" icon={<IconCheck width={14} height={14} />} onClick={() => stopRecording(true)}>
                        স্টপ ও সেভ
                      </Btn>
                      <Btn size="sm" variant="ghost" onClick={() => stopRecording(false)}>
                        শুধু ওয়ার্কস্পেসে নাও
                      </Btn>
                      <Btn size="sm" variant="danger" onClick={cancelRecording}>
                        বাতিল
                      </Btn>
                    </>
                  )}
                  {!recording && phase === "idle" && (
                    <span className="font-mono text-[11px] text-sand-500">
                      মাইক পারমিশন চাইবে · র লো-লেভেল PCM ক্যাপচার (ব্রাউজারের AGC/NS বন্ধ)
                    </span>
                  )}
                </Row>
              </div>
            </div>
          </Panel>

          <Panel
            title="নয়েজ প্রোফাইল লার্নিং"
            step="02"
            icon={<IconFan />}
            tone="signal"
            subtitle="শুধু পরিবেশের শব্দ থাকবে এমন ৩–৫ সেকেন্ড রেকর্ড করুন — অ্যাপ স্পেকট্রাম মুখস্থ করে ফেলবে।"
            right={
              profile ? (
                <Badge tone="teal">
                  <IconShield width={11} height={11} /> প্রিন্ট রেডি
                </Badge>
              ) : (
                <Badge tone="sand">প্রিন্ট নেই</Badge>
              )
            }
          >
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-1.5">
                  <span className="label-xs">স্যাম্পল দৈর্ঘ্য</span>
                  <Segmented
                    value={profileSec}
                    onChange={setProfileSec}
                    options={[
                      { value: 3, label: "৩ সেকেন্ড" },
                      { value: 4, label: "৪ সেকেন্ড" },
                      { value: 5, label: "৫ সেকেন্ড" },
                    ]}
                  />
                </div>
                <Btn
                  variant={profile ? "outline" : "primary"}
                  icon={<IconFan />}
                  disabled={phase !== "idle"}
                  onClick={captureProfile}
                >
                  {phase === "profiling" ? `শিখছি… ${countdown.toFixed(1)}s` : profile ? "আবার নয়েজ প্রিন্ট নাও" : "নয়েজ প্রিন্ট ক্যাপচার"}
                </Btn>
              </div>

              {phase === "profiling" && (
                <div className="sweep relative h-1.5 overflow-hidden border border-ink-700 bg-ink-900">
                  <div
                    className="h-full bg-gradient-to-r from-copper to-signal transition-all"
                    style={{ width: `${Math.max(4, 100 - (countdown / profileSec) * 100)}%` }}
                  />
                </div>
              )}

              {profile ? (
                <div className="space-y-2">
                  <SpectrumBars
                    magnitudes={profile.magnitudes}
                    sampleRate={profile.sampleRate}
                    fftSize={profile.fftSize}
                    height={82}
                    caption="learned noise print"
                  />
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                    <Stat label="নয়েজ ফ্লোর" value={profile.avgDb.toFixed(1)} unit="dB" tone="signal" />
                    <Stat label="শেখা সময়" value={profile.learnedSec.toFixed(1)} unit="s" />
                    <Stat label="FFT" value={profile.fftSize} unit="pt" />
                    <Stat label="ম্যাক্স কাট" value={suppress.floorDb} unit="dB" tone="teal" />
                  </div>
                  <p className="text-[11.5px] leading-relaxed text-sand-500">
                    প্রতিটি ফ্রিকোয়েন্সি বিনে শেখা নয়েজের গড় ম্যাগনিটিউড সংরক্ষিত। রেকর্ডিংয়ের সময় ওই বিনগুলোর
                    শক্তি নয়েজ প্রিন্টের কাছাকাছি হলেই শুধু অ্যাটেনুয়েট হয় — কণ্ঠের শক্তি অনেক বেশি হওয়ায় সেটি অক্ষুণ্ণ থাকে।
                  </p>
                </div>
              ) : (
                <div className="flex items-center gap-3 border border-dashed border-ink-700 px-3 py-4 text-[12.5px] text-sand-500">
                  <IconInfoGlyph />
                  প্রিন্ট ছাড়াও রেকর্ড করা যাবে; পরে এডিটরে যেকোনো অংশ থেকে নয়েজ স্যাম্পল নিয়ে ক্লিন করা যাবে।
                </div>
              )}
            </div>
          </Panel>
        </div>

        {/* right column ----------------------------------------------- */}
        <div className="space-y-4">
          <Panel
            title="সাইলেন্স স্কিপ রেকর্ডিং"
            step="03"
            icon={<IconMute />}
            tone="teal"
            subtitle="নির্দিষ্ট dB ও সেকেন্ড সেট করুন — এর বেশি চুপ থাকলে রেকর্ডিং অটো স্কিপ হবে।"
          >
            <div className="space-y-4">
              <Toggle
                checked={gate.enabled}
                onChange={(v) => setGate({ enabled: v })}
                label="সাইলেন্স স্কিপ চালু"
                hint="গেট বন্ধ থাকলে পুরো টানা রেকর্ডিং হয়, পরে এডিটরে সাইলেন্স কাটা যাবে।"
              />
              <Slider
                label="থ্রেশহোল্ড"
                value={gate.thresholdDb}
                min={-60}
                max={-20}
                step={1}
                unit=" dB"
                tone="teal"
                disabled={!gate.enabled}
                onChange={(v) => setGate({ thresholdDb: v })}
                hint="এর নিচের লেভেলকে চুপ ধরা হবে (সাধারণ ঘর −৪৫ dB এর আশপাশে)।"
              />
              <div className="space-y-1.5">
                <span className="label-xs">কত সেকেন্ড চুপ থাকলে স্কিপ</span>
                <Segmented
                  size="sm"
                  value={gate.holdSec}
                  onChange={(v) => setGate({ holdSec: v })}
                  options={[
                    { value: 1, label: "১ s" },
                    { value: 2, label: "২ s" },
                    { value: 3, label: "৩ s" },
                  ]}
                />
              </div>
              <Slider
                label="কাস্টম হোল্ড টাইম"
                value={gate.holdSec}
                min={0.3}
                max={6}
                step={0.1}
                unit=" s"
                tone="teal"
                disabled={!gate.enabled}
                onChange={(v) => setGate({ holdSec: Number(v.toFixed(1)) })}
                hint="১৪০ ms প্রি-রোল বাফার থাকায় গেট খোলার মুহূর্তে শব্দের শুরু কাটা পড়ে না।"
              />
              <div className="grid grid-cols-2 gap-2">
                <Stat label="মোড" value={gate.enabled ? "স্কিপ" : "টানা"} tone={gate.enabled ? "lime" : "sand"} />
                <Stat label="থ্রেশহোল্ড" value={gate.thresholdDb} unit="dB" />
              </div>
            </div>
          </Panel>

          <Panel
            title="স্মার্ট নয়েজ ফিল্টার"
            step="04"
            icon={<IconShield />}
            subtitle="শেখা প্রিন্ট দিয়ে রিয়েল-টাইম বা রেকর্ডিং-পরবর্তী সাবট্রাকশন।"
            right={profile ? <Badge tone="signal">প্রিন্ট লোডেড</Badge> : <Badge tone="sand">আগে প্রিন্ট নিন</Badge>}
          >
            <div className="space-y-4">
              <Toggle
                checked={liveSuppress}
                onChange={setLiveSuppress}
                disabled={!profile}
                label="লাইভ নয়েজ সাপ্রেশন (রেকর্ডিংয়ের সময়)"
                hint="ব্লক-ভিত্তিক STFT সাবট্রাকশন — রেকর্ড হওয়া PCM-এ সাথে সাথেই প্রয়োগ হয়।"
              />
              <Toggle
                checked={autoClean}
                onChange={setAutoClean}
                disabled={!profile}
                label="স্টপ করার সাথে সাথে অটো ক্লিন"
                hint="পুরো ফাইলে উচ্চ রেজোলিউশনের নয়েজ প্রিন্ট পাস চালানো হয়।"
              />
              <Slider
                label="সাবট্রাকশন স্ট্রেংথ"
                value={suppress.strength}
                min={1}
                max={4}
                step={0.1}
                unit="×"
                format={(v) => v.toFixed(1)}
                onChange={(v) => setSuppress({ strength: v })}
                hint="১× = খুব নরম, ৪× = আগ্রাসী (উচ্চ মান ভয়েসকে কিছুটা রোবোটিক করতে পারে)।"
              />
              <Slider
                label="সর্বোচ্চ অ্যাটেনুয়েশন"
                value={suppress.floorDb}
                min={-48}
                max={-6}
                step={1}
                unit=" dB"
                format={(v) => v.toFixed(0)}
                onChange={(v) => setSuppress({ floorDb: v })}
                hint="কণ্ঠের অ্যাকুরেসি রক্ষায় সীমা — কখনোই এর বেশি কাটা হবে না।"
              />
              <Slider
                label="গেইন স্মুদিং (মিউজিক্যাল নয়েজ কমানো)"
                value={suppress.smoothing}
                min={0}
                max={0.9}
                step={0.05}
                format={(v) => v.toFixed(2)}
                onChange={(v) => setSuppress({ smoothing: v })}
              />
              <Row>
                <Chip active={suppress.strength === 2 && suppress.floorDb === -32} onClick={() => setSuppress({ strength: 2, floorDb: -32, smoothing: 0.6 })}>
                  ব্যালান্সড
                </Chip>
                <Chip active={suppress.strength === 3.4} onClick={() => setSuppress({ strength: 3.4, floorDb: -42, smoothing: 0.75 })}>
                  ফ্যান/AC হেভি
                </Chip>
                <Chip active={suppress.strength === 1.3} onClick={() => setSuppress({ strength: 1.3, floorDb: -18, smoothing: 0.4 })}>
                  ভয়েস সেফ
                </Chip>
              </Row>
            </div>
          </Panel>

          <Panel title="রেকর্ডিং পরবর্তী চেইন" step="05" icon={<IconBolt />} subtitle="স্টপ করার পর যে অটো স্টেপগুলো চলবে।">
            <div className="space-y-4">
              <Toggle
                checked={autoLevelOn}
                onChange={setAutoLevel}
                label="অটো লাউডনেস লেভেলিং (−18 dBFS)"
                hint="ব্লক-ভিত্তিক RMS গেইন — কোথাও খুব জোরে বা খুব আস্তে শোনাবে না।"
              />
              <div className="border border-ink-700/70 bg-ink-900/60 p-3">
                <div className="label-xs mb-2">চেইন অর্ডার</div>
                <ol className="space-y-1.5 font-mono text-[11.5px] text-sand-300">
                  <li>
                    <span className="text-signal">01</span> গেট/সাইলেন্স স্কিপ <span className="text-sand-500">(লাইভ)</span>
                  </li>
                  <li>
                    <span className="text-signal">02</span> নয়েজ প্রিন্ট সাবট্রাকশন{" "}
                    <span className="text-sand-500">{autoClean && profile ? "(সক্রিয়)" : "(বন্ধ)"}</span>
                  </li>
                  <li>
                    <span className="text-signal">03</span> অটো লেভেল + সফট লিমিটার{" "}
                    <span className="text-sand-500">{autoLevelOn ? "(সক্রিয়)" : "(বন্ধ)"}</span>
                  </li>
                  <li>
                    <span className="text-signal">04</span> WAV এনকোড → সার্ভারে সেভ → এডিটরে খোলা
                  </li>
                </ol>
              </div>
              <Btn variant="primary" icon={<IconWand />} onClick={() => router.push("/effects")}>
                ইফেক্টস স্ক্রিনে এগিয়ে যান
              </Btn>
            </div>
          </Panel>

          <Panel title="বিকল্প সোর্স" step="06" icon={<IconUpload />} subtitle="মাইক ছাড়াই সব টুল টেস্ট করতে চাইলে।">
            <Row>
              <Btn icon={<IconBolt />} onClick={() => loadDemoIntoWorkspace(26)}>
                ডেমো অডিও তৈরি (নয়েজ + সাইলেন্স সহ)
              </Btn>
              <Btn icon={<IconUpload />} onClick={() => fileRef.current?.click()}>
                ফাইল ইমপোর্ট
              </Btn>
              <Btn variant="ghost" icon={<IconDownload />} onClick={() => router.push("/library")}>
                লাইব্রেরি থেকে খুলুন
              </Btn>
              <input
                ref={fileRef}
                type="file"
                accept="audio/*"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (f) await importFileIntoWorkspace(f);
                  e.target.value = "";
                  router.push("/editor");
                }}
              />
            </Row>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function IconInfoGlyph() {
  return (
    <svg viewBox="0 0 24 24" width={18} height={18} fill="none" stroke="currentColor" strokeWidth={1.4} className="text-teal">
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 11v5.5M12 7.8v.01" strokeLinecap="round" />
    </svg>
  );
}

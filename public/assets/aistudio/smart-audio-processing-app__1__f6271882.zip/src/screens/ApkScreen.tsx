"use client";

import { useEffect, useState } from "react";
import { Badge, Btn, CodeBlock, Panel, Row, Stat } from "@/components/ui";
import {
  IconAndroid,
  IconBolt,
  IconCheck,
  IconDownload,
  IconInfo,
  IconShield,
  IconTerminal,
  IconUpload,
} from "@/components/icons";

type InstallPrompt = { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

const ROUTES = [
  {
    id: "pwa",
    name: "PWA ইনস্টল",
    effort: "২ মিনিট",
    output: "হোমস্ক্রিন অ্যাপ (APK ছাড়াই)",
    need: "Chrome + HTTPS",
    tone: "teal" as const,
    why: "সবচেয়ে দ্রুত — কোনো টুল লাগবে না। ফুল-স্ক্রিন, অফলাইন শেল, মাইক অ্যাক্সেস সব কাজ করে।",
  },
  {
    id: "capacitor",
    name: "Capacitor APK",
    effort: "১৫–২৫ মিনিট",
    output: "app-debug.apk / release-signed.apk",
    need: "Node 18+, JDK 17, Android Studio",
    tone: "signal" as const,
    why: "আসল ইন্সটেলেবল APK — ফোনে সরাসরি ইন্সটল বা বন্ধুদের শেয়ার করা যায়। সুপারিশ করা পথ।",
  },
  {
    id: "twa",
    name: "Bubblewrap / PWABuilder",
    effort: "১০ মিনিট",
    output: "app-release-signed.apk + .aab",
    need: "পাবলিক HTTPS ডোমেইন",
    tone: "lime" as const,
    why: "Play Store-এ পাবলিশ করতে চাইলে এই পথ — Trusted Web Activity দিয়ে র‍্যাপ হয়।",
  },
];

const FILES = [
  { f: "README-BANGLA.md", d: "সম্পূর্ণ বাংলা বিল্ড গাইড" },
  { f: "capacitor-app/package.json", d: "ডিপেন্ডেন্সি ও বিল্ড স্ক্রিপ্ট" },
  { f: "capacitor-app/capacitor.config.ts", d: "appId=com.voicelab.studio, webDir=dist" },
  { f: "capacitor-app/next.config.mjs", d: "output: 'export' + distDir: 'dist'" },
  { f: "capacitor-app/build-apk.sh", d: "এক কমান্ডে বিল্ড → sync → gradlew" },
  { f: "capacitor-app/env.example", d: "NEXT_PUBLIC_API_URL কনফিগ" },
  { f: "capacitor-app/signing.gradle.snippet", d: "রিলিজ সাইনিং কনফিগ" },
  { f: "capacitor-app/AndroidManifest.permissions.xml", d: "RECORD_AUDIO ও অন্যান্য পারমিশন" },
];

const FEATURES = [
  { t: "নয়েজ প্রোফাইল লার্নিং", d: "ফোনের নিজের CPU-তে FFT চলে — ইন্টারনেট লাগে না", ok: true },
  { t: "স্মার্ট নয়েজ ফিল্টার (লাইভ + অফলাইন)", d: "Web Audio + কাস্টম STFT ইঞ্জিন", ok: true },
  { t: "সাইলেন্স স্কিপ রেকর্ডিং", d: "গেট রিয়েল-টাইম PCM ফ্রেম বাদ দেয়", ok: true },
  { t: "ডুয়েল মোড সাইলেন্স রিমুভাল", d: "dB মোড + সেকেন্ড লিমিট মোড", ok: true },
  { t: "স্যাম্পল বেসড নয়েজ রিমুভ", d: "যেকোনো সিলেকশন থেকে প্রিন্ট", ok: true },
  { t: "অটো স্প্লিটার (১০০ টুকরো)", d: "গভীরতম গ্যাপ বেছে নেয়", ok: true },
  { t: "ম্যানুয়াল টাইম রেঞ্জ (+)", d: "যত খুশি স্লট যোগ, আলাদা WAV এক্সপোর্ট", ok: true },
  { t: "ভয়েস বুস্টার / অটো-নর্মালাইজেশন", d: "ব্লক RMS লেভেলিং + সফট লিমিটার", ok: true },
  { t: "AI ভয়েস এনহ্যান্সার", d: "অফলাইন অডিও গ্রাফ রেন্ডার", ok: true },
  { t: "সার্ভার লাইব্রেরি (PostgreSQL)", d: "NEXT_PUBLIC_API_URL দিলে সিঙ্ক হবে", ok: false },
];

export default function ApkScreen() {
  const [deferred, setDeferred] = useState<InstallPrompt | null>(null);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferred(e as unknown as InstallPrompt);
    };
    window.addEventListener("beforeinstallprompt", handler);
    if (window.matchMedia?.("(display-mode: standalone)").matches) setInstalled(true);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  async function install() {
    if (!deferred) return;
    await deferred.prompt();
    const choice = await deferred.userChoice;
    if (choice.outcome === "accepted") setInstalled(true);
    setDeferred(null);
  }

  return (
    <div className="space-y-4">
      <div className="panel panel-notch flex flex-wrap items-end justify-between gap-5 px-5 py-5">
        <div className="max-w-3xl">
          <div className="label-xs mb-2 text-copper">ডিপ্লয়মেন্ট · Android</div>
          <h1 className="font-display text-[28px] leading-tight font-700 sm:text-[36px]">
            এই অ্যাপের <span className="text-signal">APK</span> যেভাবে পাবেন
          </h1>
          <p className="mt-2 text-[14px] leading-relaxed text-sand-300">
            VoiceLab Studio একটি ওয়েব-ভিত্তিক অডিও ইঞ্জিন — সম্পূর্ণ DSP (FFT, স্পেকট্রাল সাবট্রাকশন, গেট, স্প্লিটার,
            এনহ্যান্সার চেইন) ব্রাউজারের Web Audio API-তে চলে। তাই এটিকে Android-এ নেওয়ার তিনটি বাস্তব পথ আছে।
            নিচের যেকোনো একটি বেছে নিন — সব কমান্ড ও কনফিগ ফাইল কপি-পেস্ট রেডি, এমনকি পুরো Capacitor প্রজেক্টের
            স্টার্টার ZIP-ও ডাউনলোড করা যাবে।
          </p>
          <Row className="mt-4">
            <Btn variant="teal" icon={<IconAndroid />} onClick={install} disabled={!deferred || installed}>
              {installed ? "অ্যাপ ইনস্টলড (standalone মোডে চলছে)" : deferred ? "এখনই ইনস্টল করুন (PWA)" : "Chrome মেনু → Add to Home screen"}
            </Btn>
            <a href="/api/apk-bundle" download>
              <Btn variant="primary" icon={<IconDownload />}>
                Android স্টার্টার বান্ডল ডাউনলোড (ZIP)
              </Btn>
            </a>
          </Row>
        </div>
        <div className="grid flex-1 grid-cols-2 gap-2 sm:max-w-[380px]">
          <Stat label="বিল্ড টাইপ" value="APK / AAB" tone="signal" />
          <Stat label="Min SDK" value="24" sub="Android 7.0+" />
          <Stat label="ইঞ্জিন" value="Web Audio" tone="teal" sub="on-device DSP" />
          <Stat label="অফলাইন" value="হ্যাঁ" tone="lime" sub="রেকর্ড + প্রসেস" />
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-3">
        {ROUTES.map((r, i) => (
          <div
            key={r.id}
            className={`panel relative overflow-hidden px-4 py-4 transition-transform hover:-translate-y-[2px] ${
              r.tone === "signal" ? "border-signal/45" : r.tone === "teal" ? "border-teal/40" : "border-lime/35"
            }`}
          >
            <span className="label-xs">উপায় {["১", "২", "৩"][i]}</span>
            <h3 className="mt-1 font-display text-[18px] font-600 text-sand-50">{r.name}</h3>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-sand-300">{r.why}</p>
            <dl className="mt-3 space-y-1.5 border-t border-ink-700/70 pt-3 font-mono text-[11.5px]">
              <div className="flex justify-between gap-2">
                <dt className="text-sand-500">সময়</dt>
                <dd className="text-sand-100">{r.effort}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-sand-500">আউটপুট</dt>
                <dd className="text-right text-sand-100">{r.output}</dd>
              </div>
              <div className="flex justify-between gap-2">
                <dt className="text-sand-500">লাগবে</dt>
                <dd className="text-right text-sand-100">{r.need}</dd>
              </div>
            </dl>
            {i === 1 && <span className="absolute top-0 right-0 bg-signal px-2 py-[3px] font-mono text-[9.5px] tracking-[0.16em] text-ink-950 uppercase">সুপারিশ</span>}
          </div>
        ))}
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Panel title="উপায় ১ — PWA ইনস্টল (APK ছাড়াই)" step="A" icon={<IconShield />} tone="teal" subtitle="ফোনে হোমস্ক্রিন অ্যাপ হিসেবে চালানোর সবচেয়ে দ্রুত উপায়।">
          <ol className="space-y-2.5 text-[13px] text-sand-200">
            {[
              "অ্যাপটি একটি HTTPS ঠিকানায় ডিপ্লয় করুন (Vercel / নিজের সার্ভার / ngrok টানেল)। মাইক অ্যাক্সেস শুধু secure origin-এ কাজ করে।",
              "Android ফোনে Chrome দিয়ে সেই URL খুলুন।",
              "Chrome মেনু (⋮) → “Install app” বা “Add to Home screen”।",
              "হোমস্ক্রিনে VoiceLab আইকন যোগ হবে — ট্যাপ করলে ফুল-স্ক্রিন, নেটিভ-অ্যাপের মতো খুলবে (সার্ভিস ওয়ার্কার শেল অফলাইনেও লোড হয়)।",
            ].map((s, i) => (
              <li key={i} className="flex gap-2.5">
                <span className="readout mt-[2px] text-signal">{String(i + 1).padStart(2, "0")}</span>
                <span className="leading-relaxed">{s}</span>
              </li>
            ))}
          </ol>
          <div className="mt-3 flex flex-wrap items-center gap-2 border border-ink-700/70 bg-ink-900/60 px-3 py-2.5">
            <Badge tone={installed ? "teal" : "sand"}>{installed ? "standalone মোড সক্রিয়" : "ব্রাউজার মোড"}</Badge>
            <Btn size="sm" variant="teal" icon={<IconDownload width={13} height={13} />} onClick={install} disabled={!deferred}>
              ইনস্টল প্রম্পট চালু করুন
            </Btn>
            <span className="font-mono text-[11px] text-sand-500">
              {deferred ? "beforeinstallprompt ক্যাপচার হয়েছে" : "প্রম্পট না এলে Chrome মেনু থেকে ম্যানুয়ালি ইনস্টল করুন"}
            </span>
          </div>
        </Panel>

        <Panel title="উপায় ২ — Capacitor দিয়ে আসল APK" step="B" icon={<IconTerminal />} subtitle="একদম ইন্সটেলেবল app-debug.apk তৈরির ধাপে ধাপে কমান্ড।">
          <div className="space-y-3">
            <div>
              <div className="label-xs mb-1.5">০. প্রি-রিকুইজিট</div>
              <CodeBlock
                label="prerequisites"
                code={`node -v        # 18+
java -version  # JDK 17
# Android Studio → SDK Platform 34 + Build-Tools + Platform-Tools
export ANDROID_HOME=$HOME/Android/Sdk`}
              />
            </div>
            <div>
              <div className="label-xs mb-1.5">১. স্টার্টার বান্ডল নামিয়ে প্রজেক্টে ঢুকুন</div>
              <CodeBlock
                label="setup"
                code={`unzip voicelab-android-apk-starter.zip
cd capacitor-app
npm install
cp env.example .env.local   # NEXT_PUBLIC_API_URL = আপনার সার্ভার`}
              />
            </div>
            <div>
              <div className="label-xs mb-1.5">২. ওয়েব বিল্ড → Android সিঙ্ক → APK</div>
              <CodeBlock
                label="build apk"
                code={`npm run build:web          # next build → dist/
npx cap add android        # প্রথমবার শুধু
npx cap sync android
cd android
./gradlew assembleDebug
# আউটপুট: android/app/build/outputs/apk/debug/app-debug.apk`}
              />
            </div>
            <div>
              <div className="label-xs mb-1.5">৩. ফোনে ইন্সটল</div>
              <CodeBlock
                label="install"
                code={`adb install -r app/build/outputs/apk/debug/app-debug.apk
# অথবা APK ফাইলটি ফোনে কপি করে ট্যাপ করুন
# (Settings → Install unknown apps → অনুমতি দিন)`}
              />
            </div>
            <div>
              <div className="label-xs mb-1.5">৪. রিলিজ (সাইন করা) APK / Play Store AAB</div>
              <CodeBlock
                label="release"
                code={`keytool -genkey -v -keystore voicelab.keystore -alias voicelab \\
  -keyalg RSA -keysize 2048 -validity 10000
# signing.gradle.snippet ফাইলটি android/app/build.gradle-এ যোগ করুন
./gradlew assembleRelease   # → app-release.apk
./gradlew bundleRelease     # → app-release.aab (Play Console)`}
              />
            </div>
            <div className="border border-signal/35 bg-signal/8 px-3 py-2.5 text-[12.5px] text-sand-200">
              <span className="mr-1.5 inline-flex text-signal">
                <IconInfo width={14} height={14} />
              </span>
              AndroidManifest-এ <code className="font-mono text-signal">RECORD_AUDIO</code> পারমিশন যোগ করতে ভুলবেন না
              (বান্ডলের ভেতরে স্নিপেট দেওয়া আছে)। না হলে মাইক কাজ করবে না।
            </div>
          </div>
        </Panel>

        <Panel title="উপায় ৩ — Bubblewrap / PWABuilder (TWA)" step="C" icon={<IconUpload />} tone="teal" subtitle="পাবলিক HTTPS ডোমেইন থাকলে Play Store-রেডি প্যাকেজ।">
          <div className="space-y-3">
            <CodeBlock
              label="bubblewrap"
              code={`npm i -g @bubblewrap/cli
bubblewrap init --manifest=https://YOUR-DOMAIN/manifest.webmanifest
bubblewrap build
# আউটপুট: app-release-signed.apk  +  app-release-bundle.aab`}
            />
            <p className="text-[12.5px] leading-relaxed text-sand-300">
              অথবা কোড ছাড়াই:{" "}
              <span className="font-mono text-teal">https://www.pwabuilder.com</span> এ আপনার URL দিন → “Android
              Package” → Signing key সহ APK/AAB ডাউনলোড। এই অ্যাপে{" "}
              <span className="font-mono text-sand-100">/manifest.webmanifest</span> ও{" "}
              <span className="font-mono text-sand-100">/sw.js</span> আগে থেকেই যুক্ত করা আছে, তাই PWABuilder
              সরাসরি প্যাকেজ বানাতে পারবে।
            </p>
          </div>
        </Panel>

        <Panel title="স্টার্টার বান্ডলের ভেতরে কী আছে" step="D" icon={<IconDownload />} subtitle="এক ক্লিকে ডাউনলোড — ZIP খুলে শুধু কমান্ড চালান।">
          <div className="mb-3">
            <a href="/api/apk-bundle" download>
              <Btn variant="primary" icon={<IconDownload />}>
                voicelab-android-apk-starter.zip
              </Btn>
            </a>
          </div>
          <table className="w-full font-mono text-[11.5px]">
            <tbody>
              {FILES.map((f) => (
                <tr key={f.f} className="border-b border-ink-800 last:border-0">
                  <td className="py-1.5 pr-3 text-sand-100">{f.f}</td>
                  <td className="py-1.5 text-right text-sand-500">{f.d}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>

      <Panel title="APK-তে কোন ফিচার কেমন চলবে" step="E" icon={<IconBolt />} subtitle="সব অডিও প্রসেসিং অন-ডিভাইস, তাই ইন্টারনেট ছাড়াও কাজ করে; শুধু সার্ভার লাইব্রেরির জন্য API URL লাগে।">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.t} className="flex items-start gap-2.5 border border-ink-700/70 bg-ink-900/50 px-3 py-2.5">
              <span className={f.ok ? "mt-[2px] text-lime" : "mt-[2px] text-signal"}>
                {f.ok ? <IconCheck width={14} height={14} /> : <IconInfo width={14} height={14} />}
              </span>
              <span>
                <span className="block text-[12.5px] text-sand-50">{f.t}</span>
                <span className="mt-0.5 block font-mono text-[10.5px] text-sand-500">{f.d}</span>
              </span>
            </div>
          ))}
        </div>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <div className="border border-ink-700/70 bg-ink-900/50 px-3 py-3">
            <div className="label-xs mb-1.5">ট্রাবলশুটিং</div>
            <ul className="space-y-1 text-[12px] text-sand-300">
              <li>• মাইক কাজ করছে না → AndroidManifest-এ RECORD_AUDIO + রানটাইম পারমিশন চেক করুন।</li>
              <li>• সাদা স্ক্রিন → <code className="font-mono text-signal">npx cap sync</code> আবার চালান, dist/ ফোল্ডার খালি কিনা দেখুন।</li>
              <li>• লাইব্রেরি লোড হচ্ছে না → <code className="font-mono text-signal">NEXT_PUBLIC_API_URL</code> সেট করুন এবং সার্ভারে CORS/HTTPS ঠিক রাখুন।</li>
              <li>• ডাউনলোড সেভ হচ্ছে না → স্টোরেজ পারমিশন দিন অথবা শেয়ার শিট ব্যবহার করুন।</li>
            </ul>
          </div>
          <div className="border border-ink-700/70 bg-ink-900/50 px-3 py-3">
            <div className="label-xs mb-1.5">দ্রুত চেকলিস্ট</div>
            <ol className="space-y-1 font-mono text-[11.5px] text-sand-300">
              <li>1. next.config → output: 'export', distDir: 'dist'</li>
              <li>2. capacitor.config.ts → webDir: 'dist'</li>
              <li>3. npx cap add android && npx cap sync</li>
              <li>4. ./gradlew assembleDebug</li>
              <li>5. adb install -r app-debug.apk</li>
            </ol>
          </div>
        </div>
      </Panel>
    </div>
  );
}

"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Badge, Btn, Chip, Panel, Row, Segmented, Slider, Stat } from "@/components/ui";
import {
  IconBolt,
  IconCheck,
  IconDownload,
  IconFan,
  IconLoop,
  IconPause,
  IconPlay,
  IconPlus,
  IconRedo,
  IconSave,
  IconScissors,
  IconSplit,
  IconStop,
  IconTrash,
  IconUndo,
  IconUpload,
  IconWave,
  IconZoomIn,
  IconZoomOut,
} from "@/components/icons";
import { Waveform, type Region } from "@/components/visuals";
import {
  clamp,
  detectSilence,
  extractRange,
  keepRanges,
  learnNoiseProfile,
  reduceNoise,
  removeSilence,
  splitBySilence,
  timecode,
  type NoiseProfile,
  type Range,
} from "@/lib/audio/dsp";
import { downloadBlob, wavBlob } from "@/lib/audio/wav";
import { api } from "@/lib/api";
import { useWorkspace } from "@/lib/store";
import { usePlayer } from "@/lib/usePlayer";
import { importFileIntoWorkspace, loadDemoIntoWorkspace, persistToServer } from "@/lib/workspaceActions";

type ManualRange = { id: string; start: number; end: number };

export default function EditorScreen() {
  const ws = useWorkspace();
  const router = useRouter();
  const samples = ws.samples;
  const sampleRate = ws.sampleRate;
  const player = usePlayer(samples, sampleRate);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const duration = samples ? samples.length / sampleRate : 0;
  const [view, setView] = useState<Range>({ start: 0, end: 1 });
  const [sel, setSel] = useState<Range | null>(null);
  const [tool, setTool] = useState<"silence" | "noise" | "split">("silence");

  /* silence removal */
  const [silMode, setSilMode] = useState<"db" | "sec">("db");
  const [silThreshold, setSilThreshold] = useState(-45);
  const [silMin, setSilMin] = useState(0.4);
  const [silKeep, setSilKeep] = useState(0.7);
  const [detected, setDetected] = useState<Range[]>([]);

  /* sample based noise removal */
  const [noiseSample, setNoiseSample] = useState<{ range: Range; profile: NoiseProfile } | null>(null);

  /* splitter */
  const [splitMode, setSplitMode] = useState<"auto" | "manual">("auto");
  const [autoOpts, setAutoOpts] = useState({ thresholdDb: -42, minSilenceSec: 0.3, minChunkSec: 0.5, maxChunks: 24 });
  const [chunks, setChunks] = useState<Range[]>([]);
  const [manual, setManual] = useState<ManualRange[]>([]);
  const [mStart, setMStart] = useState(0);
  const [mEnd, setMEnd] = useState(5);

  useEffect(() => {
    if (!samples) return;
    const d = samples.length / sampleRate;
    setView({ start: 0, end: d });
    setSel(null);
    setDetected([]);
    setChunks([]);
    setManual([{ id: "m1", start: 0, end: Math.min(d, Number((d / 3).toFixed(2))) }]);
    setMStart(0);
    setMEnd(Math.min(d, 5));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [samples]);

  const regions = useMemo<Region[]>(() => {
    const out: Region[] = [];
    for (const d of detected) out.push({ start: d.start, end: d.end, tone: "cut" });
    if (noiseSample) out.push({ start: noiseSample.range.start, end: noiseSample.range.end, tone: "noise" });
    for (const c of chunks) out.push({ start: c.start, end: c.end, tone: "chunk" });
    return out;
  }, [detected, noiseSample, chunks]);

  const zoom = useCallback(
    (factor: number) => {
      const span = view.end - view.start;
      const centre = player.position > view.start && player.position < view.end ? player.position : (view.start + view.end) / 2;
      const next = clamp(span * factor, 0.05, Math.max(duration, 1));
      setView({
        start: clamp(centre - next / 2, 0, Math.max(0, duration - next)),
        end: clamp(centre - next / 2 + next, 0, duration),
      });
    },
    [view, player.position, duration],
  );

  /* --------------------------------------------------------- operations */

  const scanSilence = () => {
    if (!samples) return;
    const found = detectSilence(samples, sampleRate, { thresholdDb: silThreshold, minSec: silMin });
    setDetected(found);
    ws.notify(
      found.length
        ? `${found.length}টি সাইলেন্ট অংশ পাওয়া গেছে — মোট ${found.reduce((a, r) => a + (r.end - r.start), 0).toFixed(2)}s`
        : "এই সেটিংসে কোনো সাইলেন্স পাওয়া যায়নি — থ্রেশহোল্ড বাড়ান।",
      found.length ? "ok" : "warn",
    );
  };

  const applySilence = async () => {
    if (!samples) return;
    const t0 = performance.now();
    ws.setBusy("সাইলেন্স কাটা হচ্ছে…");
    await new Promise((r) => setTimeout(r, 20));
    const res = removeSilence(samples, sampleRate, {
      thresholdDb: silThreshold,
      minSilenceSec: silMin,
      keepSec: silMode === "sec" ? silKeep : null,
      padMs: 20,
    });
    ws.setBusy(null);
    if (res.removed.length === 0) {
      ws.notify("কাটার মতো কোনো সাইলেন্স নেই — আগে স্ক্যান করুন।", "warn");
      return;
    }
    ws.setAudio(res.samples, silMode === "sec" ? `সেকেন্ড-লিমিট সাইলেন্স রিমুভ (${res.removedSec.toFixed(2)}s)` : `dB সাইলেন্স রিমুভ (${res.removedSec.toFixed(2)}s)`);
    setDetected([]);
    ws.setStatus("cleaned");
    ws.setLastOperation(`${res.removed.length}টি সাইলেন্ট অংশ বাদ`);
    ws.notify(`${res.removedSec.toFixed(2)} সেকেন্ড সাইলেন্স বাদ — নতুন দৈর্ঘ্য ${timecode(res.samples.length / sampleRate)}`);
    await api
      .addLog({
        projectId: ws.projectId,
        operation: silMode === "sec" ? "silence-limit-mode" : "silence-db-mode",
        label: `${res.removed.length}টি অংশ বাদ`,
        params: { thresholdDb: silThreshold, minSilenceSec: silMin, keepSec: silMode === "sec" ? silKeep : null },
        result: { removedSec: Number(res.removedSec.toFixed(3)), beforeSec: Number(duration.toFixed(2)), afterSec: Number((res.samples.length / sampleRate).toFixed(2)) },
        durationMs: Math.round(performance.now() - t0),
      })
      .catch(() => undefined);
  };

  const takeNoiseSample = () => {
    if (!samples) return;
    if (!sel || sel.end - sel.start < 0.25) {
      ws.notify("অন্তত ০.২৫ সেকেন্ডের একটি অংশ ওয়েভফর্মে সিলেক্ট করুন (শুধু নয়েজ আছে এমন জায়গা)।", "warn");
      return;
    }
    const raw = extractRange(samples, sampleRate, sel, 0);
    const profile = learnNoiseProfile(raw, sampleRate, 2048);
    setNoiseSample({ range: { ...sel }, profile });
    ws.setNoiseProfile(profile, raw);
    ws.notify(`নয়েজ স্যাম্পল শেখা শেষ — ফ্লোর ${profile.avgDb.toFixed(1)} dB। এখন "পুরো ফাইলে প্রয়োগ" চাপুন।`);
  };

  const applyNoiseSample = async () => {
    if (!samples || !noiseSample) return;
    const t0 = performance.now();
    ws.setBusy("স্পেকট্রাল সাবট্রাকশন চলছে…");
    await new Promise((r) => setTimeout(r, 20));
    const out = reduceNoise(samples, sampleRate, noiseSample.profile, { ...ws.suppress, strength: ws.suppress.strength });
    ws.setBusy(null);
    ws.setAudio(out, "স্যাম্পল-বেসড নয়েজ রিমুভ");
    ws.setStatus("cleaned");
    ws.notify("স্যাম্পল থেকে শেখা নয়েজ পুরো ফাইল থেকে এক ক্লিকে মুছে ফেলা হয়েছে।");
    await api
      .addLog({
        projectId: ws.projectId,
        operation: "sample-noise-removal",
        label: `${(noiseSample.range.end - noiseSample.range.start).toFixed(2)}s স্যাম্পল থেকে`,
        params: { range: noiseSample.range, strength: ws.suppress.strength, floorDb: ws.suppress.floorDb },
        result: { beforeDb: Number(ws.stats?.rmsDb.toFixed(2) ?? 0), ms: Math.round(performance.now() - t0) },
        durationMs: Math.round(performance.now() - t0),
      })
      .catch(() => undefined);
  };

  const runAutoSplit = () => {
    if (!samples) return;
    const res = splitBySilence(samples, sampleRate, autoOpts);
    setChunks(res.ranges);
    ws.notify(`${res.ranges.length}টি টুকরো তৈরি — ${res.silences.length}টি সাইলেন্ট গ্যাপ স্ক্যান হয়েছে (সীমা ${autoOpts.maxChunks})।`);
  };

  const addManual = () => {
    const a = Math.min(mStart, mEnd);
    const b = Math.max(mStart, mEnd);
    if (b - a < 0.02) {
      ws.notify("টাইম রেঞ্জ কমপক্ষে ০.০২ সেকেন্ড হতে হবে।", "warn");
      return;
    }
    if (b > duration) {
      ws.notify(`রেঞ্জ অডিওর বাইরে চলে গেছে (দৈর্ঘ্য ${duration.toFixed(2)}s)।`, "warn");
      return;
    }
    setManual((m) => [...m, { id: `m${Date.now()}`, start: Number(a.toFixed(3)), end: Number(b.toFixed(3)) }]);
    setMStart(Number(b.toFixed(2)));
    setMEnd(Number(Math.min(duration, b + 5).toFixed(2)));
  };

  const renderChunks = (ranges: Range[], prefix: string) => {
    if (!samples) return;
    const list = ranges.slice(0, 100);
    list.forEach((r, i) => {
      const data = extractRange(samples, sampleRate, r, 4);
      setTimeout(() => downloadBlob(wavBlob(data, sampleRate), `${prefix}-${String(i + 1).padStart(2, "0")}.wav`), i * 260);
    });
    ws.notify(`${list.length}টি WAV টুকরো ডাউনলোড হচ্ছে…`, "ok");
  };

  const keepOnlyRanges = (ranges: Range[]) => {
    if (!samples || !ranges.length) return;
    const out = keepRanges(samples, sampleRate, ranges, 6);
    ws.setAudio(out, `${ranges.length}টি রেঞ্জ রাখা হয়েছে`);
    ws.notify(`নির্বাচিত ${ranges.length}টি রেঞ্জ জোড়া দিয়ে নতুন ফাইল তৈরি হয়েছে।`);
  };

  const saveChunksToServer = async (ranges: Range[]) => {
    if (!samples) return;
    let projectId = ws.projectId;
    ws.setBusy("টুকরো সার্ভারে আপলোড হচ্ছে…");
    if (!projectId) {
      const saved = await persistToServer({
        samples,
        sampleRate,
        title: ws.title,
        status: ws.status === "empty" ? "raw" : ws.status,
        noiseProfile: ws.noiseProfile,
        kind: "processed",
        label: "এডিট মাস্টার",
      });
      projectId = saved?.projectId ?? null;
    }
    if (!projectId) {
      ws.setBusy(null);
      return;
    }
    const list = ranges.slice(0, 24);
    for (let i = 0; i < list.length; i += 1) {
      const data = extractRange(samples, sampleRate, list[i], 4);
      await api
        .uploadAudio(projectId, {
          kind: "chunk",
          label: `টুকরো ${String(i + 1).padStart(2, "0")}`,
          samples: data,
          sampleRate,
          startSec: list[i].start,
          endSec: list[i].end,
        })
        .catch(() => undefined);
    }
    await api
      .addLog({
        projectId,
        operation: splitMode === "auto" ? "auto-split" : "manual-split",
        label: `${list.length}টি টুকরো আপলোড`,
        params: splitMode === "auto" ? autoOpts : { ranges: list },
        result: { chunks: list.length },
      })
      .catch(() => undefined);
    ws.setBusy(null);
    ws.notify(`${list.length}টি টুকরো সার্ভারে সেভ হয়েছে${ranges.length > 24 ? " (প্রথম ২৪টি)" : ""}।`);
  };

  const saveMaster = async () => {
    if (!samples) return;
    ws.setBusy("মাস্টার সেভ হচ্ছে…");
    const res = await persistToServer({
      samples,
      sampleRate,
      title: ws.title,
      status: ws.status === "empty" ? "raw" : ws.status,
      projectId: ws.projectId,
      noiseProfile: ws.noiseProfile,
      kind: "processed",
      label: "এডিট মাস্টার",
    });
    ws.setBusy(null);
    ws.setDirty(false);
    if (res) ws.notify("এডিট করা অডিও সার্ভারে সেভ হয়েছে।");
  };

  /* --------------------------------------------------------------- view */

  if (!samples) {
    return (
      <div className="space-y-4">
        <Panel title="এডিটর" step="02" icon={<IconWave />} subtitle="ওয়েভফর্ম, সাইলেন্স রিমুভাল ও স্প্লিটার।">
          <div className="flex flex-col items-start gap-4 border border-dashed border-ink-700 bg-ink-900/40 px-5 py-10">
            <div>
              <h2 className="font-display text-[22px] font-600 text-sand-50">ওয়ার্কস্পেস খালি</h2>
              <p className="mt-1 max-w-xl text-[13px] text-sand-300">
                এডিটর ব্যবহার করতে একটি রেকর্ডিং দরকার। নিচের যেকোনো উপায়ে অডিও লোড করুন — তারপর ওয়েভফর্মে
                ড্র্যাগ করে সিলেকশন নিয়ে সাইলেন্স রিমুভ, স্যাম্পল-বেসড নয়েজ রিমুভ ও স্প্লিটিং করা যাবে।
              </p>
            </div>
            <Row>
              <Btn variant="primary" icon={<IconBolt />} onClick={() => loadDemoIntoWorkspace(26)}>
                ডেমো অডিও লোড করুন
              </Btn>
              <Btn icon={<IconUpload />} onClick={() => fileRef.current?.click()}>
                ফাইল ইমপোর্ট
              </Btn>
              <Link href="/">
                <Btn icon={<IconSplit />}>রেকর্ডার খুলুন</Btn>
              </Link>
              <Link href="/library">
                <Btn variant="ghost">লাইব্রেরি</Btn>
              </Link>
              <input
                ref={fileRef}
                type="file"
                accept="audio/*"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (f) await importFileIntoWorkspace(f);
                  e.target.value = "";
                }}
              />
            </Row>
          </div>
        </Panel>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* toolbar */}
      <div className="panel panel-notch flex flex-wrap items-center gap-3 px-4 py-3">
        <div className="flex min-w-[190px] flex-1 items-center gap-2">
          <span className="label-xs">প্রজেক্ট</span>
          <input
            value={ws.title}
            onChange={(e) => ws.setTitle(e.target.value)}
            className="w-full max-w-[320px] border border-transparent bg-transparent px-2 py-1 font-display text-[15px] text-sand-50 outline-none transition-colors hover:border-ink-700 focus:border-signal/60"
          />
          <Badge tone={ws.dirty ? "signal" : "teal"}>{ws.dirty ? "পরিবর্তন আছে" : ws.status}</Badge>
        </div>
        <Row>
          <Btn size="sm" icon={<IconUndo width={14} height={14} />} disabled={!ws.past.length} onClick={ws.undo}>
            আনডু ({ws.past.length})
          </Btn>
          <Btn size="sm" icon={<IconRedo width={14} height={14} />} disabled={!ws.future.length} onClick={ws.redo}>
            রিডু
          </Btn>
          <Btn size="sm" variant="teal" icon={<IconSave width={14} height={14} />} onClick={saveMaster}>
            সার্ভারে সেভ
          </Btn>
          <Btn size="sm" icon={<IconDownload width={14} height={14} />} onClick={() => downloadBlob(wavBlob(samples, sampleRate), `${ws.title}.wav`)}>
            WAV ডাউনলোড
          </Btn>
          <Btn size="sm" variant="ghost" onClick={() => router.push("/effects")}>
            ইফেক্টস →
          </Btn>
        </Row>
      </div>

      {/* waveform deck */}
      <Panel
        title="ওয়েভফর্ম"
        step="03"
        icon={<IconWave />}
        right={
          <div className="flex items-center gap-3">
            <span className="readout text-[12px]">{timecode(player.position)}</span>
            <span className="font-mono text-[10.5px] text-sand-500">/ {timecode(duration)}</span>
          </div>
        }
      >
        <div className="space-y-3">
          <Waveform
            samples={samples}
            sampleRate={sampleRate}
            height={190}
            view={view}
            selection={sel}
            onSelect={setSel}
            playhead={player.position}
            onSeek={player.seek}
            regions={regions}
            markers={chunks.map((c) => c.start)}
          />

          <div className="flex flex-wrap items-center gap-2">
            <Btn size="sm" variant={player.playing ? "danger" : "primary"} icon={player.playing ? <IconPause width={14} height={14} /> : <IconPlay width={14} height={14} />} onClick={() => (player.playing ? player.pause() : player.play(sel?.start ?? player.position, sel?.end))}>
              {player.playing ? "পজ" : sel ? "সিলেকশন প্লে" : "প্লে"}
            </Btn>
            <Btn size="sm" icon={<IconStop width={14} height={14} />} onClick={player.stop}>
              স্টপ
            </Btn>
            <Chip active={player.loop} onClick={() => player.setLoop(!player.loop)}>
              <span className="inline-flex items-center gap-1">
                <IconLoop width={12} height={12} /> লুপ
              </span>
            </Chip>
            <span className="mx-1 h-5 w-px bg-ink-700" />
            <Btn size="sm" icon={<IconZoomOut width={14} height={14} />} onClick={() => zoom(1.6)}>
              জুম আউট
            </Btn>
            <Btn size="sm" icon={<IconZoomIn width={14} height={14} />} onClick={() => zoom(0.62)}>
              জুম ইন
            </Btn>
            <Btn size="sm" variant="ghost" onClick={() => setView({ start: 0, end: duration })}>
              ফিট
            </Btn>
            {sel && (
              <Btn size="sm" variant="ghost" onClick={() => setView({ start: sel.start, end: sel.end })}>
                সিলেকশনে জুম
              </Btn>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <Stat label="সিলেকশন শুরু" value={sel ? timecode(sel.start) : "—"} />
            <Stat label="সিলেকশন শেষ" value={sel ? timecode(sel.end) : "—"} />
            <Stat label="সিলেকশন দৈর্ঘ্য" value={sel ? (sel.end - sel.start).toFixed(2) : "0.00"} unit="s" tone="teal" />
            <Stat label="মোট দৈর্ঘ্য" value={timecode(duration)} tone="signal" />
          </div>
        </div>
      </Panel>

      {/* tool rack */}
      <div className="grid gap-4 xl:grid-cols-[260px_minmax(0,1fr)]">
        <div className="space-y-2">
          {(
            [
              { id: "silence", label: "সাইলেন্স রিমুভাল", icon: <IconMuteGlyph />, note: "ডুয়েল মোড" },
              { id: "noise", label: "স্যাম্পল নয়েজ রিমুভ", icon: <IconFan width={16} height={16} />, note: "এক ক্লিকে" },
              { id: "split", label: "স্প্লিটার", icon: <IconSplit width={16} height={16} />, note: "১০০ টুকরো" },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTool(t.id)}
              className={`flex w-full items-center gap-3 border px-3 py-3 text-left transition-all ${
                tool === t.id
                  ? "border-signal/60 bg-signal/10 text-sand-50 shadow-[inset_2px_0_0_0_#ffa23a]"
                  : "border-ink-700 bg-ink-850/60 text-sand-300 hover:border-ink-600 hover:text-sand-100"
              }`}
            >
              <span className={tool === t.id ? "text-signal" : "text-sand-500"}>{t.icon}</span>
              <span className="flex-1">
                <span className="block font-display text-[13px] tracking-wide">{t.label}</span>
                <span className="block font-mono text-[10px] text-sand-500 uppercase">{t.note}</span>
              </span>
            </button>
          ))}

          <div className="panel mt-3 px-3 py-3">
            <div className="label-xs mb-2">অ্যানালাইসিস</div>
            <div className="space-y-1.5 font-mono text-[11.5px] text-sand-300">
              <Line k="পিক" v={`${ws.stats?.peakDb.toFixed(1) ?? "—"} dB`} />
              <Line k="RMS" v={`${ws.stats?.rmsDb.toFixed(1) ?? "—"} dB`} />
              <Line k="ডাইনামিক রেঞ্জ" v={`${ws.stats?.dynamicRangeDb.toFixed(1) ?? "—"} dB`} />
              <Line k="সাইলেন্স (<-45dB)" v={`${ws.stats?.silenceSec.toFixed(2) ?? "0"} s`} />
              <Line k="নয়েজ ফ্লোর (P10)" v={`${ws.stats?.noiseFloorDb.toFixed(1) ?? "—"} dB`} />
              <Line k="ক্লিপড স্যাম্পল" v={`${ws.stats?.clipped ?? 0}`} />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {tool === "silence" && (
            <Panel
              title="ডুয়েল মোড সাইলেন্স রিমুভাল"
              step="04"
              icon={<IconScissors />}
              subtitle="dB মোডে থ্রেশহোল্ডের নিচের সব চুপ অংশ কাটে; সেকেন্ড-লিমিট মোডে প্রতিটি বিরতি নির্দিষ্ট দৈর্ঘ্য পর্যন্ত ছেঁটে দেয়।"
            >
              <div className="space-y-4">
                <Segmented
                  value={silMode}
                  onChange={(v) => setSilMode(v)}
                  options={[
                    { value: "db", label: "dB মোড — পুরোপুরি কাটো", hint: "থ্রেশহোল্ডের নিচের সাইলেন্স সম্পূর্ণ বাদ" },
                    { value: "sec", label: "সেকেন্ড লিমিট মোড", hint: "প্রতিটি বিরতি সর্বোচ্চ N সেকেন্ড রাখো" },
                  ]}
                />
                <div className="grid gap-4 sm:grid-cols-2">
                  <Slider label="সাইলেন্স থ্রেশহোল্ড" value={silThreshold} min={-70} max={-20} step={1} unit=" dB" format={(v) => v.toFixed(0)} onChange={setSilThreshold} hint="এর নিচের লেভেল চুপ হিসেবে গণ্য হবে।" />
                  <Slider label="ন্যূনতম সাইলেন্স দৈর্ঘ্য" value={silMin} min={0.1} max={3} step={0.05} unit=" s" format={(v) => v.toFixed(2)} onChange={setSilMin} hint="এর চেয়ে ছোট বিরতি ছোঁওয়া হবে না (শব্দের মাঝের গ্যাপ রক্ষা পায়)।" />
                </div>
                {silMode === "sec" && (
                  <Slider
                    label="বিরতি সর্বোচ্চ কত সেকেন্ড রাখবেন"
                    value={silKeep}
                    min={0.1}
                    max={3}
                    step={0.05}
                    unit=" s"
                    tone="teal"
                    format={(v) => v.toFixed(2)}
                    onChange={setSilKeep}
                    hint='যেমন ০.৭০ সেকেন্ড — "২ সেকেন্ডের বেশি চুপ থাকলে বাকিটা রিমুভ করো" টাইপ সেটআপ।'
                  />
                )}
                <Row>
                  <Btn icon={<IconWave />} onClick={scanSilence}>
                    সাইলেন্স খুঁজে দেখুন
                  </Btn>
                  <Btn variant="primary" icon={<IconScissors />} onClick={applySilence}>
                    {silMode === "sec" ? "লিমিট করে কাটুন" : "সাইলেন্স রিমুভ করুন"}
                  </Btn>
                  {detected.length > 0 && (
                    <Btn variant="ghost" onClick={() => setDetected([])}>
                      মার্কার মুছুন
                    </Btn>
                  )}
                </Row>
                {detected.length > 0 && (
                  <div className="max-h-[190px] overflow-auto border border-ink-700/70 bg-ink-900/60">
                    <table className="w-full font-mono text-[11.5px]">
                      <thead className="sticky top-0 bg-ink-850 text-sand-500">
                        <tr>
                          <th className="px-2 py-1.5 text-left">#</th>
                          <th className="px-2 py-1.5 text-left">শুরু</th>
                          <th className="px-2 py-1.5 text-left">শেষ</th>
                          <th className="px-2 py-1.5 text-left">দৈর্ঘ্য</th>
                          <th className="px-2 py-1.5 text-left"> </th>
                        </tr>
                      </thead>
                      <tbody>
                        {detected.slice(0, 200).map((d, i) => (
                          <tr key={`${d.start}-${i}`} className="border-t border-ink-800 text-sand-300 hover:bg-ink-800/60">
                            <td className="px-2 py-1 text-sand-500">{i + 1}</td>
                            <td className="px-2 py-1">{timecode(d.start)}</td>
                            <td className="px-2 py-1">{timecode(d.end)}</td>
                            <td className="px-2 py-1 text-rec">{(d.end - d.start).toFixed(2)}s</td>
                            <td className="px-2 py-1">
                              <button type="button" className="text-teal hover:underline" onClick={() => player.play(d.start, d.end)}>
                                শুনুন
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </Panel>
          )}

          {tool === "noise" && (
            <Panel
              title="স্যাম্পল বেসড নয়েজ রিমুভ"
              step="05"
              icon={<IconFan />}
              tone="signal"
              subtitle="অডিওর যেকোনো অংশ সিলেক্ট করে নয়েজ স্যাম্পল বানান — তারপর এক ক্লিকে পুরো ফাইল থেকে সেই নয়েজ মুছে ফেলুন।"
            >
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 border border-ink-700/70 bg-ink-900/60 px-3 py-2.5">
                  <div className="font-mono text-[12px] text-sand-300">
                    সিলেকশন: <span className="text-signal">{sel ? `${timecode(sel.start)} → ${timecode(sel.end)}` : "নেই"}</span>
                    {sel && <span className="text-sand-500"> ({(sel.end - sel.start).toFixed(2)}s)</span>}
                  </div>
                  <Row>
                    <Btn size="sm" icon={<IconFan />} onClick={takeNoiseSample} disabled={!sel}>
                      এই অংশকে নয়েজ স্যাম্পল বানাও
                    </Btn>
                    {noiseSample && (
                      <Btn size="sm" variant="primary" icon={<IconCheck />} onClick={applyNoiseSample}>
                        পুরো ফাইলে প্রয়োগ করুন
                      </Btn>
                    )}
                  </Row>
                </div>

                {noiseSample ? (
                  <div className="grid gap-3 sm:grid-cols-3">
                    <Stat label="স্যাম্পল দৈর্ঘ্য" value={(noiseSample.range.end - noiseSample.range.start).toFixed(2)} unit="s" />
                    <Stat label="নয়েজ ফ্লোর" value={noiseSample.profile.avgDb.toFixed(1)} unit="dB" tone="signal" />
                    <Stat label="প্রিন্ট পিক" value={noiseSample.profile.peakDb.toFixed(1)} unit="dB" tone="teal" />
                  </div>
                ) : (
                  <p className="text-[12.5px] text-sand-500">
                    টিপস: রেকর্ডিংয়ের যে অংশে শুধু ফ্যান/AC/হাম আছে (কথা নেই) সেখানে ড্র্যাগ করে সিলেকশন নিন। অন্তত
                    ০.২৫ সেকেন্ড দরকার, ১ সেকেন্ড হলে সবচেয়ে নির্ভুল প্রিন্ট পাওয়া যায়।
                  </p>
                )}

                <div className="grid gap-4 sm:grid-cols-3">
                  <Slider label="স্ট্রেংথ" value={ws.suppress.strength} min={1} max={4} step={0.1} unit="×" format={(v) => v.toFixed(1)} onChange={(v) => ws.setSuppress({ strength: v })} />
                  <Slider label="ম্যাক্স অ্যাটেনুয়েশন" value={ws.suppress.floorDb} min={-48} max={-6} step={1} unit=" dB" format={(v) => v.toFixed(0)} onChange={(v) => ws.setSuppress({ floorDb: v })} />
                  <Slider label="স্মুদিং" value={ws.suppress.smoothing} min={0} max={0.9} step={0.05} format={(v) => v.toFixed(2)} onChange={(v) => ws.setSuppress({ smoothing: v })} />
                </div>

                {ws.noiseProfile && (
                  <div className="flex flex-wrap items-center gap-2 border border-ink-700/70 bg-ink-900/40 px-3 py-2 text-[12px] text-sand-300">
                    <Badge tone="teal">রেকর্ডার প্রিন্ট</Badge>
                    {ws.noiseProfile.avgDb.toFixed(1)} dB · {ws.noiseProfile.learnedSec.toFixed(1)}s শেখা
                    <Btn
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setNoiseSample({ range: { start: 0, end: ws.noiseProfile!.learnedSec }, profile: ws.noiseProfile! });
                        ws.notify("রেকর্ডারের শেখা নয়েজ প্রিন্ট এডিটরে লোড হয়েছে।");
                      }}
                    >
                      এডিটরে ব্যবহার করুন
                    </Btn>
                  </div>
                )}
              </div>
            </Panel>
          )}

          {tool === "split" && (
            <Panel
              title="ফ্লেক্সিবল অডিও স্প্লিটার"
              step="06"
              icon={<IconSplit />}
              tone="teal"
              subtitle="সাইলেন্স অনুযায়ী অটো ভাগ অথবা নিজের টাইম রেঞ্জ লিখে '+' চেপে যত খুশি স্লট যোগ করুন।"
            >
              <div className="space-y-4">
                <Segmented
                  value={splitMode}
                  onChange={(v) => setSplitMode(v)}
                  options={[
                    { value: "auto", label: "অটো সাইলেন্স স্প্লিট" },
                    { value: "manual", label: "ম্যানুয়াল টাইম রেঞ্জ (+)" },
                  ]}
                />

                {splitMode === "auto" ? (
                  <>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Slider label="গ্যাপ থ্রেশহোল্ড" value={autoOpts.thresholdDb} min={-70} max={-20} step={1} unit=" dB" format={(v) => v.toFixed(0)} onChange={(v) => setAutoOpts((o) => ({ ...o, thresholdDb: v }))} />
                      <Slider label="ন্যূনতম গ্যাপ দৈর্ঘ্য" value={autoOpts.minSilenceSec} min={0.05} max={2} step={0.05} unit=" s" format={(v) => v.toFixed(2)} onChange={(v) => setAutoOpts((o) => ({ ...o, minSilenceSec: v }))} />
                      <Slider label="টুকরোর ন্যূনতম দৈর্ঘ্য" value={autoOpts.minChunkSec} min={0.1} max={5} step={0.1} unit=" s" format={(v) => v.toFixed(1)} onChange={(v) => setAutoOpts((o) => ({ ...o, minChunkSec: v }))} />
                      <Slider label="সর্বোচ্চ টুকরো" value={autoOpts.maxChunks} min={2} max={100} step={1} onChange={(v) => setAutoOpts((o) => ({ ...o, maxChunks: Math.round(v) }))} hint="১০০ পর্যন্ত ভাগ করা যায় — বেশি গ্যাপ পাওয়া গেলে গভীরতম গ্যাপগুলো বেছে নেওয়া হয়।" />
                    </div>
                    <Row>
                      <Btn variant="primary" icon={<IconSplit />} onClick={runAutoSplit}>
                        টুকরো করুন
                      </Btn>
                      {chunks.length > 0 && (
                        <>
                          <Btn icon={<IconDownload />} onClick={() => renderChunks(chunks, `${ws.title}-auto`)}>
                            সব WAV ডাউনলোড ({chunks.length})
                          </Btn>
                          <Btn icon={<IconSave />} onClick={() => saveChunksToServer(chunks)}>
                            সার্ভারে সেভ
                          </Btn>
                          <Btn variant="ghost" icon={<IconScissors />} onClick={() => keepOnlyRanges(chunks)}>
                            শুধু টুকরো রেখে নতুন ফাইল
                          </Btn>
                        </>
                      )}
                    </Row>
                  </>
                ) : (
                  <>
                    <div className="flex flex-wrap items-end gap-3 border border-ink-700/70 bg-ink-900/60 px-3 py-3">
                      <div className="space-y-1">
                        <span className="label-xs">শুরু (সেকেন্ড)</span>
                        <input
                          type="number"
                          step="0.1"
                          min={0}
                          max={duration}
                          value={mStart}
                          onChange={(e) => setMStart(Number(e.target.value))}
                          className="readout w-[120px] border border-ink-700 bg-ink-950 px-2 py-1.5 text-[13px] outline-none focus:border-teal/70"
                        />
                      </div>
                      <div className="space-y-1">
                        <span className="label-xs">শেষ (সেকেন্ড)</span>
                        <input
                          type="number"
                          step="0.1"
                          min={0}
                          max={duration}
                          value={mEnd}
                          onChange={(e) => setMEnd(Number(e.target.value))}
                          className="readout w-[120px] border border-ink-700 bg-ink-950 px-2 py-1.5 text-[13px] outline-none focus:border-teal/70"
                        />
                      </div>
                      <Btn variant="teal" icon={<IconPlus />} onClick={addManual}>
                        রেঞ্জ যোগ করুন (+)
                      </Btn>
                      <Btn
                        variant="ghost"
                        onClick={() => {
                          if (!sel) return ws.notify("আগে ওয়েভফর্মে একটি অংশ সিলেক্ট করুন।", "warn");
                          setMStart(Number(sel.start.toFixed(2)));
                          setMEnd(Number(sel.end.toFixed(2)));
                        }}
                      >
                        সিলেকশন থেকে নাও
                      </Btn>
                      <span className="font-mono text-[11px] text-sand-500">
                        উদাহরণ: ১ → ২০, তারপর ২০ → ৩০ … প্রতিবার '+' চাপলে নতুন স্লট যোগ হয়।
                      </span>
                    </div>

                    {manual.length > 0 && (
                      <div className="space-y-1.5">
                        {manual.map((m, i) => (
                          <div key={m.id} className="flex items-center gap-2 border border-ink-700/70 bg-ink-900/50 px-2.5 py-1.5">
                            <span className="readout w-8 text-signal">{String(i + 1).padStart(2, "0")}</span>
                            <span className="readout flex-1 text-[12px] text-sand-100">
                              {timecode(m.start)} → {timecode(m.end)}
                              <span className="ml-2 text-sand-500">({(m.end - m.start).toFixed(2)}s)</span>
                            </span>
                            <Btn size="sm" variant="ghost" icon={<IconPlay width={12} height={12} />} onClick={() => player.play(m.start, m.end)}>
                              শুনুন
                            </Btn>
                            <Btn
                              size="sm"
                              variant="ghost"
                              icon={<IconDownload width={12} height={12} />}
                              onClick={() => downloadBlob(wavBlob(extractRange(samples, sampleRate, m, 4), sampleRate), `${ws.title}-slot-${i + 1}.wav`)}
                            >
                              WAV
                            </Btn>
                            <Btn size="sm" variant="ghost" icon={<IconTrash width={12} height={12} />} onClick={() => setManual((list) => list.filter((x) => x.id !== m.id))} />
                          </div>
                        ))}
                        <Row className="mt-2">
                          <Btn variant="primary" icon={<IconDownload />} onClick={() => renderChunks(manual, `${ws.title}-slot`)}>
                            সব স্লট ডাউনলোড ({manual.length})
                          </Btn>
                          <Btn icon={<IconScissors />} onClick={() => keepOnlyRanges(manual)}>
                            এই রেঞ্জগুলো দিয়ে নতুন ফাইল
                          </Btn>
                          <Btn icon={<IconSave />} onClick={() => saveChunksToServer(manual)}>
                            সার্ভারে সেভ
                          </Btn>
                          <Btn variant="ghost" icon={<IconTrash />} onClick={() => setManual([])}>
                            সব মুছুন
                          </Btn>
                        </Row>
                      </div>
                    )}
                  </>
                )}

                {splitMode === "auto" && chunks.length > 0 && (
                  <div className="grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
                    {chunks.slice(0, 100).map((c, i) => (
                      <div key={`${c.start}-${i}`} className="flex items-center gap-2 border border-teal/25 bg-teal/5 px-2.5 py-1.5">
                        <span className="readout text-[12px] text-teal">{String(i + 1).padStart(2, "0")}</span>
                        <span className="readout flex-1 text-[11.5px] text-sand-200">
                          {timecode(c.start, false)}–{timecode(c.end, false)} · {(c.end - c.start).toFixed(1)}s
                        </span>
                        <button type="button" className="text-sand-500 transition-colors hover:text-signal" onClick={() => player.play(c.start, c.end)} title="শুনুন">
                          <IconPlay width={12} height={12} />
                        </button>
                        <button
                          type="button"
                          className="text-sand-500 transition-colors hover:text-teal"
                          title="ডাউনলোড"
                          onClick={() => downloadBlob(wavBlob(extractRange(samples, sampleRate, c, 4), sampleRate), `${ws.title}-auto-${i + 1}.wav`)}
                        >
                          <IconDownload width={12} height={12} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex items-start gap-2 border border-ink-700/70 bg-ink-900/50 px-3 py-2.5 text-[12px] leading-relaxed text-sand-300">
                  <IconSplit width={14} height={14} className="mt-[2px] shrink-0 text-teal" />
                  প্রতিটি টুকরো আলাদা WAV হিসেবে ডাউনলোড হয়; “সার্ভারে সেভ” চাপলে সেগুলো প্রজেক্টের{" "}
                  <span className="font-mono text-teal">chunk</span> অ্যাসেট হিসেবে জমা হয় ও লাইব্রেরিতে দেখা যায়
                  (একবারে সর্বোচ্চ ২৪টি আপলোড, এক্সপোর্ট ১০০টি পর্যন্ত)।
                </div>
              </div>
            </Panel>
          )}
        </div>
      </div>
    </div>
  );
}

function Line({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-sand-500">{k}</span>
      <span className="text-sand-100">{v}</span>
    </div>
  );
}

function IconMuteGlyph() {
  return (
    <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 9.5h3.5L12 5.5v13L7.5 14.5H4z" />
      <path d="m16 9.5 5 5M21 9.5l-5 5" />
    </svg>
  );
}

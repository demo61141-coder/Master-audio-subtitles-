"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Btn, Chip, CodeBlock, Panel, Row, Slider, Stat } from "@/components/ui";
import {
  IconBolt,
  IconCheck,
  IconDownload,
  IconFan,
  IconPlay,
  IconSave,
  IconWand,
  IconWave,
} from "@/components/icons";
import { Waveform } from "@/components/visuals";
import {
  analyze,
  autoLevel,
  normalizePeak,
  normalizeRms,
  reduceNoise,
  timecode,
  type Analysis,
} from "@/lib/audio/dsp";
import { enhancePresets, presetById, renderEnhanced, type EnhanceConfig } from "@/lib/audio/enhance";
import { downloadBlob, wavBlob } from "@/lib/audio/wav";
import { api, type PresetRow } from "@/lib/api";
import { useWorkspace } from "@/lib/store";
import { usePlayer } from "@/lib/usePlayer";
import { persistToServer } from "@/lib/workspaceActions";

export default function EffectsScreen() {
  const ws = useWorkspace();
  const router = useRouter();
  const samples = ws.samples;
  const sampleRate = ws.sampleRate;
  const original = ws.original ?? samples;

  const player = usePlayer(samples, sampleRate);
  const origPlayer = usePlayer(original, sampleRate);
  const [preview, setPreview] = useState<Float32Array | null>(null);
  const previewPlayer = usePlayer(preview, sampleRate);
  const [dbPresets, setDbPresets] = useState<PresetRow[]>([]);

  /* levelling */
  const [target, setTarget] = useState(-18);
  const [maxBoost, setMaxBoost] = useState(18);
  const [maxCut, setMaxCut] = useState(12);
  const [windowMs, setWindowMs] = useState(60);
  const [smoothing, setSmoothing] = useState(0.75);

  const before = useMemo<Analysis | null>(() => (original ? analyze(original, sampleRate) : null), [original, sampleRate]);
  const after = ws.stats;

  useEffect(() => {
    api.listPresets().then(setDbPresets).catch(() => undefined);
  }, []);

  useEffect(() => {
    setPreview(null);
  }, [samples]);

  const stopAll = () => {
    player.stop();
    origPlayer.stop();
    previewPlayer.stop();
  };

  async function renderPreview() {
    if (!samples) return;
    ws.setBusy("AI ভয়েস এনহ্যান্সার রেন্ডার হচ্ছে…");
    const t0 = performance.now();
    try {
      const out = await renderEnhanced(samples, sampleRate, ws.enhance);
      setPreview(out);
      ws.notify(`প্রিভিউ তৈরি (${Math.round(performance.now() - t0)} ms) — "প্রিভিউ শুনুন" চেপে তুলনা করুন।`);
    } catch {
      ws.notify("রেন্ডার ব্যর্থ হয়েছে", "err");
    } finally {
      ws.setBusy(null);
    }
  }

  async function applyEnhance() {
    if (!samples) return;
    ws.setBusy("এনহ্যান্সমেন্ট প্রয়োগ হচ্ছে…");
    const t0 = performance.now();
    try {
      const out = await renderEnhanced(samples, sampleRate, ws.enhance);
      ws.setAudio(out, `AI ভয়েস এনহ্যান্সার (${ws.presetId})`);
      ws.setStatus("enhanced");
      setPreview(null);
      ws.notify("স্টুডিও-কোয়ালিটি ভয়েস চেইন প্রয়োগ হয়েছে।");
      await api
        .addLog({
          projectId: ws.projectId,
          operation: "ai-voice-enhance",
          label: presetById(ws.presetId).name,
          params: ws.enhance as unknown as Record<string, unknown>,
          result: { ms: Math.round(performance.now() - t0) },
          durationMs: Math.round(performance.now() - t0),
        })
        .catch(() => undefined);
    } catch {
      ws.notify("এনহ্যান্সমেন্ট ব্যর্থ", "err");
    } finally {
      ws.setBusy(null);
    }
  }

  function applyLevel() {
    if (!samples) return;
    const res = autoLevel(samples, sampleRate, { targetDb: target, maxBoostDb: maxBoost, maxCutDb: maxCut, windowMs, smoothing });
    ws.setAudio(res.samples, `অটো লেভেলিং (${target} dBFS)`);
    ws.notify(`ভলিউম এক লেভেলে আনা হয়েছে — টার্গেট ${target} dBFS RMS।`);
    void api
      .addLog({
        projectId: ws.projectId,
        operation: "auto-normalize",
        label: "ভয়েস বুস্টার / অটো লেভেলিং",
        params: { targetDb: target, maxBoostDb: maxBoost, maxCutDb: maxCut, windowMs, smoothing },
        result: { gainBlocks: res.gains.length },
      })
      .catch(() => undefined);
  }

  function applyNoise() {
    if (!samples) return;
    if (!ws.noiseProfile) {
      ws.notify("কোনো নয়েজ প্রিন্ট নেই — রেকর্ডারে ক্যাপচার করুন বা এডিটরে স্যাম্পল নিন।", "warn");
      router.push("/editor");
      return;
    }
    const out = reduceNoise(samples, sampleRate, ws.noiseProfile, ws.suppress);
    ws.setAudio(out, "নয়েজ রিমুভাল (প্রিন্ট)");
    ws.setStatus("cleaned");
    ws.notify("নয়েজ প্রিন্ট সাবট্রাকশন প্রয়োগ হয়েছে।");
    void api
      .addLog({
        projectId: ws.projectId,
        operation: "noise-removal",
        label: "প্রিন্ট থেকে স্পেকট্রাল সাবট্রাকশন",
        params: ws.suppress as unknown as Record<string, unknown>,
        result: { noiseFloorDb: Number(ws.noiseProfile.avgDb.toFixed(2)) },
      })
      .catch(() => undefined);
  }

  async function magicChain() {
    if (!samples) return;
    ws.setBusy("ওয়ান-ক্লিক স্টুডিও চেইন চলছে…");
    const t0 = performance.now();
    let out = samples;
    const steps: string[] = [];
    if (ws.noiseProfile) {
      out = reduceNoise(out, sampleRate, ws.noiseProfile, ws.suppress);
      steps.push("noise-subtract");
    }
    out = autoLevel(out, sampleRate, { targetDb: target, maxBoostDb: maxBoost, maxCutDb: maxCut, windowMs, smoothing }).samples;
    steps.push("auto-level");
    out = await renderEnhanced(out, sampleRate, ws.enhance);
    steps.push("ai-enhance");
    out = normalizePeak(out, -1);
    steps.push("peak-normalize");
    ws.setAudio(out, "ওয়ান-ক্লিক স্টুডিও চেইন");
    ws.setStatus("enhanced");
    ws.setBusy(null);
    ws.notify(`চেইন সম্পন্ন: ${steps.join(" → ")}`);
    await api
      .addLog({
        projectId: ws.projectId,
        operation: "studio-chain",
        label: "ওয়ান-ক্লিক স্টুডিও চেইন",
        params: { steps, preset: ws.presetId },
        result: { durationSec: Number((out.length / sampleRate).toFixed(2)) },
        durationMs: Math.round(performance.now() - t0),
      })
      .catch(() => undefined);
  }

  async function savePreset() {
    const name = window.prompt("প্রিসেটের নাম দিন:", `${ws.title} কাস্টম`);
    if (!name) return;
    try {
      const row = await api.savePreset({
        name,
        category: "CUSTOM",
        description: `${ws.presetId} থেকে কাস্টমাইজ করা`,
        config: ws.enhance as unknown as PresetRow["config"],
      });
      setDbPresets((p) => [row, ...p]);
      ws.notify(`প্রিসেট "${name}" সার্ভারে সেভ হয়েছে।`);
    } catch {
      ws.notify("প্রিসেট সেভ করা যায়নি", "err");
    }
  }

  const cfg = ws.enhance;
  const setCfg = (patch: Partial<EnhanceConfig>) => ws.setEnhance(patch);
  const customPresetList = dbPresets.filter((p) => !p.builtin);

  return (
    <div className="space-y-4">
      <div className="panel panel-notch flex flex-wrap items-end justify-between gap-4 px-5 py-4">
        <div>
          <div className="label-xs mb-2 text-copper">ফিচার ০৫ · AI স্পিচ ক্লিয়ারিটি ও সাউন্ড এনহ্যান্সমেন্ট</div>
          <h1 className="font-display text-[26px] leading-tight font-700 sm:text-[30px]">
            সাধারণ রেকর্ডিং → <span className="text-signal">স্টুডিও-কোয়ালিটি ভয়েস</span>
          </h1>
          <p className="mt-1.5 max-w-2xl text-[13.5px] text-sand-300">
            ভয়েস বুস্টার ও অটো-নর্মালাইজেশন পুরো অডিওর ভলিউম এক লেভেলে রাখে; AI ভয়েস এনহ্যান্সার মাল্টি-স্টেজ
            EQ → ডি-এসার → কম্প্রেসর → লিমিটার চেইনে ক্রিস্টাল ক্লিয়ার পডকাস্ট টোন তৈরি করে।
          </p>
        </div>
        <Row>
          <Btn variant="primary" icon={<IconWand />} onClick={magicChain} disabled={!samples}>
            ওয়ান-ক্লিক স্টুডিও চেইন
          </Btn>
          <Btn icon={<IconSave />} onClick={savePreset} disabled={!samples}>
            প্রিসেট সেভ
          </Btn>
        </Row>
      </div>

      {/* preset rail */}
      <Panel title="ভয়েস প্রিসেট" step="01" icon={<IconBolt />} subtitle="প্রতিটি প্রিসেট নিচের সব প্যারামিটার একসাথে সেট করে — তারপর নিজের মতো বদলানো যাবে।">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {[...enhancePresets, ...customPresetList.map((p) => ({ id: p.id, name: p.name, tag: p.category, description: p.description ?? "", config: p.config as unknown as EnhanceConfig }))].map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                ws.setPresetId(p.id);
                setPreview(null);
              }}
              className={`group border px-3 py-2.5 text-left transition-all ${
                ws.presetId === p.id
                  ? "border-signal/70 bg-signal/10 shadow-[inset_0_0_0_1px_rgba(255,162,58,0.25)]"
                  : "border-ink-700 bg-ink-900/50 hover:border-ink-600 hover:bg-ink-850"
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-display text-[13px] text-sand-50">{p.name}</span>
                <span className="font-mono text-[9px] tracking-[0.14em] text-copper uppercase">{p.tag}</span>
              </div>
              <p className="mt-1 text-[11.5px] leading-snug text-sand-500">{p.description}</p>
            </button>
          ))}
        </div>
      </Panel>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        {/* preview + report */}
        <div className="space-y-4">
          <Panel
            title="প্রিভিউ ও A/B তুলনা"
            step="02"
            icon={<IconWave />}
            right={<Badge tone={preview ? "teal" : "sand"}>{preview ? "প্রিভিউ রেডি" : "প্রিভিউ নেই"}</Badge>}
          >
            <div className="space-y-3">
              <Waveform samples={preview ?? samples} sampleRate={sampleRate} height={130} playhead={previewPlayer.playing ? previewPlayer.position : player.position} onSeek={(s) => (preview ? previewPlayer.seek(s) : player.seek(s))} label={preview ? "enhanced preview" : "current"} accent={preview ? "#2fd4c4" : "#ffa23a"} />
              <Row>
                <Btn size="sm" icon={<IconPlay width={13} height={13} />} onClick={() => { stopAll(); origPlayer.play(0); }}>
                  মূল (অরিজিনাল)
                </Btn>
                <Btn size="sm" variant={player.playing ? "danger" : "outline"} icon={player.playing ? <IconWave width={13} height={13} /> : <IconPlay width={13} height={13} />} onClick={() => { stopAll(); player.play(0); }}>
                  বর্তমান এডিট
                </Btn>
                <Btn size="sm" variant="teal" icon={<IconPlay width={13} height={13} />} disabled={!preview} onClick={() => { stopAll(); previewPlayer.play(0); }}>
                  প্রিভিউ শুনুন
                </Btn>
                <Btn size="sm" variant="ghost" onClick={stopAll}>
                  স্টপ
                </Btn>
                <span className="readout text-[11.5px] text-sand-500">
                  {timecode(previewPlayer.playing ? previewPlayer.position : player.position)} / {timecode((samples?.length ?? 0) / sampleRate)}
                </span>
              </Row>
              <Row>
                <Btn size="sm" icon={<IconCheck />} onClick={renderPreview} disabled={!samples}>
                  এনহ্যান্সমেন্ট প্রিভিউ রেন্ডার
                </Btn>
                <Btn size="sm" variant="primary" icon={<IconWand />} onClick={applyEnhance} disabled={!samples || !preview}>
                  প্রিভিউ প্রয়োগ করুন
                </Btn>
                {preview && (
                  <Btn size="sm" icon={<IconDownload />} onClick={() => downloadBlob(wavBlob(preview, sampleRate), `${ws.title}-enhanced-preview.wav`)}>
                    প্রিভিউ WAV
                  </Btn>
                )}
              </Row>
            </div>
          </Panel>

          <Panel title="লাউডনেস রিপোর্ট" step="03" icon={<IconWave />} subtitle="প্রসেসিংয়ের আগে/পরে পরিমাপ — কণ্ঠের ডাইনামিকস নষ্ট হয়েছে কিনা এখানেই ধরা পড়ে।">
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <Stat label="পিক (আগে)" value={before?.peakDb.toFixed(1) ?? "—"} unit="dB" />
                <Stat label="পিক (এখন)" value={after?.peakDb.toFixed(1) ?? "—"} unit="dB" tone="signal" />
                <Stat label="RMS (আগে)" value={before?.rmsDb.toFixed(1) ?? "—"} unit="dB" />
                <Stat label="RMS (এখন)" value={after?.rmsDb.toFixed(1) ?? "—"} unit="dB" tone="teal" />
              </div>
              <DeltaRow label="ডাইনামিক রেঞ্জ" a={before?.dynamicRangeDb} b={after?.dynamicRangeDb} unit="dB" invert />
              <DeltaRow label="সাইলেন্স (<−45 dB)" a={before?.silenceSec} b={after?.silenceSec} unit="s" invert />
              <DeltaRow label="ক্লিপড স্যাম্পল" a={before?.clipped} b={after?.clipped} unit="" invert />
              <DeltaRow label="দৈর্ঘ্য" a={before?.durationSec} b={after?.durationSec} unit="s" />
            </div>
          </Panel>
        </div>

        {/* controls */}
        <div className="space-y-4">
          <Panel title="ভয়েস বুস্টার ও অটো-নর্মালাইজেশন" step="04" icon={<IconBolt />} subtitle="ব্লক-ভিত্তিক RMS লেভেলিং — নয়েজ ফ্লোর বুস্ট এড়ায়, সফট লিমিটার পিক সামলায়।">
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Slider label="টার্গেট লাউডনেস" value={target} min={-32} max={-6} step={0.5} unit=" dBFS" format={(v) => v.toFixed(1)} onChange={setTarget} hint="পডকাস্টের জন্য −১৮ dBFS RMS ভালো স্ট্যান্ডার্ড।" />
                <Slider label="সর্বোচ্চ বুস্ট" value={maxBoost} min={0} max={30} step={1} unit=" dB" format={(v) => v.toFixed(0)} onChange={setMaxBoost} />
                <Slider label="সর্বোচ্চ কাট" value={maxCut} min={0} max={24} step={1} unit=" dB" format={(v) => v.toFixed(0)} onChange={setMaxCut} />
                <Slider label="উইন্ডো" value={windowMs} min={10} max={250} step={5} unit=" ms" format={(v) => v.toFixed(0)} onChange={setWindowMs} hint="ছোট উইন্ডো = দ্রুত প্রতিক্রিয়া, বড় উইন্ডো = মসৃণ গেইন।" />
              </div>
              <Slider label="গেইন স্মুদিং" value={smoothing} min={0} max={0.95} step={0.05} format={(v) => v.toFixed(2)} onChange={setSmoothing} />
              <Row>
                <Btn variant="primary" icon={<IconBolt />} onClick={applyLevel} disabled={!samples}>
                  অটো লেভেল প্রয়োগ
                </Btn>
                <Btn icon={<IconCheck />} onClick={() => samples && ws.setAudio(normalizeRms(samples, target), "RMS নর্মালাইজ")} disabled={!samples}>
                  RMS নর্মালাইজ
                </Btn>
                <Btn icon={<IconCheck />} onClick={() => samples && ws.setAudio(normalizePeak(samples, -1), "পিক নর্মালাইজ")} disabled={!samples}>
                  পিক নর্মালাইজ (−1 dB)
                </Btn>
              </Row>
            </div>
          </Panel>

          <Panel title="AI ভয়েস এনহ্যান্সার চেইন" step="05" icon={<IconWand />} tone="signal" subtitle="HPF → LPF → ওয়ার্মথ → প্রেজেন্স → ডি-এসার → এয়ার → কম্প্রেসর → মেকআপ → লিমিটার">
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Slider label="হাই-পাস ফিল্টার" value={cfg.highpassHz} min={20} max={300} step={5} unit=" Hz" format={(v) => v.toFixed(0)} onChange={(v) => setCfg({ highpassHz: v })} hint="রুম রাম্বল/হ্যান্ডেল নয়েজ কাটে।" />
                <Slider label="লো-পাস ফিল্টার" value={cfg.lowpassHz} min={6000} max={20000} step={500} unit=" Hz" format={(v) => (v / 1000).toFixed(1) + "k"} onChange={(v) => setCfg({ lowpassHz: v })} />
                <Slider label="ওয়ার্মথ (লো-শেল্ফ)" value={cfg.warmthGainDb} min={-6} max={8} step={0.5} unit=" dB" format={(v) => v.toFixed(1)} onChange={(v) => setCfg({ warmthGainDb: v })} />
                <Slider label="ওয়ার্মথ ফ্রিকোয়েন্সি" value={cfg.warmthHz} min={80} max={400} step={10} unit=" Hz" format={(v) => v.toFixed(0)} onChange={(v) => setCfg({ warmthHz: v })} />
                <Slider label="প্রেজেন্স বুস্ট" value={cfg.presenceGainDb} min={-6} max={12} step={0.5} unit=" dB" format={(v) => v.toFixed(1)} onChange={(v) => setCfg({ presenceGainDb: v })} hint="কণ্ঠের বোধগম্যতা ২.৫–৪.৫ kHz এ বাড়ে।" />
                <Slider label="প্রেজেন্স ফ্রিকোয়েন্সি" value={cfg.presenceHz} min={1000} max={7000} step={100} unit=" Hz" format={(v) => (v / 1000).toFixed(1) + "k"} onChange={(v) => setCfg({ presenceHz: v })} />
                <Slider label="এয়ার শেল্ফ" value={cfg.airGainDb} min={-6} max={10} step={0.5} unit=" dB" format={(v) => v.toFixed(1)} onChange={(v) => setCfg({ airGainDb: v })} />
                <Slider label="ডি-এসার (হিস কমানো)" value={cfg.deEsserGainDb} min={-14} max={0} step={0.5} unit=" dB" format={(v) => v.toFixed(1)} tone="teal" onChange={(v) => setCfg({ deEsserGainDb: v })} />
                <Slider label="কম্প্রেসর থ্রেশহোল্ড" value={cfg.compThresholdDb} min={-50} max={0} step={1} unit=" dB" format={(v) => v.toFixed(0)} onChange={(v) => setCfg({ compThresholdDb: v })} />
                <Slider label="কম্প্রেসর রেশিও" value={cfg.compRatio} min={1} max={14} step={0.5} unit=":1" format={(v) => v.toFixed(1)} onChange={(v) => setCfg({ compRatio: v })} />
                <Slider label="মেকআপ গেইন" value={cfg.makeupGainDb} min={-6} max={16} step={0.5} unit=" dB" format={(v) => v.toFixed(1)} onChange={(v) => setCfg({ makeupGainDb: v })} />
                <Slider label="লিমিটার ড্রাইভ" value={cfg.limiterDrive} min={1} max={2} step={0.05} unit="×" format={(v) => v.toFixed(2)} onChange={(v) => setCfg({ limiterDrive: v })} />
              </div>
              <Row>
                <Chip onClick={() => ws.resetEnhance()}>প্রিসেটে রিসেট</Chip>
                <Chip onClick={() => setCfg({ presenceGainDb: cfg.presenceGainDb + 1 })}>প্রেজেন্স +1</Chip>
                <Chip onClick={() => setCfg({ compRatio: Math.min(14, cfg.compRatio + 1) })}>রেশিও +1</Chip>
                <Chip onClick={() => setCfg({ highpassHz: cfg.highpassHz > 20 ? cfg.highpassHz - 20 : 20 })}>HPF −20Hz</Chip>
              </Row>
              <CodeBlock
                label="render chain"
                code={`highpass(${cfg.highpassHz}Hz) → lowpass(${cfg.lowpassHz}Hz) → lowshelf(${cfg.warmthHz}Hz, ${cfg.warmthGainDb}dB)
→ peaking(${cfg.presenceHz}Hz, ${cfg.presenceGainDb}dB, Q${cfg.presenceQ}) → deesser(${cfg.deEsserHz}Hz, ${cfg.deEsserGainDb}dB)
→ highshelf(${cfg.airHz}Hz, ${cfg.airGainDb}dB) → compressor(${cfg.compThresholdDb}dB, ${cfg.compRatio}:1, ${cfg.compAttack}s/${cfg.compRelease}s)
→ makeup(${cfg.makeupGainDb}dB) → tanh limiter(${cfg.limiterDrive}x, 4x oversample)`}
              />
            </div>
          </Panel>

          <Panel title="নয়েজ রিমুভাল কন্ট্রোল" step="06" icon={<IconFan />} tone="teal" subtitle={ws.noiseProfile ? `শেখা প্রিন্ট: ${ws.noiseProfile.avgDb.toFixed(1)} dB ফ্লোর · ${ws.noiseProfile.learnedSec.toFixed(1)}s` : "এখনো কোনো নয়েজ প্রিন্ট শেখা হয়নি"}>
            <div className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-3">
                <Slider label="স্ট্রেংথ" value={ws.suppress.strength} min={1} max={4} step={0.1} unit="×" tone="teal" format={(v) => v.toFixed(1)} onChange={(v) => ws.setSuppress({ strength: v })} />
                <Slider label="ম্যাক্স কাট" value={ws.suppress.floorDb} min={-48} max={-6} step={1} unit=" dB" tone="teal" format={(v) => v.toFixed(0)} onChange={(v) => ws.setSuppress({ floorDb: v })} />
                <Slider label="স্মুদিং" value={ws.suppress.smoothing} min={0} max={0.9} step={0.05} tone="teal" format={(v) => v.toFixed(2)} onChange={(v) => ws.setSuppress({ smoothing: v })} />
              </div>
              <Row>
                <Btn variant="teal" icon={<IconFan />} onClick={applyNoise} disabled={!samples}>
                  নয়েজ রিমুভ প্রয়োগ
                </Btn>
                <Btn variant="ghost" onClick={() => router.push("/editor")}>
                  এডিটরে স্যাম্পল নিতে যান →
                </Btn>
              </Row>
            </div>
          </Panel>

          <Panel title="মাস্টার আউটপুট" step="07" icon={<IconSave />}>
            <Row>
              <Btn
                variant="primary"
                icon={<IconSave />}
                disabled={!samples}
                onClick={async () => {
                  if (!samples) return;
                  ws.setBusy("সার্ভারে সেভ হচ্ছে…");
                  const res = await persistToServer({
                    samples,
                    sampleRate,
                    title: ws.title,
                    status: ws.status === "empty" ? "enhanced" : ws.status,
                    projectId: ws.projectId,
                    noiseProfile: ws.noiseProfile,
                    kind: "processed",
                    label: "এনহ্যান্সড মাস্টার",
                  });
                  ws.setBusy(null);
                  ws.setDirty(false);
                  if (res) ws.notify("এনহ্যান্সড মাস্টার সার্ভারে সেভ হয়েছে — লাইব্রেরিতে দেখুন।");
                }}
              >
                সার্ভারে সেভ করুন
              </Btn>
              <Btn icon={<IconDownload />} disabled={!samples} onClick={() => samples && downloadBlob(wavBlob(samples, sampleRate, 16), `${ws.title}-master.wav`)}>
                16-bit WAV
              </Btn>
              <Btn icon={<IconDownload />} disabled={!samples} onClick={() => samples && downloadBlob(wavBlob(samples, sampleRate, 24), `${ws.title}-master-24bit.wav`)}>
                24-bit WAV
              </Btn>
              <Btn variant="ghost" onClick={() => router.push("/library")}>
                লাইব্রেরি →
              </Btn>
            </Row>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function DeltaRow({
  label,
  a,
  b,
  unit,
  invert,
}: {
  label: string;
  a?: number;
  b?: number;
  unit: string;
  invert?: boolean;
}) {
  if (a == null || b == null) return null;
  const delta = b - a;
  const good = invert ? delta <= 0 : delta >= 0;
  return (
    <div className="flex items-center gap-3 border border-ink-700/60 bg-ink-900/50 px-3 py-2">
      <span className="flex-1 text-[12.5px] text-sand-300">{label}</span>
      <span className="readout text-[12px] text-sand-500">
        {a.toFixed(2)} {unit}
      </span>
      <span className="text-sand-500">→</span>
      <span className="readout text-[12px] text-sand-50">
        {b.toFixed(2)} {unit}
      </span>
      <span className={`readout w-[74px] text-right text-[12px] ${Math.abs(delta) < 0.005 ? "text-sand-500" : good ? "text-lime" : "text-signal"}`}>
        {delta > 0 ? "+" : ""}
        {delta.toFixed(2)}
      </span>
    </div>
  );
}

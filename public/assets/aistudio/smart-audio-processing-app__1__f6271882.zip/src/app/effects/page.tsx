import type { Metadata } from "next";
import EffectsScreen from "@/screens/EffectsScreen";

export const metadata: Metadata = {
  title: "ইফেক্টস · VoiceLab Studio",
  description:
    "ভয়েস বুস্টার, অটো-নর্মালাইজেশন, AI ভয়েস এনহ্যান্সার ও নয়েজ রিমুভাল কন্ট্রোল প্যানেল — A/B তুলনা ও লাউডনেস রিপোর্টসহ।",
};

export default function Page() {
  return <EffectsScreen />;
}

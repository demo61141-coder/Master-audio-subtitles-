import type { Metadata } from "next";
import ApkScreen from "@/screens/ApkScreen";

export const metadata: Metadata = {
  title: "APK গাইড · VoiceLab Studio",
  description:
    "VoiceLab Studio অ্যাপটি Android APK বানানোর সম্পূর্ণ গাইড — PWA ইনস্টল, Capacitor বিল্ড, Bubblewrap TWA ও স্টার্টার বান্ডল।",
};

export default function Page() {
  return <ApkScreen />;
}

import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AppShell } from "@/components/AppShell";
import { SwRegister } from "@/components/SwRegister";

export const metadata: Metadata = {
  title: "VoiceLab Studio — নয়েজ ইন্টেলিজেন্স অডিও স্টুডিও",
  description:
    "নয়েজ প্রোফাইল লার্নিং, স্মার্ট রেকর্ডিং, সাইলেন্স স্কিপ, ডুয়েল-মোড সাইলেন্স রিমুভাল, অটো স্প্লিটার ও AI ভয়েস এনহ্যান্সমেন্ট — সব এক জায়গায়।",
  applicationName: "VoiceLab Studio",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: "/icons/icon-512.png",
    apple: "/icons/icon-512.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#0b0d10",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="bn">
      <body className="min-h-screen bg-ink-950 text-sand-50 antialiased">
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap"
        />
        <AppShell>{children}</AppShell>
        <SwRegister />
      </body>
    </html>
  );
}

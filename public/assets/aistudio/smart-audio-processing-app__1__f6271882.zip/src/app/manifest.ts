import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "VoiceLab Studio — নয়েজ ইন্টেলিজেন্স অডিও স্টুডিও",
    short_name: "VoiceLab",
    description:
      "নয়েজ প্রিন্ট লার্নিং, সাইলেন্স স্কিপ রেকর্ডিং, সাইলেন্স রিমুভাল, অডিও স্প্লিটার ও AI ভয়েস এনহ্যান্সার।",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait-primary",
    background_color: "#0b0d10",
    theme_color: "#0b0d10",
    lang: "bn",
    categories: ["music", "productivity", "utilities"],
    icons: [
      {
        src: "/icons/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/icon-512.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}

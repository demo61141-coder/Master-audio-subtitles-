import { sql } from "drizzle-orm";
import { db } from "@/db";
import { audioAssets, processingLogs, projects } from "@/db/schema";
import type { DashboardStats } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(): Promise<Response> {
  const [p] = await db
    .select({
      count: sql<number>`count(*)::int`,
      seconds: sql<number>`coalesce(sum(${projects.durationSec}),0)::double precision`,
    })
    .from(projects);

  const [a] = await db
    .select({
      bytes: sql<string>`coalesce(sum(${audioAssets.bytes}),0)::bigint`,
      chunks: sql<number>`count(*) filter (where ${audioAssets.kind} = 'chunk')::int`,
    })
    .from(audioAssets);

  const [l] = await db
    .select({
      ops: sql<number>`count(*)::int`,
      silence: sql<number>`coalesce(sum(((${processingLogs.result}->>'removedSec'))::double precision),0)::double precision`,
    })
    .from(processingLogs);

  const out: DashboardStats = {
    projects: Number(p?.count ?? 0),
    audioSeconds: Number(p?.seconds ?? 0),
    silenceRemovedSec: Number(l?.silence ?? 0),
    chunks: Number(a?.chunks ?? 0),
    operations: Number(l?.ops ?? 0),
    storageBytes: Number(a?.bytes ?? 0),
  };
  return Response.json(out);
}

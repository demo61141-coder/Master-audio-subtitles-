import { desc, inArray } from "drizzle-orm";
import { db } from "@/db";
import { audioAssets, projects } from "@/db/schema";
import { serializeAsset, serializeProject } from "@/lib/server/serialize";
import type { AssetSummary, ProjectSummary } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(): Promise<Response> {
  const rows = await db.select().from(projects).orderBy(desc(projects.createdAt)).limit(200);
  const ids = rows.map((r) => r.id);

  const assetRows = ids.length
    ? await db
        .select({
          id: audioAssets.id,
          projectId: audioAssets.projectId,
          kind: audioAssets.kind,
          label: audioAssets.label,
          mime: audioAssets.mime,
          durationSec: audioAssets.durationSec,
          bytes: audioAssets.bytes,
          startSec: audioAssets.startSec,
          endSec: audioAssets.endSec,
          createdAt: audioAssets.createdAt,
        })
        .from(audioAssets)
        .where(inArray(audioAssets.projectId, ids))
    : [];

  const grouped = new Map<string, AssetSummary[]>();
  for (const a of assetRows) {
    const list = grouped.get(a.projectId) ?? [];
    list.push(serializeAsset(a));
    grouped.set(a.projectId, list);
  }

  const out: ProjectSummary[] = rows.map((row) => serializeProject(row, grouped.get(row.id) ?? []));
  return Response.json(out);
}

export async function POST(req: Request): Promise<Response> {
  const body = (await req.json().catch(() => null)) as Partial<{
    title: string;
    durationSec: number;
    sampleRate: number;
    channels: number;
    status: string;
    source: string;
    noisePrint: unknown;
    settings: unknown;
    stats: unknown;
    tags: string[];
  }> | null;

  if (!body) return Response.json({ error: "body দরকার" }, { status: 400 });

  const [row] = await db
    .insert(projects)
    .values({
      title: (body.title ?? "নতুন রেকর্ডিং").slice(0, 120),
      durationSec: Number(body.durationSec ?? 0),
      sampleRate: Math.round(Number(body.sampleRate ?? 44100)),
      channels: Math.round(Number(body.channels ?? 1)),
      status: body.status ?? "raw",
      source: body.source ?? "mic",
      noisePrint: (body.noisePrint ?? null) as never,
      settings: (body.settings ?? null) as never,
      stats: (body.stats ?? null) as never,
      tags: body.tags ?? [],
    })
    .returning();

  return Response.json(serializeProject(row, []), { status: 201 });
}

import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { audioAssets, projects } from "@/db/schema";
import { serializeAsset, serializeProject } from "@/lib/server/serialize";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx): Promise<Response> {
  const { id } = await ctx.params;
  const rows = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  if (!rows.length) return Response.json({ error: "প্রজেক্ট পাওয়া যায়নি" }, { status: 404 });
  const assets = await db
    .select()
    .from(audioAssets)
    .where(eq(audioAssets.projectId, id))
    .orderBy(desc(audioAssets.createdAt));
  return Response.json(serializeProject(rows[0], assets.map(serializeAsset)));
}

export async function PATCH(req: Request, ctx: Ctx): Promise<Response> {
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return Response.json({ error: "body দরকার" }, { status: 400 });

  const patch: Record<string, unknown> = { updatedAt: new Date() };
  const allowed = ["title", "status", "source", "tags", "noisePrint", "settings", "stats", "version"];
  for (const key of allowed) {
    if (body[key] !== undefined) patch[key] = body[key];
  }
  if (typeof body.durationSec === "number") patch.durationSec = body.durationSec;
  if (typeof body.sampleRate === "number") patch.sampleRate = body.sampleRate;
  if (typeof body.channels === "number") patch.channels = body.channels;

  const [row] = await db.update(projects).set(patch).where(eq(projects.id, id)).returning();
  if (!row) return Response.json({ error: "প্রজেক্ট পাওয়া যায়নি" }, { status: 404 });
  const assets = await db
    .select()
    .from(audioAssets)
    .where(eq(audioAssets.projectId, id))
    .orderBy(desc(audioAssets.createdAt));
  return Response.json(serializeProject(row, assets.map(serializeAsset)));
}

export async function DELETE(_req: Request, ctx: Ctx): Promise<Response> {
  const { id } = await ctx.params;
  await db.delete(projects).where(eq(projects.id, id));
  return Response.json({ ok: true });
}

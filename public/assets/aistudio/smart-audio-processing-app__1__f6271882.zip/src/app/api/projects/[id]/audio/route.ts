import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { audioAssets, projects } from "@/db/schema";
import { MAX_AUDIO_BYTES, serializeAsset } from "@/lib/server/serialize";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx): Promise<Response> {
  const { id } = await ctx.params;
  const rows = await db
    .select()
    .from(audioAssets)
    .where(eq(audioAssets.projectId, id))
    .orderBy(desc(audioAssets.createdAt));
  return Response.json(rows.map(serializeAsset));
}

export async function POST(req: Request, ctx: Ctx): Promise<Response> {
  const { id } = await ctx.params;
  const project = await db.select({ id: projects.id }).from(projects).where(eq(projects.id, id)).limit(1);
  if (!project.length) return Response.json({ error: "প্রজেক্ট পাওয়া যায়নি" }, { status: 404 });

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return Response.json({ error: "multipart/form-data দরকার" }, { status: 400 });
  }

  const file = form.get("file");
  if (!(file instanceof File)) return Response.json({ error: "ফাইল পাওয়া যায়নি" }, { status: 400 });
  if (file.size > MAX_AUDIO_BYTES) {
    return Response.json(
      { error: `অডিও অনেক বড় (${(file.size / 1024 / 1024).toFixed(1)} MB) — সর্বোচ্চ ${MAX_AUDIO_BYTES / 1024 / 1024} MB` },
      { status: 413 },
    );
  }

  const buf = Buffer.from(await file.arrayBuffer());
  const kind = String(form.get("kind") ?? "processed").slice(0, 32);
  const label = String(form.get("label") ?? kind).slice(0, 120);
  const durationSec = Number(form.get("durationSec") ?? 0);
  const startRaw = form.get("startSec");
  const endRaw = form.get("endSec");

  const [row] = await db
    .insert(audioAssets)
    .values({
      projectId: id,
      kind,
      label,
      mime: file.type || "audio/wav",
      durationSec: Number.isFinite(durationSec) ? durationSec : 0,
      bytes: buf.byteLength,
      startSec: startRaw == null ? null : Number(startRaw),
      endSec: endRaw == null ? null : Number(endRaw),
      data: buf,
    })
    .returning({
      id: audioAssets.id,
      kind: audioAssets.kind,
      label: audioAssets.label,
      mime: audioAssets.mime,
      durationSec: audioAssets.durationSec,
      bytes: audioAssets.bytes,
      startSec: audioAssets.startSec,
      endSec: audioAssets.endSec,
      createdAt: audioAssets.createdAt,
    });

  if (kind !== "chunk") {
    await db.update(projects).set({ updatedAt: new Date(), durationSec }).where(eq(projects.id, id));
  }

  return Response.json(serializeAsset(row), { status: 201 });
}

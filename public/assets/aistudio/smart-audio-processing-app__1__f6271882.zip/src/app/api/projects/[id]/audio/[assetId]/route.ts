import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { audioAssets } from "@/db/schema";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string; assetId: string }> };

export async function GET(_req: Request, ctx: Ctx): Promise<Response> {
  const { id, assetId } = await ctx.params;
  const rows = await db
    .select()
    .from(audioAssets)
    .where(and(eq(audioAssets.id, assetId), eq(audioAssets.projectId, id)))
    .limit(1);
  if (!rows.length) return Response.json({ error: "অডিও পাওয়া যায়নি" }, { status: 404 });
  const row = rows[0];
  const safeName = encodeURIComponent(`${row.label || row.kind}.wav`).replace(/['()]/g, "");
  return new Response(new Uint8Array(row.data), {
    headers: {
      "content-type": row.mime || "audio/wav",
      "content-length": String(row.bytes),
      "content-disposition": `attachment; filename="audio.wav"; filename*=UTF-8''${safeName}`,
      "cache-control": "private, max-age=60",
    },
  });
}

export async function DELETE(_req: Request, ctx: Ctx): Promise<Response> {
  const { id, assetId } = await ctx.params;
  await db.delete(audioAssets).where(and(eq(audioAssets.id, assetId), eq(audioAssets.projectId, id)));
  return Response.json({ ok: true });
}

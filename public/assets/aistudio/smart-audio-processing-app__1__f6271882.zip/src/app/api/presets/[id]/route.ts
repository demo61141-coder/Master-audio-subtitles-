import { and, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { presets } from "@/db/schema";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function DELETE(_req: Request, ctx: Ctx): Promise<Response> {
  const { id } = await ctx.params;
  // built-in presets are protected, user presets can be removed
  const deleted = await db
    .delete(presets)
    .where(and(eq(presets.id, id), ne(presets.builtin, true)))
    .returning({ id: presets.id });
  if (!deleted.length) return Response.json({ error: "বিল্ট-ইন প্রিসেট মুছে ফেলা যাবে না" }, { status: 400 });
  return Response.json({ ok: true });
}

import { desc } from "drizzle-orm";
import { db } from "@/db";
import { presets } from "@/db/schema";
import { enhancePresets } from "@/lib/audio/enhance";
import { serializePreset } from "@/lib/server/serialize";
import type { PresetRow } from "@/lib/api";

export const dynamic = "force-dynamic";

export async function GET(): Promise<Response> {
  const existing = await db.select().from(presets).limit(1);
  if (!existing.length) {
    await db.insert(presets).values(
      enhancePresets.map((p) => ({
        name: p.name,
        category: p.tag,
        description: p.description,
        builtin: true,
        config: p.config as unknown as PresetRow["config"],
      })),
    );
  }
  const rows = await db.select().from(presets).orderBy(desc(presets.builtin), desc(presets.createdAt));
  return Response.json(rows.map(serializePreset));
}

export async function POST(req: Request): Promise<Response> {
  const body = (await req.json().catch(() => null)) as Partial<{
    name: string;
    category: string;
    description: string;
    config: PresetRow["config"];
  }> | null;

  if (!body?.name || !body?.config) {
    return Response.json({ error: "name ও config দরকার" }, { status: 400 });
  }

  const [row] = await db
    .insert(presets)
    .values({
      name: body.name.slice(0, 80),
      category: (body.category ?? "CUSTOM").slice(0, 32),
      description: body.description?.slice(0, 240) ?? null,
      builtin: false,
      config: body.config,
    })
    .returning();

  return Response.json(serializePreset(row), { status: 201 });
}

import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { processingLogs } from "@/db/schema";
import { serializeLog } from "@/lib/server/serialize";

export const dynamic = "force-dynamic";

export async function GET(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  const rows = projectId
    ? await db
        .select()
        .from(processingLogs)
        .where(eq(processingLogs.projectId, projectId))
        .orderBy(desc(processingLogs.createdAt))
        .limit(100)
    : await db.select().from(processingLogs).orderBy(desc(processingLogs.createdAt)).limit(120);
  return Response.json(rows.map(serializeLog));
}

export async function POST(req: Request): Promise<Response> {
  const body = (await req.json().catch(() => null)) as Partial<{
    projectId: string | null;
    operation: string;
    label: string;
    params: Record<string, unknown>;
    result: Record<string, unknown>;
    durationMs: number;
  }> | null;

  if (!body?.operation) return Response.json({ error: "operation দরকার" }, { status: 400 });

  const [row] = await db
    .insert(processingLogs)
    .values({
      projectId: body.projectId ?? null,
      operation: body.operation.slice(0, 48),
      label: (body.label ?? "").slice(0, 160),
      params: (body.params ?? {}) as never,
      result: (body.result ?? {}) as never,
      durationMs: Math.round(Number(body.durationMs ?? 0)),
    })
    .returning();

  return Response.json(serializeLog(row), { status: 201 });
}

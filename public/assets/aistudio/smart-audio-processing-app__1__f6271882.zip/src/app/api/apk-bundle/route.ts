import JSZip from "jszip";

export const dynamic = "force-dynamic";

const README = `# VoiceLab Studio — Android APK বিল্ড গাইড (বাংলা)

এই অ্যাপটি একটি **ওয়য়েব-ভিত্তিক অডিও স্টুডিও**। Android APK বানানোর ৩টি উপায় আছে —
সবচেয়ে সহজ থেকে সবচেয়ে "আসল প্লে-স্টোর" পর্যন্ত সাজানো হলো।

---

## উপায় ১ (সবচেয়ে সহজ) — PWA ইনস্টল, APK ছাড়াই
1. Android ফোনে Chrome খুলে এই অ্যাপের URL ওপেন করুন।
2. মেনু (⋮) → **"Add to Home screen"** / **"ইনস্টল করুন"**।
3. অ্যাপটি হোমস্ক্রিনে নেটিভ অ্যাপের মতো আইকন নিয়ে বসে যাবে, ফুল-স্ক্রিনে চলবে,
   মাইক রেকর্ডিং + অফলাইন শেল সব কাজ করবে।
> দ্রষ্টব্য: HTTPS লাগবে (localhost বা https ডোমেইন)। মাইক অ্যাক্সেস শুধু secure origin-এ কাজ করে।

## উপায় ২ — Capacitor দিয়ে আসল \`app-debug.apk\` (সুপারিশ)
প্রয়োজন: Node.js 18+, JDK 17, Android Studio (SDK + Gradle)।

\`\`\`bash
# ১) ফোল্ডারে ঢুকুন
cd capacitor-app
npm install

# ২) নেট এক্সপোর্ট তৈরি (ওয়েব অ্যাসেট dist/ এ যাবে)
npm run build:web

# ৩) Android প্ল্যাটফর্ম যোগ + সিঙ্ক
npx cap add android
npx cap sync android

# ৪) ডিবাগ APK বিল্ড (সবচেয়ে সহজ, ইন্সটল করা যায়)
cd android
./gradlew assembleDebug
# আউটপুট: android/app/build/outputs/apk/debug/app-debug.apk

# ৫) ফোনে ইন্সটল
adb install -r app/build/outputs/apk/debug/app-debug.apk
\`\`\`

### রিলিজ (সাইন করা) APK
\`\`\`bash
keytool -genkey -v -keystore voicelab.keystore -alias voicelab \\
  -keyalg RSA -keysize 2048 -validity 10000
./gradlew assembleRelease
# তারপর android/app/build.gradle-এ signingConfigs যোগ করুন (নিচের নমুনা দেখুন)
\`\`\`

> গুরুত্বপূর্ণ: মোবাইলে ডেটাবেস/API সার্ভার থাকে না, তাই \`NEXT_PUBLIC_API_URL\`
> এ আপনার সার্ভারের ঠিকানা দিন (যেমন https://api.example.com)। রেকর্ডিং, নয়েজ
> প্রিন্ট, সাইলেন্স রিমুভাল, স্প্লিটার, এনহ্যান্সমেন্ট — সব DSP ফোনের নিজের
> Web Audio ইঞ্জিনেই চলে, তাই অফলাইনেও কাজ করে।

## উপায় ৩ — PWABuilder / Bubblewrap (TWA, Play Store-এর জন্য)
\`\`\`bash
npm i -g @bubblewrap/cli
bubblewrap init --manifest=https://YOUR-DOMAIN/manifest.webmanifest
bubblewrap build
# আউটপুট: app-release-signed.apk + .aab
\`\`\`
অথবা https://www.pwabuilder.com এ URL দিয়ে "Android Package" ডাউনলোড করুন।

---

## ফাইল ম্যাপ
| ফাইল | কাজ |
| --- | --- |
| \`capacitor-app/package.json\` | বিল্ড স্ক্রিপ্ট ও ডিপেন্ডেন্সি |
| \`capacitor-app/capacitor.config.ts\` | অ্যাপ আইডি, নাম, webDir |
| \`capacitor-app/next.config.mjs\` | স্ট্যাটিক এক্সপোর্ট সেটিং |
| \`capacitor-app/build-apk.sh\` | এক কমান্ডে পুরো বিল্ড পাইপলাইন |
| \`capacitor-app/env.example\` | API URL কনফিগ |
| \`signing.gradle.snippet\` | রিলিজ সাইনিং কনফিগ |
`;

const PACKAGE_JSON = `{
  "name": "voicelab-android",
  "private": true,
  "version": "1.0.0",
  "scripts": {
    "build:web": "next build",
    "sync": "cap sync android",
    "apk:debug": "cd android && ./gradlew assembleDebug",
    "apk:release": "cd android && ./gradlew assembleRelease",
    "android": "cap open android"
  },
  "dependencies": {
    "@capacitor/android": "^6.1.2",
    "@capacitor/core": "^6.1.2",
    "next": "^16.2.6",
    "react": "^19.2.6",
    "react-dom": "^19.2.6"
  },
  "devDependencies": {
    "@capacitor/cli": "^6.1.2",
    "typescript": "^5.9.3"
  }
}
`;

const CAPACITOR_CONFIG = `import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.voicelab.studio',
  appName: 'VoiceLab Studio',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: true,
  },
  plugins: {
    SplashScreen: { launchShowDuration: 800, backgroundColor: '#0a0b0d' },
  },
  server: {
    // লোকাল ডেভেলপমেন্টে আপনার পিসির dev সার্ভার দেখাতে চাইলে:
    // url: 'http://192.168.0.10:3000',
    // cleartext: true,
    androidScheme: 'https',
  },
};

export default config;
`;

const NEXT_CONFIG = `/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  distDir: 'dist',
  images: { unoptimized: true },
  trailingSlash: true,
};

export default nextConfig;
`;

const BUILD_SH = `#!/usr/bin/env bash
set -euo pipefail

echo "==> ১. ওয়েব বিল্ড (static export)"
npm run build:web

echo "==> ২. Capacitor sync"
npx cap sync android

echo "==> ৩. Gradle assembleDebug"
cd android && ./gradlew assembleDebug

APK="app/build/outputs/apk/debug/app-debug.apk"
echo "==> APK তৈরি: android/$APK"
echo "==> ফোনে ইন্সটল: adb install -r android/$APK"
`;

const ENV_EXAMPLE = `# APK থেকে আপনার ব্যাকএন্ড (Postgres + Next API) কোথায় থাকবে
NEXT_PUBLIC_API_URL=https://api.your-domain.com
NEXT_PUBLIC_APP_NAME=VoiceLab Studio
`;

const SIGNING = `// android/app/build.gradle এর ভেতরে যোগ করুন
android {
  signingConfigs {
    release {
      storeFile file("../../voicelab.keystore")
      storePassword System.getenv("KEYSTORE_PASSWORD")
      keyAlias "voicelab"
      keyPassword System.getenv("KEY_PASSWORD")
    }
  }
  buildTypes {
    release { signingConfig signingConfigs.release }
  }
}
`;

const PERMISSIONS = `<!-- android/app/src/main/AndroidManifest.xml -->
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
  android:maxSdkVersion="28" />
<uses-feature android:name="android.hardware.microphone" android:required="true" />
`;

export async function GET(): Promise<Response> {
  const zip = new JSZip();
  zip.file("README-BANGLA.md", README);
  zip.file("capacitor-app/package.json", PACKAGE_JSON);
  zip.file("capacitor-app/capacitor.config.ts", CAPACITOR_CONFIG);
  zip.file("capacitor-app/next.config.mjs", NEXT_CONFIG);
  zip.file("capacitor-app/build-apk.sh", BUILD_SH);
  zip.file("capacitor-app/env.example", ENV_EXAMPLE);
  zip.file("capacitor-app/signing.gradle.snippet", SIGNING);
  zip.file("capacitor-app/AndroidManifest.permissions.xml", PERMISSIONS);

  const data = await zip.generateAsync({ type: "arraybuffer", compression: "DEFLATE" });
  return new Response(data, {
    headers: {
      "content-type": "application/zip",
      "content-disposition": `attachment; filename="voicelab-android-apk-starter.zip"`,
      "content-length": String(data.byteLength),
    },
  });
}

import type { Metadata } from "next";
import LibraryScreen from "@/screens/LibraryScreen";

export const metadata: Metadata = {
  title: "লাইব্রেরি · VoiceLab Studio",
  description: "সার্ভারে সংরক্ষিত রেকর্ডিং, নয়েজ প্রিন্ট, স্প্লিট টুকরো ও DSP প্রসেসিং টাইমলাইন।",
};

export default function Page() {
  return <LibraryScreen />;
}

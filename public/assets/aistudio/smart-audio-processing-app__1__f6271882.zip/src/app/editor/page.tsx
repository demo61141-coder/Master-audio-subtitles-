import type { Metadata } from "next";
import EditorScreen from "@/screens/EditorScreen";

export const metadata: Metadata = {
  title: "এডিটর ও ট্রিমার · VoiceLab Studio",
  description:
    "ওয়েভফর্ম এডিটর — ডুয়েল মোড সাইলেন্স রিমুভাল, স্যাম্পল বেসড নয়েজ রিমুভ, অটো স্প্লিট ও ম্যানুয়াল টাইম রেঞ্জ স্প্লিটার।",
};

export default function Page() {
  return <EditorScreen />;
}

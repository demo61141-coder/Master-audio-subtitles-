import type { Metadata } from "next";
import RecorderScreen from "@/screens/RecorderScreen";

export const metadata: Metadata = {
  title: "রেকর্ডার · VoiceLab Studio",
  description:
    "নয়েজ প্রোফাইল লার্নিং, নয়েজ প্রিন্ট ক্যাপচার, লাইভ স্পেকট্রাল সাবট্রাকশন ও সাইলেন্স স্কিপ রেকর্ডিং।",
};

export default function Page() {
  return <RecorderScreen />;
}
